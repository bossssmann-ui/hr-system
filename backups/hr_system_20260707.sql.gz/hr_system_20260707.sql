--
-- PostgreSQL database dump
--

\restrict wdOxN2Mr8GXJApTcjSuArzPEr3bLN4B4NKLyOShjRTwts1Tnsr0QFO9YWp4tzcS

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: app; Type: SCHEMA; Schema: -; Owner: hr_user
--

CREATE SCHEMA app;


ALTER SCHEMA app OWNER TO hr_user;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: ApplicationStage; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public."ApplicationStage" AS ENUM (
    'new',
    'screen',
    'tech',
    'final',
    'offer',
    'hired',
    'rejected'
);


ALTER TYPE public."ApplicationStage" OWNER TO hr_user;

--
-- Name: AssessmentQuestionType; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public."AssessmentQuestionType" AS ENUM (
    'open',
    'single_choice',
    'multi_choice'
);


ALTER TYPE public."AssessmentQuestionType" OWNER TO hr_user;

--
-- Name: AssessmentSessionStatus; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public."AssessmentSessionStatus" AS ENUM (
    'invited',
    'consented',
    'in_progress',
    'submitted',
    'graded',
    'expired'
);


ALTER TYPE public."AssessmentSessionStatus" OWNER TO hr_user;

--
-- Name: CandidateSource; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public."CandidateSource" AS ENUM (
    'manual',
    'hh_ru',
    'sberpodbor',
    'avito',
    'rabota_ru',
    'referral',
    'careers_page'
);


ALTER TYPE public."CandidateSource" OWNER TO hr_user;

--
-- Name: Currency; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public."Currency" AS ENUM (
    'RUB',
    'USD',
    'THB',
    'USDT'
);


ALTER TYPE public."Currency" OWNER TO hr_user;

--
-- Name: InterviewStatus; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public."InterviewStatus" AS ENUM (
    'created',
    'transcribing',
    'transcribed',
    'protocol_ready',
    'failed'
);


ALTER TYPE public."InterviewStatus" OWNER TO hr_user;

--
-- Name: NotificationChannel; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public."NotificationChannel" AS ENUM (
    'email',
    'telegram',
    'in_app',
    'push'
);


ALTER TYPE public."NotificationChannel" OWNER TO hr_user;

--
-- Name: OfferStatus; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public."OfferStatus" AS ENUM (
    'draft',
    'manager_review',
    'approved',
    'sent',
    'accepted',
    'declined',
    'expired'
);


ALTER TYPE public."OfferStatus" OWNER TO hr_user;

--
-- Name: RequisitionStatus; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public."RequisitionStatus" AS ENUM (
    'draft',
    'submitted',
    'manager_approved',
    'hr_approved',
    'approved',
    'in_recruitment',
    'closed',
    'rejected'
);


ALTER TYPE public."RequisitionStatus" OWNER TO hr_user;

--
-- Name: RoleName; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public."RoleName" AS ENUM (
    'owner',
    'hr_admin',
    'recruiter',
    'hiring_manager',
    'employee',
    'candidate'
);


ALTER TYPE public."RoleName" OWNER TO hr_user;

--
-- Name: alumni_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.alumni_status AS ENUM (
    'active',
    'do_not_rehire',
    'archived'
);


ALTER TYPE public.alumni_status OWNER TO hr_user;

--
-- Name: analytics_signal_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.analytics_signal_status AS ENUM (
    'open',
    'reviewed',
    'dismissed'
);


ALTER TYPE public.analytics_signal_status OWNER TO hr_user;

--
-- Name: analytics_signal_type; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.analytics_signal_type AS ENUM (
    'flight_risk',
    'burnout'
);


ALTER TYPE public.analytics_signal_type OWNER TO hr_user;

--
-- Name: comp_plan_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.comp_plan_status AS ENUM (
    'draft',
    'approved',
    'applied'
);


ALTER TYPE public.comp_plan_status OWNER TO hr_user;

--
-- Name: device_platform; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.device_platform AS ENUM (
    'ios',
    'android',
    'web'
);


ALTER TYPE public.device_platform OWNER TO hr_user;

--
-- Name: employee_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.employee_status AS ENUM (
    'pre_onboarding',
    'probation',
    'active',
    'on_leave',
    'terminated',
    'alumni',
    'onboarding',
    'notice'
);


ALTER TYPE public.employee_status OWNER TO hr_user;

--
-- Name: employment_document_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.employment_document_status AS ENUM (
    'draft',
    'pending_signature',
    'signed',
    'declined',
    'expired',
    'archived'
);


ALTER TYPE public.employment_document_status OWNER TO hr_user;

--
-- Name: employment_document_type; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.employment_document_type AS ENUM (
    'offer_letter',
    'employment_contract',
    'nda',
    'addendum',
    'termination_letter',
    'certificate',
    'other'
);


ALTER TYPE public.employment_document_type OWNER TO hr_user;

--
-- Name: employment_type; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.employment_type AS ENUM (
    'full_time',
    'part_time',
    'contract',
    'internship'
);


ALTER TYPE public.employment_type OWNER TO hr_user;

--
-- Name: exit_reason_category; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.exit_reason_category AS ENUM (
    'voluntary',
    'mutual',
    'probation_failed',
    'for_cause',
    'other'
);


ALTER TYPE public.exit_reason_category OWNER TO hr_user;

--
-- Name: external_vacancy_post_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.external_vacancy_post_status AS ENUM (
    'pending',
    'published',
    'unpublished',
    'failed'
);


ALTER TYPE public.external_vacancy_post_status OWNER TO hr_user;

--
-- Name: idp_item_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.idp_item_status AS ENUM (
    'planned',
    'in_progress',
    'completed',
    'dropped'
);


ALTER TYPE public.idp_item_status OWNER TO hr_user;

--
-- Name: idp_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.idp_status AS ENUM (
    'draft',
    'active',
    'completed'
);


ALTER TYPE public.idp_status OWNER TO hr_user;

--
-- Name: job_board; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.job_board AS ENUM (
    'hh',
    'sber_podbor',
    'avito_jobs',
    'rabota_ru'
);


ALTER TYPE public.job_board OWNER TO hr_user;

--
-- Name: key_result_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.key_result_status AS ENUM (
    'open',
    'on_track',
    'at_risk',
    'achieved'
);


ALTER TYPE public.key_result_status OWNER TO hr_user;

--
-- Name: learning_assignment_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.learning_assignment_status AS ENUM (
    'assigned',
    'started',
    'completed',
    'expired'
);


ALTER TYPE public.learning_assignment_status OWNER TO hr_user;

--
-- Name: learning_content_type; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.learning_content_type AS ENUM (
    'video',
    'article',
    'quiz',
    'external_link',
    'scorm'
);


ALTER TYPE public.learning_content_type OWNER TO hr_user;

--
-- Name: lifecycle_event_type; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.lifecycle_event_type AS ENUM (
    'hired',
    'probation_started',
    'probation_passed',
    'probation_failed',
    'probation_extended',
    'role_change',
    'transfer',
    'leave_started',
    'leave_ended',
    'terminated',
    'rehired',
    'notice_started'
);


ALTER TYPE public.lifecycle_event_type OWNER TO hr_user;

--
-- Name: message_channel_type; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.message_channel_type AS ENUM (
    'in_app',
    'email',
    'telegram',
    'hh_chat'
);


ALTER TYPE public.message_channel_type OWNER TO hr_user;

--
-- Name: message_direction; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.message_direction AS ENUM (
    'inbound',
    'outbound'
);


ALTER TYPE public.message_direction OWNER TO hr_user;

--
-- Name: message_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.message_status AS ENUM (
    'draft',
    'queued',
    'sent',
    'delivered',
    'failed',
    'received'
);


ALTER TYPE public.message_status OWNER TO hr_user;

--
-- Name: okr_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.okr_status AS ENUM (
    'draft',
    'active',
    'achieved',
    'missed'
);


ALTER TYPE public.okr_status OWNER TO hr_user;

--
-- Name: onboarding_task_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.onboarding_task_status AS ENUM (
    'pending',
    'in_progress',
    'completed',
    'skipped',
    'blocked'
);


ALTER TYPE public.onboarding_task_status OWNER TO hr_user;

--
-- Name: one_on_one_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.one_on_one_status AS ENUM (
    'scheduled',
    'completed',
    'cancelled'
);


ALTER TYPE public.one_on_one_status OWNER TO hr_user;

--
-- Name: pre_start_portal_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.pre_start_portal_status AS ENUM (
    'pending_link',
    'active',
    'closed'
);


ALTER TYPE public.pre_start_portal_status OWNER TO hr_user;

--
-- Name: probation_outcome; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.probation_outcome AS ENUM (
    'passed',
    'failed',
    'extended'
);


ALTER TYPE public.probation_outcome OWNER TO hr_user;

--
-- Name: retention_entity_type; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.retention_entity_type AS ENUM (
    'candidate',
    'employee',
    'audit_event',
    'application',
    'resume'
);


ALTER TYPE public.retention_entity_type OWNER TO hr_user;

--
-- Name: review_cycle_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.review_cycle_status AS ENUM (
    'draft',
    'open',
    'closed'
);


ALTER TYPE public.review_cycle_status OWNER TO hr_user;

--
-- Name: review_request_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.review_request_status AS ENUM (
    'pending',
    'submitted',
    'declined'
);


ALTER TYPE public.review_request_status OWNER TO hr_user;

--
-- Name: selection_retention_outcome_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.selection_retention_outcome_status AS ENUM (
    'in_progress',
    'resolved_survived_90',
    'resolved_terminated'
);


ALTER TYPE public.selection_retention_outcome_status OWNER TO hr_user;

--
-- Name: subscription_status; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.subscription_status AS ENUM (
    'active',
    'past_due',
    'cancelled',
    'trialing'
);


ALTER TYPE public.subscription_status OWNER TO hr_user;

--
-- Name: termination_ground; Type: TYPE; Schema: public; Owner: hr_user
--

CREATE TYPE public.termination_ground AS ENUM (
    'voluntary_resignation',
    'involuntary',
    'end_of_contract',
    'probation_fail',
    'mutual_agreement',
    'retirement',
    'other'
);


ALTER TYPE public.termination_ground OWNER TO hr_user;

--
-- Name: current_roles(); Type: FUNCTION; Schema: app; Owner: hr_user
--

CREATE FUNCTION app.current_roles() RETURNS text[]
    LANGUAGE sql STABLE
    AS $$ SELECT string_to_array(coalesce(NULLIF(current_setting('app.user_roles', true), ''), ''), ',') $$;


ALTER FUNCTION app.current_roles() OWNER TO hr_user;

--
-- Name: current_tenant_id(); Type: FUNCTION; Schema: app; Owner: hr_user
--

CREATE FUNCTION app.current_tenant_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$ SELECT NULLIF(current_setting('app.tenant_id', true), '')::uuid $$;


ALTER FUNCTION app.current_tenant_id() OWNER TO hr_user;

--
-- Name: current_user_id(); Type: FUNCTION; Schema: app; Owner: hr_user
--

CREATE FUNCTION app.current_user_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$ SELECT NULLIF(current_setting('app.user_id', true), '')::uuid $$;


ALTER FUNCTION app.current_user_id() OWNER TO hr_user;

--
-- Name: has_role(text); Type: FUNCTION; Schema: app; Owner: hr_user
--

CREATE FUNCTION app.has_role(name text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$ SELECT name = ANY(app.current_roles()) $$;


ALTER FUNCTION app.has_role(name text) OWNER TO hr_user;

--
-- Name: is_admin(); Type: FUNCTION; Schema: app; Owner: hr_user
--

CREATE FUNCTION app.is_admin() RETURNS boolean
    LANGUAGE sql STABLE
    AS $$ SELECT app.has_role('owner') OR app.has_role('hr_admin') $$;


ALTER FUNCTION app.is_admin() OWNER TO hr_user;

--
-- Name: knowledge_articles_search_vector_refresh(); Type: FUNCTION; Schema: public; Owner: hr_user
--

CREATE FUNCTION public.knowledge_articles_search_vector_refresh() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.search_vector :=
        setweight(to_tsvector('simple', coalesce(NEW.title, '')), 'A') ||
        setweight(to_tsvector('simple', coalesce(NEW.body,  '')), 'B');
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.knowledge_articles_search_vector_refresh() OWNER TO hr_user;

--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: hr_user
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;


ALTER FUNCTION public.set_updated_at() OWNER TO hr_user;

--
-- Name: uuidv7(); Type: FUNCTION; Schema: public; Owner: hr_user
--

CREATE FUNCTION public.uuidv7() RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
  unix_ms BIGINT;
  rand    BYTEA;
  hex     TEXT;
BEGIN
  unix_ms := (extract(epoch FROM clock_timestamp()) * 1000)::BIGINT;
  rand    := gen_random_bytes(10);

  hex := lpad(to_hex(unix_ms), 12, '0')
      || '7'
      || to_hex(get_byte(rand, 0) & 15)
      || lpad(to_hex(get_byte(rand, 1)), 2, '0')
      || lpad(to_hex((get_byte(rand, 2) & 63) | 128), 2, '0')
      || lpad(to_hex(get_byte(rand, 3)), 2, '0')
      || lpad(to_hex(get_byte(rand, 4)), 2, '0')
      || lpad(to_hex(get_byte(rand, 5)), 2, '0')
      || lpad(to_hex(get_byte(rand, 6)), 2, '0')
      || lpad(to_hex(get_byte(rand, 7)), 2, '0')
      || lpad(to_hex(get_byte(rand, 8)), 2, '0')
      || lpad(to_hex(get_byte(rand, 9)), 2, '0');

  RETURN CAST(
    substr(hex, 1,  8) || '-' ||
    substr(hex, 9,  4) || '-' ||
    substr(hex, 13, 4) || '-' ||
    substr(hex, 17, 4) || '-' ||
    substr(hex, 21, 12)
  AS UUID);
END;
$$;


ALTER FUNCTION public.uuidv7() OWNER TO hr_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO hr_user;

--
-- Name: alumni_profiles; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.alumni_profiles (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    candidate_id uuid,
    status public.alumni_status DEFAULT 'active'::public.alumni_status NOT NULL,
    would_rehire boolean,
    departure_reason text,
    rehire_eligible_from date,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.alumni_profiles FORCE ROW LEVEL SECURITY;


ALTER TABLE public.alumni_profiles OWNER TO hr_user;

--
-- Name: analytics_signals; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.analytics_signals (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    type public.analytics_signal_type NOT NULL,
    score integer NOT NULL,
    factors jsonb DEFAULT '[]'::jsonb NOT NULL,
    status public.analytics_signal_status DEFAULT 'open'::public.analytics_signal_status NOT NULL,
    computed_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    reviewed_at timestamp(3) without time zone,
    reviewed_by uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT analytics_signals_score_range CHECK (((score >= 0) AND (score <= 100)))
);

ALTER TABLE ONLY public.analytics_signals FORCE ROW LEVEL SECURITY;


ALTER TABLE public.analytics_signals OWNER TO hr_user;

--
-- Name: application_stage_events; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.application_stage_events (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    application_id uuid NOT NULL,
    from_stage public."ApplicationStage" NOT NULL,
    to_stage public."ApplicationStage" NOT NULL,
    actor_user_id uuid NOT NULL,
    comment text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.application_stage_events FORCE ROW LEVEL SECURITY;


ALTER TABLE public.application_stage_events OWNER TO hr_user;

--
-- Name: applications; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.applications (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    candidate_id uuid NOT NULL,
    vacancy_id uuid NOT NULL,
    stage public."ApplicationStage" DEFAULT 'new'::public."ApplicationStage" NOT NULL,
    assigned_to_user_id uuid,
    notes text,
    ai_scoring jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    external_ids jsonb DEFAULT '{}'::jsonb NOT NULL,
    ai_score_feedback jsonb,
    ai_interview_questions jsonb,
    trust_flagged boolean DEFAULT false NOT NULL,
    ai_score numeric(10,4),
    ai_verdict text,
    ai_assessed_at timestamp(3) without time zone,
    ai_flags jsonb
);

ALTER TABLE ONLY public.applications FORCE ROW LEVEL SECURITY;


ALTER TABLE public.applications OWNER TO hr_user;

--
-- Name: assessment_answers; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.assessment_answers (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    session_id uuid NOT NULL,
    question_id uuid NOT NULL,
    answer jsonb NOT NULL,
    ai_grade jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.assessment_answers FORCE ROW LEVEL SECURITY;


ALTER TABLE public.assessment_answers OWNER TO hr_user;

--
-- Name: assessment_questions; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.assessment_questions (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    template_id uuid NOT NULL,
    question_order integer NOT NULL,
    type public."AssessmentQuestionType" NOT NULL,
    prompt text NOT NULL,
    options jsonb,
    rubric text,
    competency text,
    weight double precision DEFAULT 1 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public.assessment_questions FORCE ROW LEVEL SECURITY;


ALTER TABLE public.assessment_questions OWNER TO hr_user;

--
-- Name: assessment_sessions; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.assessment_sessions (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    template_id uuid NOT NULL,
    application_id uuid NOT NULL,
    invite_token text NOT NULL,
    status public."AssessmentSessionStatus" DEFAULT 'invited'::public."AssessmentSessionStatus" NOT NULL,
    consent_recorded boolean DEFAULT false NOT NULL,
    started_at timestamp(3) without time zone,
    submitted_at timestamp(3) without time zone,
    trust_score integer,
    trust_signals jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.assessment_sessions FORCE ROW LEVEL SECURITY;


ALTER TABLE public.assessment_sessions OWNER TO hr_user;

--
-- Name: assessment_templates; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.assessment_templates (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    vacancy_id uuid,
    title text NOT NULL,
    description text,
    time_limit_min integer,
    created_by uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public.assessment_templates FORCE ROW LEVEL SECURITY;


ALTER TABLE public.assessment_templates OWNER TO hr_user;

--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.audit_events (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    actor_user_id uuid,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid NOT NULL,
    diff jsonb NOT NULL,
    ip text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.audit_events FORCE ROW LEVEL SECURITY;


ALTER TABLE public.audit_events OWNER TO hr_user;

--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.auth_sessions (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    user_id uuid NOT NULL,
    refresh_token_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    revoked_at timestamp(3) without time zone,
    user_agent text,
    ip_address text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.auth_sessions OWNER TO hr_user;

--
-- Name: candidates; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.candidates (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    full_name text NOT NULL,
    email text,
    phone text,
    location text,
    source public."CandidateSource" DEFAULT 'manual'::public."CandidateSource" NOT NULL,
    external_ids jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    consent_context jsonb
);

ALTER TABLE ONLY public.candidates FORCE ROW LEVEL SECURITY;


ALTER TABLE public.candidates OWNER TO hr_user;

--
-- Name: comp_bands; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.comp_bands (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    grade text NOT NULL,
    currency public."Currency" NOT NULL,
    min_salary integer NOT NULL,
    mid_salary integer NOT NULL,
    max_salary integer NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT comp_bands_ordering_check CHECK (((min_salary > 0) AND (min_salary <= mid_salary) AND (mid_salary <= max_salary)))
);

ALTER TABLE ONLY public.comp_bands FORCE ROW LEVEL SECURITY;


ALTER TABLE public.comp_bands OWNER TO hr_user;

--
-- Name: comp_plan_items; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.comp_plan_items (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    current_salary integer NOT NULL,
    proposed_salary integer NOT NULL,
    currency public."Currency" NOT NULL,
    change_pct numeric(7,2) NOT NULL,
    reason text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT comp_plan_items_salary_positive_check CHECK (((current_salary >= 0) AND (proposed_salary >= 0)))
);

ALTER TABLE ONLY public.comp_plan_items FORCE ROW LEVEL SECURITY;


ALTER TABLE public.comp_plan_items OWNER TO hr_user;

--
-- Name: comp_plans; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.comp_plans (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    effective_date date NOT NULL,
    budget_currency public."Currency" NOT NULL,
    budget_total integer DEFAULT 0 NOT NULL,
    status public.comp_plan_status DEFAULT 'draft'::public.comp_plan_status NOT NULL,
    notes text,
    created_by_user_id uuid NOT NULL,
    approved_by_user_id uuid,
    approved_at timestamp(3) without time zone,
    applied_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT comp_plans_budget_nonneg_check CHECK ((budget_total >= 0))
);

ALTER TABLE ONLY public.comp_plans FORCE ROW LEVEL SECURITY;


ALTER TABLE public.comp_plans OWNER TO hr_user;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.conversations (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    candidate_id uuid NOT NULL,
    application_id uuid,
    subject text,
    last_message_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public.conversations FORCE ROW LEVEL SECURITY;


ALTER TABLE public.conversations OWNER TO hr_user;

--
-- Name: cron_job_runs; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.cron_job_runs (
    id uuid NOT NULL,
    job_name text NOT NULL,
    tenant_id uuid,
    scheduled_window text NOT NULL,
    started_at timestamp(3) without time zone NOT NULL,
    finished_at timestamp(3) without time zone,
    status text NOT NULL,
    attempt integer NOT NULL,
    error text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    CONSTRAINT cron_job_runs_status_check CHECK ((status = ANY (ARRAY['running'::text, 'succeeded'::text, 'failed'::text])))
);


ALTER TABLE public.cron_job_runs OWNER TO hr_user;

--
-- Name: data_retention_policies; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.data_retention_policies (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    entity_type public.retention_entity_type NOT NULL,
    retain_days integer NOT NULL,
    anonymize boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.data_retention_policies FORCE ROW LEVEL SECURITY;


ALTER TABLE public.data_retention_policies OWNER TO hr_user;

--
-- Name: device_tokens; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.device_tokens (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    platform public.device_platform NOT NULL,
    token text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.device_tokens FORCE ROW LEVEL SECURITY;


ALTER TABLE public.device_tokens OWNER TO hr_user;

--
-- Name: employee_lifecycle_events; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.employee_lifecycle_events (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    type public.lifecycle_event_type NOT NULL,
    from_status public.employee_status,
    to_status public.employee_status,
    effective_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    actor_user_id uuid,
    payload jsonb,
    note text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.employee_lifecycle_events FORCE ROW LEVEL SECURITY;


ALTER TABLE public.employee_lifecycle_events OWNER TO hr_user;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.employees (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    application_id uuid,
    org_unit_id uuid,
    full_name text NOT NULL,
    email text,
    phone text,
    job_title text,
    employment_type public.employment_type DEFAULT 'full_time'::public.employment_type NOT NULL,
    status public.employee_status DEFAULT 'pre_onboarding'::public.employee_status NOT NULL,
    hire_date date,
    probation_ends_at timestamp(3) without time zone,
    probation_outcome public.probation_outcome,
    terminated_at timestamp(3) without time zone,
    termination_ground public.termination_ground,
    termination_note text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    candidate_id uuid,
    requisition_id uuid,
    grade text,
    currency text,
    agreed_base_salary integer,
    agreed_start_date date,
    role_family text,
    CONSTRAINT employees_probation_requires_ends_at_chk CHECK (((status <> 'probation'::public.employee_status) OR (probation_ends_at IS NOT NULL))),
    CONSTRAINT employees_terminated_requires_metadata_chk CHECK (((status <> 'terminated'::public.employee_status) OR ((terminated_at IS NOT NULL) AND (termination_ground IS NOT NULL))))
);

ALTER TABLE ONLY public.employees FORCE ROW LEVEL SECURITY;


ALTER TABLE public.employees OWNER TO hr_user;

--
-- Name: employment_documents; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.employment_documents (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    type public.employment_document_type NOT NULL,
    status public.employment_document_status DEFAULT 'draft'::public.employment_document_status NOT NULL,
    title text NOT NULL,
    file_url text,
    metadata jsonb,
    issued_at timestamp(3) without time zone,
    signed_at timestamp(3) without time zone,
    expires_at timestamp(3) without time zone,
    created_by_user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.employment_documents FORCE ROW LEVEL SECURITY;


ALTER TABLE public.employment_documents OWNER TO hr_user;

--
-- Name: exit_interviews; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.exit_interviews (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    conducted_by_user_id uuid,
    conducted_at timestamp(3) without time zone,
    reason_category public.exit_reason_category NOT NULL,
    notes text,
    would_rehire boolean,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.exit_interviews FORCE ROW LEVEL SECURITY;


ALTER TABLE public.exit_interviews OWNER TO hr_user;

--
-- Name: external_vacancy_posts; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.external_vacancy_posts (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    vacancy_id uuid NOT NULL,
    board public.job_board NOT NULL,
    external_id text,
    status public.external_vacancy_post_status DEFAULT 'pending'::public.external_vacancy_post_status NOT NULL,
    last_error text,
    last_synced_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public.external_vacancy_posts FORCE ROW LEVEL SECURITY;


ALTER TABLE public.external_vacancy_posts OWNER TO hr_user;

--
-- Name: hh_connections; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.hh_connections (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    access_token text NOT NULL,
    refresh_token text NOT NULL,
    token_expires_at timestamp(3) without time zone NOT NULL,
    connected_employer_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public.hh_connections FORCE ROW LEVEL SECURITY;


ALTER TABLE public.hh_connections OWNER TO hr_user;

--
-- Name: hh_sync_cursors; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.hh_sync_cursors (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    vacancy_id uuid NOT NULL,
    last_synced_at timestamp(3) without time zone,
    last_negotiation_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public.hh_sync_cursors FORCE ROW LEVEL SECURITY;


ALTER TABLE public.hh_sync_cursors OWNER TO hr_user;

--
-- Name: hiring_requisitions; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.hiring_requisitions (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    org_unit_id uuid NOT NULL,
    created_by_user_id uuid NOT NULL,
    title text NOT NULL,
    grade text NOT NULL,
    salary_min integer NOT NULL,
    salary_max integer NOT NULL,
    currency public."Currency" NOT NULL,
    justification text NOT NULL,
    status public."RequisitionStatus" DEFAULT 'draft'::public."RequisitionStatus" NOT NULL,
    deadline_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    CONSTRAINT hiring_requisitions_salary_range_check CHECK ((salary_min <= salary_max))
);

ALTER TABLE ONLY public.hiring_requisitions FORCE ROW LEVEL SECURITY;


ALTER TABLE public.hiring_requisitions OWNER TO hr_user;

--
-- Name: hr_snapshots; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.hr_snapshots (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    snapshot_date date NOT NULL,
    headcount integer NOT NULL,
    headcount_by_status jsonb DEFAULT '{}'::jsonb NOT NULL,
    headcount_by_org_unit jsonb DEFAULT '{}'::jsonb NOT NULL,
    open_requisitions integer DEFAULT 0 NOT NULL,
    hired_mtd integer DEFAULT 0 NOT NULL,
    terminated_mtd integer DEFAULT 0 NOT NULL,
    avg_time_to_hire_days numeric(10,2),
    probation_pass_rate_qtd numeric(5,2),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.hr_snapshots FORCE ROW LEVEL SECURITY;


ALTER TABLE public.hr_snapshots OWNER TO hr_user;

--
-- Name: idp_items; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.idp_items (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    idp_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    status public.idp_item_status DEFAULT 'planned'::public.idp_item_status NOT NULL,
    due_date date,
    completed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.idp_items FORCE ROW LEVEL SECURITY;


ALTER TABLE public.idp_items OWNER TO hr_user;

--
-- Name: idps; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.idps (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    quarter text NOT NULL,
    summary text,
    status public.idp_status DEFAULT 'draft'::public.idp_status NOT NULL,
    created_by_user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.idps FORCE ROW LEVEL SECURITY;


ALTER TABLE public.idps OWNER TO hr_user;

--
-- Name: interviews; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.interviews (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    application_id uuid NOT NULL,
    scheduled_at timestamp(3) without time zone,
    recording_url text,
    consent_recorded boolean DEFAULT false NOT NULL,
    status public."InterviewStatus" DEFAULT 'created'::public."InterviewStatus" NOT NULL,
    transcript jsonb,
    protocol jsonb,
    offer_draft jsonb,
    created_by_user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public.interviews FORCE ROW LEVEL SECURITY;


ALTER TABLE public.interviews OWNER TO hr_user;

--
-- Name: key_results; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.key_results (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    okr_id uuid NOT NULL,
    title text NOT NULL,
    unit text,
    start_value double precision DEFAULT 0 NOT NULL,
    target_value double precision NOT NULL,
    current_value double precision DEFAULT 0 NOT NULL,
    status public.key_result_status DEFAULT 'open'::public.key_result_status NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.key_results FORCE ROW LEVEL SECURITY;


ALTER TABLE public.key_results OWNER TO hr_user;

--
-- Name: knowledge_articles; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.knowledge_articles (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[] NOT NULL,
    visibility text DEFAULT 'internal'::text NOT NULL,
    created_by_user_id uuid NOT NULL,
    updated_by_user_id uuid,
    deleted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    search_vector tsvector,
    CONSTRAINT knowledge_articles_visibility_check CHECK ((visibility = ANY (ARRAY['internal'::text, 'portal'::text])))
);

ALTER TABLE ONLY public.knowledge_articles FORCE ROW LEVEL SECURITY;


ALTER TABLE public.knowledge_articles OWNER TO hr_user;

--
-- Name: learning_assignments; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.learning_assignments (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    course_id uuid,
    path_id uuid,
    status public.learning_assignment_status DEFAULT 'assigned'::public.learning_assignment_status NOT NULL,
    progress_percent integer DEFAULT 0 NOT NULL,
    score integer,
    due_date date,
    started_at timestamp(3) without time zone,
    completed_at timestamp(3) without time zone,
    assigned_by_user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT learning_assignments_progress_chk CHECK (((progress_percent >= 0) AND (progress_percent <= 100))),
    CONSTRAINT learning_assignments_target_chk CHECK ((((course_id IS NOT NULL) AND (path_id IS NULL)) OR ((course_id IS NULL) AND (path_id IS NOT NULL))))
);

ALTER TABLE ONLY public.learning_assignments FORCE ROW LEVEL SECURITY;


ALTER TABLE public.learning_assignments OWNER TO hr_user;

--
-- Name: learning_courses; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.learning_courses (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    content_type public.learning_content_type NOT NULL,
    content_url text,
    duration_minutes integer,
    is_mandatory boolean DEFAULT false NOT NULL,
    org_unit_id uuid,
    created_by_user_id uuid NOT NULL,
    deleted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.learning_courses FORCE ROW LEVEL SECURITY;


ALTER TABLE public.learning_courses OWNER TO hr_user;

--
-- Name: learning_path_items; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.learning_path_items (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    path_id uuid NOT NULL,
    course_id uuid NOT NULL,
    item_order integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.learning_path_items FORCE ROW LEVEL SECURITY;


ALTER TABLE public.learning_path_items OWNER TO hr_user;

--
-- Name: learning_paths; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.learning_paths (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    role_family text,
    auto_assign boolean DEFAULT false NOT NULL,
    created_by_user_id uuid NOT NULL,
    deleted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.learning_paths FORCE ROW LEVEL SECURITY;


ALTER TABLE public.learning_paths OWNER TO hr_user;

--
-- Name: message_templates; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.message_templates (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    channel public.message_channel_type,
    subject text,
    body text NOT NULL,
    created_by_user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public.message_templates FORCE ROW LEVEL SECURITY;


ALTER TABLE public.message_templates OWNER TO hr_user;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.messages (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    conversation_id uuid NOT NULL,
    channel public.message_channel_type NOT NULL,
    direction public.message_direction NOT NULL,
    body text NOT NULL,
    sender_user_id uuid,
    external_id text,
    status public.message_status DEFAULT 'draft'::public.message_status NOT NULL,
    sent_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.messages FORCE ROW LEVEL SECURITY;


ALTER TABLE public.messages OWNER TO hr_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    recipient_user_id uuid NOT NULL,
    channel public."NotificationChannel" NOT NULL,
    template text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    read_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.notifications FORCE ROW LEVEL SECURITY;


ALTER TABLE public.notifications OWNER TO hr_user;

--
-- Name: offboarding_checklists; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.offboarding_checklists (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    due_date date,
    completed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.offboarding_checklists FORCE ROW LEVEL SECURITY;


ALTER TABLE public.offboarding_checklists OWNER TO hr_user;

--
-- Name: offboarding_tasks; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.offboarding_tasks (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    checklist_id uuid NOT NULL,
    task_order integer NOT NULL,
    title text NOT NULL,
    description text,
    assignee_role text NOT NULL,
    status public.onboarding_task_status DEFAULT 'pending'::public.onboarding_task_status NOT NULL,
    assignee_user_id uuid,
    due_date date,
    completed_at timestamp(3) without time zone,
    completed_by_user_id uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.offboarding_tasks FORCE ROW LEVEL SECURITY;


ALTER TABLE public.offboarding_tasks OWNER TO hr_user;

--
-- Name: offers; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.offers (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    application_id uuid NOT NULL,
    interview_id uuid,
    salary integer NOT NULL,
    currency public."Currency" NOT NULL,
    start_date date NOT NULL,
    grade text,
    conditions text[] DEFAULT ARRAY[]::text[] NOT NULL,
    status public."OfferStatus" DEFAULT 'draft'::public."OfferStatus" NOT NULL,
    docuseal_submission_id text,
    docuseal_document_url text,
    docuseal_signing_url text,
    sent_at timestamp with time zone,
    expires_at timestamp with time zone,
    accepted_at timestamp with time zone,
    declined_at timestamp with time zone,
    declined_reason text,
    created_by_user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT offers_salary_positive_check CHECK ((salary > 0))
);

ALTER TABLE ONLY public.offers FORCE ROW LEVEL SECURITY;


ALTER TABLE public.offers OWNER TO hr_user;

--
-- Name: okrs; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.okrs (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    parent_okr_id uuid,
    quarter text NOT NULL,
    objective text NOT NULL,
    description text,
    status public.okr_status DEFAULT 'draft'::public.okr_status NOT NULL,
    progress_percent integer DEFAULT 0 NOT NULL,
    created_by_user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT okrs_progress_chk CHECK (((progress_percent >= 0) AND (progress_percent <= 100)))
);

ALTER TABLE ONLY public.okrs FORCE ROW LEVEL SECURITY;


ALTER TABLE public.okrs OWNER TO hr_user;

--
-- Name: onboarding_checklists; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.onboarding_checklists (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    due_date date,
    completed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.onboarding_checklists FORCE ROW LEVEL SECURITY;


ALTER TABLE public.onboarding_checklists OWNER TO hr_user;

--
-- Name: onboarding_tasks; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.onboarding_tasks (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    checklist_id uuid NOT NULL,
    task_order integer NOT NULL,
    title text NOT NULL,
    description text,
    status public.onboarding_task_status DEFAULT 'pending'::public.onboarding_task_status NOT NULL,
    assignee_user_id uuid,
    due_date date,
    completed_at timestamp(3) without time zone,
    completed_by_user_id uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.onboarding_tasks FORCE ROW LEVEL SECURITY;


ALTER TABLE public.onboarding_tasks OWNER TO hr_user;

--
-- Name: one_on_ones; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.one_on_ones (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    manager_user_id uuid NOT NULL,
    scheduled_at timestamp(3) without time zone NOT NULL,
    duration_minutes integer,
    status public.one_on_one_status DEFAULT 'scheduled'::public.one_on_one_status NOT NULL,
    agenda text,
    notes text,
    action_items jsonb DEFAULT '[]'::jsonb NOT NULL,
    reminder_sent_at timestamp(3) without time zone,
    completed_at timestamp(3) without time zone,
    created_by_user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.one_on_ones FORCE ROW LEVEL SECURITY;


ALTER TABLE public.one_on_ones OWNER TO hr_user;

--
-- Name: org_units; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.org_units (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    parent_id uuid,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public.org_units FORCE ROW LEVEL SECURITY;


ALTER TABLE public.org_units OWNER TO hr_user;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.password_reset_tokens (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    used_at timestamp(3) without time zone,
    user_agent text,
    ip_address text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO hr_user;

--
-- Name: plans; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.plans (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    name text NOT NULL,
    max_employees integer NOT NULL,
    max_users integer NOT NULL,
    price_rub_monthly integer NOT NULL,
    features jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.plans OWNER TO hr_user;

--
-- Name: pre_start_portal_entries; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.pre_start_portal_entries (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    employee_id uuid NOT NULL,
    status public.pre_start_portal_status DEFAULT 'pending_link'::public.pre_start_portal_status NOT NULL,
    opened_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    linked_at timestamp(3) without time zone,
    closed_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.pre_start_portal_entries FORCE ROW LEVEL SECURITY;


ALTER TABLE public.pre_start_portal_entries OWNER TO hr_user;

--
-- Name: queue_jobs; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.queue_jobs (
    id uuid NOT NULL,
    queue_name text NOT NULL,
    payload jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 5 NOT NULL,
    available_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    started_at timestamp(3) without time zone,
    finished_at timestamp(3) without time zone,
    last_error text,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    CONSTRAINT queue_jobs_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'done'::text, 'failed'::text])))
);


ALTER TABLE public.queue_jobs OWNER TO hr_user;

--
-- Name: resumes; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.resumes (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    candidate_id uuid NOT NULL,
    file_url text NOT NULL,
    parsed_payload jsonb,
    uploaded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp(3) without time zone
);

ALTER TABLE ONLY public.resumes FORCE ROW LEVEL SECURITY;


ALTER TABLE public.resumes OWNER TO hr_user;

--
-- Name: review_cycles; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.review_cycles (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    title text NOT NULL,
    quarter text NOT NULL,
    status public.review_cycle_status DEFAULT 'draft'::public.review_cycle_status NOT NULL,
    questions jsonb DEFAULT '[]'::jsonb NOT NULL,
    opened_at timestamp(3) without time zone,
    closes_at timestamp(3) without time zone,
    closed_at timestamp(3) without time zone,
    created_by_user_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.review_cycles FORCE ROW LEVEL SECURITY;


ALTER TABLE public.review_cycles OWNER TO hr_user;

--
-- Name: review_requests; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.review_requests (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    cycle_id uuid NOT NULL,
    subject_employee_id uuid NOT NULL,
    reviewer_user_id uuid NOT NULL,
    relationship text DEFAULT 'peer'::text NOT NULL,
    status public.review_request_status DEFAULT 'pending'::public.review_request_status NOT NULL,
    response jsonb,
    decline_reason text,
    submitted_at timestamp(3) without time zone,
    declined_at timestamp(3) without time zone,
    reminder_sent_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.review_requests FORCE ROW LEVEL SECURITY;


ALTER TABLE public.review_requests OWNER TO hr_user;

--
-- Name: selection_retention_outcomes; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.selection_retention_outcomes (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid NOT NULL,
    hire_date date NOT NULL,
    observed_days integer NOT NULL,
    survived_30 boolean NOT NULL,
    survived_60 boolean NOT NULL,
    survived_90 boolean NOT NULL,
    termination_ground public.termination_ground,
    outcome_status public.selection_retention_outcome_status NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.selection_retention_outcomes OWNER TO hr_user;

--
-- Name: selection_scoring_weights; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.selection_scoring_weights (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    model_version text NOT NULL,
    weights jsonb NOT NULL,
    sample_size integer NOT NULL,
    computed_at timestamp with time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT false NOT NULL
);


ALTER TABLE public.selection_scoring_weights OWNER TO hr_user;

--
-- Name: selection_sessions; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.selection_sessions (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    application_id uuid,
    template_id uuid NOT NULL,
    token text DEFAULT public.uuidv7() NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    started_at timestamp(3) without time zone,
    completed_at timestamp(3) without time zone,
    expires_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    assessment_profile jsonb,
    specializations jsonb,
    flags jsonb
);

ALTER TABLE ONLY public.selection_sessions FORCE ROW LEVEL SECURITY;


ALTER TABLE public.selection_sessions OWNER TO hr_user;

--
-- Name: selection_stage_results; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.selection_stage_results (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    session_id uuid NOT NULL,
    stage_number integer NOT NULL,
    answers jsonb NOT NULL,
    scores jsonb,
    flags jsonb,
    ai_evaluation jsonb,
    submitted_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.selection_stage_results FORCE ROW LEVEL SECURITY;


ALTER TABLE public.selection_stage_results OWNER TO hr_user;

--
-- Name: selection_templates; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.selection_templates (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    vacancy_id uuid NOT NULL,
    role text NOT NULL,
    stages jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.selection_templates FORCE ROW LEVEL SECURITY;


ALTER TABLE public.selection_templates OWNER TO hr_user;

--
-- Name: selection_verdicts; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.selection_verdicts (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    session_id uuid NOT NULL,
    verdict text NOT NULL,
    total_weighted_score numeric(65,30),
    stage_scores jsonb,
    cross_check_flags jsonb,
    lie_scale_result jsonb,
    verdict_reason text,
    hr_notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    retention_prediction jsonb
);

ALTER TABLE ONLY public.selection_verdicts FORCE ROW LEVEL SECURITY;


ALTER TABLE public.selection_verdicts OWNER TO hr_user;

--
-- Name: specialization_module_results; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.specialization_module_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid,
    package_id text NOT NULL,
    level text NOT NULL,
    raw_score numeric(5,2),
    max_score numeric(5,2),
    weighted_score numeric(5,2),
    flags jsonb,
    submitted_at timestamp with time zone DEFAULT now(),
    CONSTRAINT specialization_module_results_level_check CHECK ((level = ANY (ARRAY['primary'::text, 'secondary'::text, 'mentioned_only'::text, 'contradicted'::text])))
);


ALTER TABLE public.specialization_module_results OWNER TO hr_user;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.subscriptions (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    status public.subscription_status DEFAULT 'active'::public.subscription_status NOT NULL,
    current_period_end timestamp(3) without time zone,
    stripe_subscription_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.subscriptions FORCE ROW LEVEL SECURITY;


ALTER TABLE public.subscriptions OWNER TO hr_user;

--
-- Name: telegram_links; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.telegram_links (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    candidate_id uuid,
    employee_id uuid,
    chat_id text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    linked_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);

ALTER TABLE ONLY public.telegram_links FORCE ROW LEVEL SECURITY;


ALTER TABLE public.telegram_links OWNER TO hr_user;

--
-- Name: tenant_settings; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.tenant_settings (
    tenant_id uuid NOT NULL,
    logo_url text,
    primary_color text,
    timezone text DEFAULT 'Europe/Moscow'::text NOT NULL,
    locale text DEFAULT 'ru-RU'::text NOT NULL,
    feature_flags jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.tenant_settings FORCE ROW LEVEL SECURITY;


ALTER TABLE public.tenant_settings OWNER TO hr_user;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    slug text,
    subdomain text
);

ALTER TABLE ONLY public.tenants FORCE ROW LEVEL SECURITY;


ALTER TABLE public.tenants OWNER TO hr_user;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role public."RoleName" NOT NULL,
    tenant_id uuid NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.user_roles FORCE ROW LEVEL SECURITY;


ALTER TABLE public.user_roles OWNER TO hr_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    display_name text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    disabled_at timestamp(3) without time zone
);


ALTER TABLE public.users OWNER TO hr_user;

--
-- Name: vacancies; Type: TABLE; Schema: public; Owner: hr_user
--

CREATE TABLE public.vacancies (
    id uuid DEFAULT public.uuidv7() NOT NULL,
    tenant_id uuid NOT NULL,
    requisition_id uuid NOT NULL,
    org_unit_id uuid NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    is_published boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    hh_vacancy_id text,
    slug text,
    hh_sourcing_criteria jsonb,
    role text
);

ALTER TABLE ONLY public.vacancies FORCE ROW LEVEL SECURITY;


ALTER TABLE public.vacancies OWNER TO hr_user;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
47c26460-1174-4553-b9b2-3a2469e6ba2e	3c4c63a462b03ae07bded4f1cd3da81dc4278083c3a657f1bb3276e70337e816	2026-05-29 08:38:50.153381+00	20260516170056_uuidv7_function	\N	\N	2026-05-29 08:38:50.139932+00	1
c9520b85-bc54-415d-861b-bd5616b88029	aafe1ddf71b8b2821ca305910985bc6b629375e35c738ce3791a2587b056392a	\N	20260516170057_init	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260516170057_init\n\nDatabase error code: 42883\n\nDatabase error:\nERROR: function uuidv7() does not exist\nHINT: No function matches the given name and argument types. You might need to add explicit type casts.\n\nPosition:\n[1m  0[0m\n[1m  1[0m -- CreateTable\n[1m  2[0m CREATE TABLE "users" (\n[1m  3[1;31m     "id" UUID NOT NULL DEFAULT uuidv7(),[0m\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42883), message: "function uuidv7() does not exist", detail: None, hint: Some("No function matches the given name and argument types. You might need to add explicit type casts."), position: Some(Original(70)), where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("parse_func.c"), line: Some(629), routine: Some("ParseFuncOrColumn") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260516170057_init"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260516170057_init"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:255	2026-05-29 08:37:04.448478+00	2026-05-29 08:04:17.229627+00	0
0834694d-fdd7-4a2a-a09a-a8fc493f1aa8	aafe1ddf71b8b2821ca305910985bc6b629375e35c738ce3791a2587b056392a	\N	20260516170057_init	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260516170057_init\n\nDatabase error code: 42883\n\nDatabase error:\nERROR: function uuidv7() does not exist\nHINT: No function matches the given name and argument types. You might need to add explicit type casts.\n\nPosition:\n[1m  0[0m\n[1m  1[0m -- CreateTable\n[1m  2[0m CREATE TABLE "users" (\n[1m  3[1;31m     "id" UUID NOT NULL DEFAULT uuidv7(),[0m\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42883), message: "function uuidv7() does not exist", detail: None, hint: Some("No function matches the given name and argument types. You might need to add explicit type casts."), position: Some(Original(70)), where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("parse_func.c"), line: Some(629), routine: Some("ParseFuncOrColumn") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260516170057_init"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260516170057_init"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:255	2026-05-29 08:38:47.579308+00	2026-05-29 08:37:07.242335+00	0
73afce1b-0fb6-414e-85b1-181803e9a365	4c4ef2bb5e6b6d203e0cdbe8808734c2cafc711bcd5ba20037f7147457c75675	2026-05-29 08:38:50.496912+00	20260522000000_phase1f_interviews	\N	\N	2026-05-29 08:38:50.468423+00	1
714352bb-930b-4e35-9d82-437d1fc076d9	aafe1ddf71b8b2821ca305910985bc6b629375e35c738ce3791a2587b056392a	2026-05-29 08:38:50.200555+00	20260516170057_init	\N	\N	2026-05-29 08:38:50.155643+00	1
594e4f56-3197-4ad3-955e-5bc42dd9dd7a	fb8f5ad8e7de3390e978aed2282b35095e8267af1456d4609bc4b5b7d76b8372	2026-05-29 08:38:50.385553+00	20260520000000_phase0_recruiting	\N	\N	2026-05-29 08:38:50.201874+00	1
f44f0798-4318-486e-ad30-3dfd831f81d6	401096f74b8b490183f3a288398fc22e2f627d837a6130abdc6dffd3e4582e45	2026-05-29 08:38:50.604907+00	20260522111150_phase1d_assessments	\N	\N	2026-05-29 08:38:50.498074+00	1
a7a8ba3d-0f9e-4491-8d1b-42270de00ff2	a0df0973203cc08bf4cf8e8bd9fa27398569bd3d6f52bd4db8b00112df60d25d	2026-05-29 08:38:50.408983+00	20260520000001_phase0_rls	\N	\N	2026-05-29 08:38:50.386531+00	1
b47e5120-f671-4006-89fa-64cb4d53d32f	e663d4443f9e4f6407ac7de521f89b77b7f0645cccd9f8c425c2cac4bb4642dc	2026-05-29 08:38:50.448541+00	20260521120000_phase1a_hh_negotiations_sync	\N	\N	2026-05-29 08:38:50.410166+00	1
5ce89507-11eb-4ed3-a133-cbdb9e03ab81	6339cc1f7a6b7fae725775af919e3585c44e8d8d822516c9ddd8567404ba9dc5	2026-05-29 08:38:50.798803+00	20260524115117_phase2_selection	\N	\N	2026-05-29 08:38:50.768135+00	1
d68c2fbb-487e-4679-8550-c74f789912a1	1b5c6ecf6747b02839b0d411ce6b1746a544ad80be2d9196bad1e55960cda0af	2026-05-29 08:38:50.461534+00	20260521121000_phase1a_hh_rls	\N	\N	2026-05-29 08:38:50.449674+00	1
f27109f8-081c-444e-b8f9-07ba6bada190	9a703b90f3ded98c8745a65f1ed391f7586760682c6798d98879e2794a97c741	2026-05-29 08:38:50.675747+00	20260522200000_phase1e_messaging	\N	\N	2026-05-29 08:38:50.605887+00	1
b5622da5-52a5-4540-9f34-65773fb51b36	f82818628696b5b311263c654189f49033539830e88660730867f09508134617	2026-05-29 08:38:50.467296+00	20260521213838_phase1c_ai_score_feedback	\N	\N	2026-05-29 08:38:50.462443+00	1
8bcea568-1276-429d-a79d-c9cab53f0dbb	4d1dff3fe30c16ff9505c780f541dfb4e134c9bfdeebff2f542729fc9bf0cf5a	2026-05-29 08:38:50.943282+00	20260526045152_phase46_probation_states	\N	\N	2026-05-29 08:38:50.938913+00	1
8fd7a3d6-84b9-49a8-9d68-4d5e60468928	74a947dc1308d84d20a6202802564139725c69ef36029b3592c0454bc6e7db76	2026-05-29 08:38:50.684629+00	20260523000000_phase1g_careers	\N	\N	2026-05-29 08:38:50.676754+00	1
7a90a4c6-5b40-4bd6-86e2-129869e3b570	ec0ca9ddd15d1c1ebb26fad4ef2af735fc30882d7f98d57307cb7b57a4330ec2	2026-05-29 08:38:50.91347+00	20260525000000_phase4a_employee_lifecycle	\N	\N	2026-05-29 08:38:50.800244+00	1
d2323ca6-127c-4c5e-b9b4-e25657dc93a6	e2e8d1d3e353e7a040fe8e2254e07c847283ef74a167e1e7303a933e94f225e2	2026-05-29 08:38:50.767335+00	20260524000000_phase2_selection	\N	\N	2026-05-29 08:38:50.685796+00	1
0cfa8285-ccf2-400e-b2aa-3d613b78da03	21d7e405662194bd00af51c8b83087e32f98ae4fdd6aeb15860a33b3a699554d	2026-05-29 08:38:50.937899+00	20260526000000_phase4c_employee_handoff	\N	\N	2026-05-29 08:38:50.914552+00	1
7b3fecb0-4b5f-4c09-8172-d64dc3efd39b	80c9b41413535de89eceda0fe2cb11e496ca0bb9290aa3cdd2693b82f54a21dc	2026-05-29 08:38:50.977445+00	20260526130000_phase48_lifecycle_rls	\N	\N	2026-05-29 08:38:50.964752+00	1
2292d1ab-9d0b-4914-8754-7b64df469cb5	ebfb060aff8cf7457bdf5dd67cb9ffeffcf0c7c82482596e275dd3282bcda1a1	2026-05-29 08:38:50.963516+00	20260526120000_phase47_pre_start_portal	\N	\N	2026-05-29 08:38:50.944247+00	1
cda1adf9-1ed6-470e-a267-212ccfba86f9	55c02a3cbfe5764b95185735dc869d0c6c1b5bf4ded01d2597d392824d9bdf94	2026-05-29 08:38:51.023193+00	20260527000000_phase3_offers_comp	\N	\N	2026-05-29 08:38:50.97875+00	1
c8d7d079-b5ed-44e0-9ab4-5c22e576fe27	a3d122954abc675781ca71621a0df6637fba78bf91f4079df335bceab350626a	2026-05-29 08:38:51.099178+00	20260528000000_phase5_offboarding_alumni	\N	\N	2026-05-29 08:38:51.024363+00	1
f8f3ce04-7d4a-4320-a596-3f75e18c2ea2	864a75c7008119f0264a3048be5f2828206a8e458af840b928b5fab11ad29daa	2026-05-29 08:38:51.312848+00	20260529000000_phase6_learning_performance	\N	\N	2026-05-29 08:38:51.101513+00	1
acae298c-3ca2-4690-8bc5-65750fefdad5	d89ed1aa1d3c06ebf4bf73c5d3ea69b047220694019fca94c6700beae3d4ca6c	2026-05-29 08:38:51.362059+00	20260530000000_phase7_analytics_finance	\N	\N	2026-05-29 08:38:51.313823+00	1
bad9dd16-9c70-4495-8588-c3240ef431b2	b43f9108b5fd2265e6f6a79027c631980e17ec360fc2654dfe9c12672db1b66f	2026-05-29 08:38:51.41231+00	20260531000000_phase8_integrations	\N	\N	2026-05-29 08:38:51.363069+00	1
56b531f9-cbdd-498c-8ce6-d29d5755af09	07381db449500519664a7cb0d83eef1e6df174e768fe7084439b57e7bdd1d1df	2026-05-29 08:38:51.449658+00	20260601000000_phase9_ai_intelligence	\N	\N	2026-05-29 08:38:51.413176+00	1
1cd236f2-71de-4eed-abdd-7d3bf61c6bd3	87ff088dd9f03bbc26986d5ed656a62763573ebe4d140d1706c1e34c2b566056	2026-05-29 08:38:51.470908+00	20260602000000_phase11_device_tokens	\N	\N	2026-05-29 08:38:51.450612+00	1
a6696310-573c-4b50-a634-cceb0df228a0	88ae7f9a312f1313396704d6fc2bea76d68770e51b3f2dca7ad381bc3d2f4ab3	\N	20260603000000_phase12_multitenancy_compliance	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260603000000_phase12_multitenancy_compliance\n\nDatabase error code: 42883\n\nDatabase error:\nERROR: function gen_random_bytes(integer) does not exist\nHINT: No function matches the given name and argument types. You might need to add explicit type casts.\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42883), message: "function gen_random_bytes(integer) does not exist", detail: None, hint: Some("No function matches the given name and argument types. You might need to add explicit type casts."), position: Some(Internal { position: 12, query: "rand    := gen_random_bytes(10)" }), where_: Some("PL/pgSQL function uuidv7() line 8 at assignment"), schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("parse_func.c"), line: Some(629), routine: Some("ParseFuncOrColumn") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260603000000_phase12_multitenancy_compliance"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260603000000_phase12_multitenancy_compliance"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:255	2026-05-29 08:40:29.523839+00	2026-05-29 08:38:51.471726+00	0
a399c4cf-608c-4cfd-938e-00e21ea27dde	88ae7f9a312f1313396704d6fc2bea76d68770e51b3f2dca7ad381bc3d2f4ab3	\N	20260603000000_phase12_multitenancy_compliance	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260603000000_phase12_multitenancy_compliance\n\nDatabase error code: 42701\n\nDatabase error:\nERROR: column "slug" of relation "tenants" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42701), message: "column \\"slug\\" of relation \\"tenants\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("tablecmds.c"), line: Some(7347), routine: Some("check_for_column_name_collision") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260603000000_phase12_multitenancy_compliance"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260603000000_phase12_multitenancy_compliance"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:255	2026-05-29 08:42:34.411993+00	2026-05-29 08:40:31.854309+00	0
ead918ef-abe2-41d2-8fe2-6eec283d85f3	f9eb5dd61598c97735f72623d04adbf6211764d4512ab7c173ae84b7edd4a203	\N	20260605000000_phase15c_selection_session_specs	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260605000000_phase15c_selection_session_specs\n\nDatabase error code: 42701\n\nDatabase error:\nERROR: column "specializations" of relation "selection_sessions" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42701), message: "column \\"specializations\\" of relation \\"selection_sessions\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("tablecmds.c"), line: Some(7347), routine: Some("check_for_column_name_collision") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260605000000_phase15c_selection_session_specs"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260605000000_phase15c_selection_session_specs"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:255	2026-05-31 14:09:27.952327+00	2026-05-31 14:07:51.395775+00	0
da6949f4-e966-449b-b9ce-f111eb8cc144	60c72b2f36b43516959d9da58e79bf5e47199caf73b7b654ebaaf43978c8c423	\N	20260603000000_phase12_multitenancy_compliance	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260603000000_phase12_multitenancy_compliance\n\nDatabase error code: 42P07\n\nDatabase error:\nERROR: relation "tenant_settings" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P07), message: "relation \\"tenant_settings\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("heap.c"), line: Some(1164), routine: Some("heap_create_with_catalog") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260603000000_phase12_multitenancy_compliance"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260603000000_phase12_multitenancy_compliance"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:255	2026-05-29 08:44:01.705684+00	2026-05-29 08:42:36.894626+00	0
2e8184f6-894b-42e6-9444-86c0855d8d36	f9eb5dd61598c97735f72623d04adbf6211764d4512ab7c173ae84b7edd4a203	2026-05-31 14:09:27.955724+00	20260605000000_phase15c_selection_session_specs		\N	2026-05-31 14:09:27.955724+00	0
fd5a6320-ccfc-4927-91dc-b5a2b1ed54df	6ac55e7b4200fcf41d03bf6644a602af91399088c3eb7799bddb55554c86f3b1	2026-05-29 08:44:04.713113+00	20260603000000_phase12_multitenancy_compliance	\N	\N	2026-05-29 08:44:04.683734+00	1
819f2f1f-c265-4a4e-ab65-afc4ea9cb95a	74ead27c6f92c5d010d6596b4b9d5a8fbe0501c42b3f93c76ede46d9bb984bda	2026-05-31 14:07:51.390958+00	20260601000000_phase15a_domestic_profile	\N	\N	2026-05-31 14:07:51.355409+00	1
2edb9c61-cfdf-492f-a5df-2f53c7af9edd	f6ff311406f0cff95380c5555d584f1e2e6408b47e93a4dc083e7a7fba37501f	2026-05-31 14:07:51.394996+00	20260604000000_phase14b_selection_session_flags	\N	\N	2026-05-31 14:07:51.391709+00	1
d6a3c294-0ac0-4f6f-82d6-50d17117dd72	b9a110ba6d79aaf223264659a4e64cb28b1a576a2d127ef4fb69d79caa5d99e4	2026-06-03 10:20:57.994837+00	20260606000000_phase18_selection_retention_feedback	\N	\N	2026-06-03 10:20:57.914585+00	1
bd7d72f4-290c-47e5-b055-9711a1ba29db	b573f9df4228534045dfea20a50d3d1ee1af926c64699fd23d21c52754691c93	2026-06-05 06:39:22.660484+00	20260607000000_phase19_selection_application_bridge	\N	\N	2026-06-05 06:39:22.635564+00	1
92259a23-b1ca-4a73-a653-fd3e9f9a883b	11dac5504f83eaf1443c0df2fa0b8baa0b3cbfc15249d5e5099cf337b71eb084	2026-06-05 06:39:22.709706+00	20260610000000_phase21_hh_resume_sourcing	\N	\N	2026-06-05 06:39:22.705275+00	1
321d4b0b-6c49-44db-9980-8f27d63a3851	7a457c11be37f6a04fc64e410056525242d86d43cfe28a42c92e83dbe7d8b719	2026-06-05 06:39:22.687495+00	20260608000000_phase20_durable_queue	\N	\N	2026-06-05 06:39:22.661345+00	1
53fa106c-38d9-461f-8211-1006e35eeda3	404a0439898b021bdd9fc9b8743874cfbb6c318039e573a028f661af2351c0bb	2026-06-05 06:39:22.704487+00	20260609000000_phase20_cron_job_runs	\N	\N	2026-06-05 06:39:22.688205+00	1
dc05822e-b308-4c57-b6ec-67bdb3f4ff11	b5438357e7013ef65c6726f47e1398ba18b18d62e948232802f1179ae0c00947	2026-06-05 09:26:49.360689+00	20260611000000_phase22_vacancy_role_selector	\N	\N	2026-06-05 09:26:49.344399+00	1
8b83eb20-ce75-464e-8bc2-a0868ba9d5aa	372cf0a59106e6dbc036e844fd6b66c24320a57747c3436553518c024a7b7ff9	2026-07-05 14:49:42.211745+00	20260706000000_password_reset_tokens	\N	\N	2026-07-05 14:49:42.169767+00	1
\.


--
-- Data for Name: alumni_profiles; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.alumni_profiles (id, tenant_id, employee_id, candidate_id, status, would_rehire, departure_reason, rehire_eligible_from, tags, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_signals; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.analytics_signals (id, tenant_id, employee_id, type, score, factors, status, computed_at, reviewed_at, reviewed_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: application_stage_events; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.application_stage_events (id, tenant_id, application_id, from_stage, to_stage, actor_user_id, comment, created_at) FROM stdin;
019f3562-88f0-718e-95bd-b42fd5cd4909	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c586-7566-8b94-75ed1e04e42d	new	screen	019e72e8-735d-7c54-b229-08222aa2c6ca	Auto-moved to screening after AI relevance score 75 >= 70	2026-07-06 03:04:37.856
019f3562-88f3-72e3-b0ea-ea88e90a8d37	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c75b-7fc6-a540-cb753cc79f62	new	screen	019e72e8-735d-7c54-b229-08222aa2c6ca	Auto-moved to screening after AI relevance score 85 >= 70	2026-07-06 03:04:37.856
019f3576-90a4-7424-8848-8afe6f839ee5	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c8ee-744e-a7a6-812dbd88314f	new	screen	019e72e8-735d-7c54-b229-08222aa2c6ca	Auto-moved to screening after AI relevance score 85 >= 70	2026-07-06 03:26:30.561
019f3579-c9f0-76f1-b1e8-0a10570a45d3	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c825-7778-b131-e12c9dc892e7	new	screen	019f324a-0df9-7a4a-835a-f6f742e2d659	Auto-moved to screening after AI relevance score 80 >= 70	2026-07-06 03:30:01.836
019f358f-dbab-70c1-af7c-bd011dcd9d63	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c825-7778-b131-e12c9dc892e7	screen	new	019e8bd6-0aea-7b42-9ed7-28afab973de7	verification: recruiter backward move	2026-07-06 03:54:08.16
019f358f-dbcb-73ef-b07c-ad9bb3d45a3b	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c825-7778-b131-e12c9dc892e7	new	screen	019e8bd6-0aea-7b42-9ed7-28afab973de7	verification: restore stage	2026-07-06 03:54:08.2
019f35cb-86ab-75f2-879d-f25effcff09e	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c825-7778-b131-e12c9dc892e7	screen	new	019f324a-0df9-7a4a-835a-f6f742e2d659	\N	2026-07-06 04:59:18.568
019f35cd-1541-7dd9-b88c-7832de08485d	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c40d-773f-9c71-e1a661d3e493	new	screen	019e72e8-735d-7c54-b229-08222aa2c6ca	Auto-moved to screening after AI relevance score 70 >= 70	2026-07-06 05:01:00.607
019f35cf-c853-70f5-ba4f-036d782ceeda	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c8ee-744e-a7a6-812dbd88314f	screen	new	019e72e8-735d-7c54-b229-08222aa2c6ca	Auto-returned to new after AI relevance score 0 <= 60	2026-07-06 05:03:57.522
\.


--
-- Data for Name: applications; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.applications (id, tenant_id, candidate_id, vacancy_id, stage, assigned_to_user_id, notes, ai_scoring, created_at, updated_at, external_ids, ai_score_feedback, ai_interview_questions, trust_flagged, ai_score, ai_verdict, ai_assessed_at, ai_flags) FROM stdin;
019f32cc-c75b-7fc6-a540-cb753cc79f62	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c751-72d0-93db-2f7c59349d4f	019e8d16-224f-77a8-b24d-4de278134fd3	screen	\N	\N	{"status": "failed", "failure": {"error": "OpenAI-compatible scoring request failed: 403", "model": "deepseek/deepseek-v4-flash", "scored_at": "2026-07-07T00:49:18.727Z"}, "input_hash": "6a7e330088c0b915fcb5c58a6532bfe582015a04c4b1ba592c53c5e752250d43"}	2026-07-05 15:01:49.018	2026-07-07 00:49:18.728	{"hh_resume_id": "1dd9f114000992d3e100a886e6643645644a37", "hh_negotiation_id": "5400900869"}	{"note": null, "agrees": false, "user_id": "019f324a-0df9-7a4a-835a-f6f742e2d659", "created_at": "2026-07-06T03:28:42.197Z"}	\N	f	\N	\N	\N	\N
019f32cc-c40d-773f-9c71-e1a661d3e493	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c3eb-7fa9-a694-bd52a1884a27	019e8d16-224f-77a8-b24d-4de278134fd3	screen	\N	\N	{"result": {"gaps": ["Нет явного опыта в расширении логистических операций", "Не указаны конкретные навыки", "Образование получено недавно, возможно, нет глубоких теоретических знаний"], "model": "deepseek/deepseek-v4-flash", "summary": "Кандидат имеет 5 лет опыта в транспортной логистике, закупках и документообороте, что соответствует базовым требованиям должности логиста. Однако отсутствие четких указаний на опыт в расширении деятельности и отсутствие перечня навыков снижают релевантность. Образование получено в 2023 году, что указывает на возможное совмещение работы с учебой.", "red_flags": [], "scored_at": "2026-07-06T05:01:00.520Z", "strengths": ["Опыт работы менеджером по транспортной логистике", "Опыт в закупках и документообороте", "Общий стаж около 5 лет"], "tokens_used": 1849, "competencies": {"Закупки": {"score": 5, "reasoning": "Работал специалистом по закупкам, но без уточнения сложности и объемов."}, "Документооборот": {"score": 6, "reasoning": "Опыт ведущего специалиста по документообороту предполагает знание процессов, но не связан напрямую с логистикой."}, "Транспортная логистика": {"score": 7, "reasoning": "Занимал должность менеджера по транспортной логистике дважды, что указывает на практический опыт, но отсутствие деталей не позволяет оценить глубину."}, "Расширение деятельности": {"score": 2, "reasoning": "Нет упоминаний о проектах развития или масштабирования в логистике."}}, "model_version": "deepseek/deepseek-v4-flash-20260423", "schema_version": 2, "relevance_score": 70, "suggested_grade": "M1", "suggested_salary": 120000, "anti_fraud_signals": ["Резюме очень краткое, без детализации обязанностей и достижений", "Отсутствуют конкретные даты занятости в каждой роли", "Список навыков пуст"], "interview_questions": ["Расскажите о вашем опыте в проектах, связанных с расширением логистических операций или увеличением объемов перевоз"], "soft_skills_signals": ["Нет явных сигналов мягких навыков в резюме"], "interview_focus_areas": ["Опыт участия в проектах по расширению или оптимизации логистики", "Конкретные достижения в предыдущих ролях", "Уровень владения программными продуктами для логистики", "Причина смены должностей", "Карьерные ожидания и готовность к развитию"], "values_fit_hypothesis": "Кандидат, вероятно, ориентирован на стабильную работу и выполнение операционных задач, но не демонстрирует явного интереса к масштабированию и развитию."}, "status": "scored", "input_hash": "4e6680c4a82615b5a1f448624485b5329b72aea410eaf75118310f157ef278e1"}	2026-07-05 15:01:48.171	2026-07-06 05:01:00.592	{"hh_resume_id": "720ba0a3000984305400a886e6626439556c77", "hh_negotiation_id": "5390276569"}	{"note": null, "agrees": true, "user_id": "019f324a-0df9-7a4a-835a-f6f742e2d659", "created_at": "2026-07-05T15:06:45.894Z"}	\N	f	\N	\N	\N	\N
019f32cc-c8ee-744e-a7a6-812dbd88314f	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c8e8-79b5-b6cd-5a1fa6c7a877	019e8d16-224f-77a8-b24d-4de278134fd3	new	\N	\N	{"result": {"gaps": ["Отсутствие конкретных требований в описании вакансии не позволяет выявить несоответствия; требуется уточнение желаемых навыков.", "В резюме не указаны hard skills (например, знание TMS, WMS, 1C, SAP, работа с таможней, знание языков).", "Нет достижений, цифр, метрик (KPI, объемы перевозок, экономия бюджета)."], "model": "deepseek/deepseek-v4-flash", "summary": "Кандидат имеет значительный опыт в транспортной логистике и международных перевозках, однако предоставленное описание вакансии не содержит конкретных требований, что затрудняет оценку релевантности. Поле required_skills содержит только слово \\"Расширение\\", что не позволяет сопоставить навыки кандидата с ожиданиями работы. Кандидат занимал руководящие должности (руководитель отдела, заместитель директора) и имеет опыт работы со всеми видами транспорта, включая Китай и ЕС.", "red_flags": ["Отсутствует образование в профильной сфере (логистика/транспорт), что может быть важно.", "Резюме содержит только названия должностей и работодателей, без описания функционала и достижений — это может быть признаком неполноты или шаблонности."], "scored_at": "2026-07-06T05:03:57.471Z", "strengths": ["Обширный опыт в транспортной логистике: около 26 лет (318 месяцев).", "Опыт управления отделами и направлениями перевозок.", "Знание международных перевозок, включая Китай и Европу.", "Работа с различными видами транспорта (автомобильные, морские, железнодорожные)."], "tokens_used": 2419, "competencies": {"Знание ВЭД и таможни": {"score": 4, "reasoning": "Опыт с Китаем и международными перевозками предполагает знание ВЭД, но не описан."}, "Управление командой": {"score": 6, "reasoning": "Указаны руководящие должности, но нет информации о размере команд и результатах."}, "Организация перевозок": {"score": 7, "reasoning": "Общий опыт в транспортной логистике подтверждает компетенцию, но отсутствие деталей не позволяет оценить глубину."}}, "model_version": "deepseek/deepseek-v4-flash-20260423", "schema_version": 2, "relevance_score": 0, "suggested_grade": "М1 (при соответствии требованиям)", "suggested_salary": null, "anti_fraud_signals": ["Резюме выглядит шаблонным: нет конкретных дат, мест работы, описания обязанностей или результатов. Это может указывать на признаки ИИ-написанного резюме или намеренного сокрытия деталей.", "Явных признаков не найдено, но отсутствие детализации вызывает вопросы."], "interview_questions": ["Опишите Ваш самый крупный опыт руководства отделом логистики: сколько человек было в подчинении, какие ключевые показатели были достигнуты?", "Приведите пример сложной ситуации при международной перевозке (например, задержка на границе, проблемы с таможней) и как Вы её решили.", "Какие логистические IT-системы Вы использовали? Дайте оценку своей экспертизе в 1C, SAP, TMS.", "Почему Вы покинули предыдущие места работы? Каких изменений ожидали?", "Как Вы оцениваете свою готовность работать в должности логиста уровня М1 (начальный руководящий уровень)? Какие зоны роста видите?"], "soft_skills_signals": ["Опыт руководства отделами и замещения директора указывает на лидерские качества.", "Разнообразие ролей (от специалиста до руководителя) предполагает адаптивность и широкий кругозор."], "interview_focus_areas": ["Уточнить конкретный опыт и обязанности на предыдущих местах работы.", "Проверить знание рынка перевозок Китай-ЕС-СНГ.", "Оценить управленческие компетенции: численность подчиненных, бюджеты, внедрение процессов.", "Запросить примеры оптимизации логистических процессов.", "Уточнить причины частой смены должностей (12 позиций за 26 лет)."], "values_fit_hypothesis": "Кандидат, вероятно, ценит профессиональное развитие в сфере логистики и готов занимать руководящие позиции. Однако без понимания корпоративной культуры компании гипотеза не может быть обоснована."}, "status": "scored", "input_hash": "e7d02a259973e7b5a71aa3b1eca0b87beb7a07b52c9906d4539db580636bfe22"}	2026-07-05 15:01:49.421	2026-07-06 05:03:57.518	{"hh_resume_id": "41652be600107f873700a886e641575462634b", "hh_negotiation_id": "5403154710"}	\N	\N	f	\N	\N	\N	\N
019f32cc-c586-7566-8b94-75ed1e04e42d	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c53f-71a9-bdd8-26b660dc737a	019e8d16-224f-77a8-b24d-4de278134fd3	screen	\N	\N	{"result": {"gaps": ["Отсутствует конкретный опыт в расширении (требование вакансии).", "Нет перечня навыков, что затрудняет оценку соответствия.", "Образование указано без степени и дат окончания, что снижает доверие.", "Не указаны достижения, метрики или результаты работы."], "model": "deepseek/deepseek-v4-flash", "summary": "Кандидат имеет 15+ лет опыта в логистике, включая роли от диспетчера до менеджера по логистике. Однако отсутствуют конкретные достижения, навыки или указание на опыт в расширении бизнеса, что требуется в вакансии. Образование неполное (без указания степени).", "red_flags": ["Резюме не содержит временных меток для каждой должности, что затрудняет проверку последовательности.", "Пустой раздел навыков — возможное упущение или попытка скрыть несоответствие."], "scored_at": "2026-07-06T05:01:12.619Z", "strengths": ["Длительный стаж в логистике (189 месяцев) позволяет предполагать глубокое понимание процессов.", "Разнообразие должностей (диспетчер, менеджер склада, специалист, ведущий специалист, менеджер по логистике) свидетельствует о карьерном росте.", "Работа в транспортной логистике может быть релевантна задачам по расширению."], "tokens_used": 1857, "competencies": {"Логистические процессы": {"score": 7, "reasoning": "Длительный опыт в разных ролях, но без подтверждения глубоких знаний."}, "Управление расширением": {"score": 3, "reasoning": "Нет явных признаков опыта в расширении; требуется уточнение на собеседовании."}, "Коммуникация и координация": {"score": 6, "reasoning": "Роли диспетчера и менеджера предполагают развитые навыки, но нет подтвер"}}, "model_version": "deepseek/deepseek-v4-flash-20260423", "schema_version": 2, "relevance_score": 65, "anti_fraud_signals": ["Резюме выглядит шаблонно: общие названия должностей без деталей, отсутствие конкретных дат и метрик.", "Нет указания на конкретные проекты или достижения, что характерно для AI-сгенерированных текстов.", "Образование: два вуза без указания факультета или специальности — возможное раздувание."], "soft_skills_signals": ["Организаторские способности (менеджер склада).", "Коммуникативные навыки (диспетчер, менеджер по логистике).", "Лидерские качества (ведущий специалист, менеджер по логистике)."], "interview_focus_areas": ["Опыт в проектах по расширению или оптимизации логистических процессов.", "Конкретные результаты и метрики на предыдущих местах работы.", "Управленческий опыт и масштаб ответственности.", "Знание современных инструментов и технологий в логистике.", "Причины перехода и ожидания от новой роли."], "values_fit_hypothesis": "Кандидат может разделять ценности, связанные с эффективностью и надёжностью в логистике, но неясно, насколько он ориентирован на инновации и расширение, что важно для данной роли."}, "status": "scored", "input_hash": "a5425c466c0964440df2126d0dced13f2151c837b735a3b68f2bccc81fb26954"}	2026-07-05 15:01:48.54	2026-07-06 05:01:12.621	{"hh_resume_id": "d3bb9777000234178800a886e66c444f683245", "hh_negotiation_id": "5397233021"}	\N	\N	f	\N	\N	\N	\N
019f32cc-cac4-7e67-821a-52e13dcf340b	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-cabd-7522-a98b-4be3f9e61347	019e8d16-224f-77a8-b24d-4de278134fd3	new	\N	\N	{"result": {"gaps": ["Полное отсутствие опыта работы в логистике, управлении цепями поставок, складском учете или транспортной логистике.", "Отсутствие в резюме упоминания каких-либо специализированных навыков или знаний в области логистики.", "Не указано образование в сфере логистики (имеется экономическое образование).", "Текущее место жительства (Кумертау) может не соответствовать требованиям к логистическим позициям, часто предполагающим работу в крупных городах или регионах."], "model": "deepseek/deepseek-v4-flash", "summary": "Кандидат имеет обширный опыт работы (более 16 лет) в различных сферах: от бухгалтерии и кредитования до административной поддержки и статистики. Прямого опыта в логистике не указано, однако есть навыки координации и работы с данными, которые могут быть полезны. Географическое расположение (Кумертау) может ограничивать возможности для работы в крупных логистических центрах.", "red_flags": ["Отсутствие информации о предыдущих версиях резюме для сравнения — невозможно оценить динамику изменений.", "Значительный стаж (195 месяцев, ~16 лет) при отсутствии прогрессии в должностях, связанных с логистикой, что может свидетельствовать о недостаточной фокусировке карьеры."], "scored_at": "2026-07-06T05:04:52.960Z", "strengths": ["Большой общий стаж работы (более 16 лет).", "Опыт работы в роли координатора и администратора, что предполагает навыки организации и контроля.", "Опыт работы со статистикой и данными (роль «Статистик»).", "Широкий кругозор благодаря работе в разных отраслях."], "tokens_used": 2908, "competencies": {"Логистика и цепи поставок": {"score": 1, "reasoning": "Нет ни одного указания на опыт, образование или навыки в данной области. Единственная возможная связь — общие координационные навыки."}, "Анализ данных и отчетность": {"score": 6, "reasoning": "Опыт работы статистиком и кредитным менеджером предполагает работу с цифрами и анализом. Однако отсутствуют детали (уровень владения Excel, BI-инструменты и т.п.)."}, "Клиентский сервис и коммуникация": {"score": 7, "reasoning": "Прямой опыт работы с клиентами на руководящих должностях. Навыки ведения переговоров и поддержки обоснованы."}}, "model_version": "deepseek/deepseek-v4-flash-20260423", "schema_version": 2, "relevance_score": 45, "suggested_grade": null, "suggested_salary": null, "anti_fraud_signals": ["Резюме выглядит шаблонно: перечислены только названия должностей и одно образование, без описания достижений, обязанностей, конкретных проектов или метрик. Это может быть признаком сокращенной или неполной версии резюме.", "Отсутствуют какие-либо конкретные данные (даты, места работы, результаты), что характерно для AI-сгенерированного или сильно схематичного резюме.", "Явных признаков мошенничества не найдено, однако информационная бедность и отсутствие деталей — серьезный повод для дополнительной проверки."], "interview_questions": ["Расскажите подробно о вашем опыте на позиции «Координатор»: какими процессами вы"], "soft_skills_signals": ["Опыт работы с клиентами («Менеджер по работе с клиентами») — навыки коммуникации и клиентоориентированности.", "Роль координатора подразумевает организаторские способности и навыки планирования.", "Управление кредитными рисками («Ведущий кредитный менеджер») — внимательность к деталям и аналитические способности."], "interview_focus_areas": ["Подробный разбор опыта работы: выяснить конкретные обязанности и достижения на каждой позиции, особенно на ролях координатора и администратора.", "Мотивация к переходу в логистику: что привлекло кандидата в этой сфере, есть ли базовые знания или пройденное обучение.", "Проверка технических навыков: знание 1С, WMS-систем, Excel на продвинутом уровне, понимание транспортной документации.", "Готовность к переезду или удаленной работе: соответствует ли локация требованиям вакансии.", "Оценка организаторских способностей: попросить привести пример успешной координации или управления процессом."], "values_fit_hypothesis": "Кандидат, вероятно, ценит стабильность и разноплановую работу, что следует из длительного опыта в разных функциях. Однако такие ценности могут не совпадать с динамичной, ориентированной на результат средой логистики, где часто требуются оперативность и готовность к изменениям."}, "status": "scored", "input_hash": "58ed876c0e610d80c20d963945ab3743660d87c0886ad84d0f2a0ceffac10f66"}	2026-07-05 15:01:49.891	2026-07-06 05:04:52.962	{"hh_resume_id": "c03c3c9b000b4957cb00a886e67869344b5653", "hh_negotiation_id": "5407960003"}	\N	\N	f	\N	\N	\N	\N
019f32cc-c686-721f-b2ed-8e74ef2a140d	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c679-7ea2-9534-0c29e5f362b4	019e8d16-224f-77a8-b24d-4de278134fd3	new	\N	\N	{"result": {"gaps": ["Навыки не указаны, что не позволяет оценить соответствие требуемым компетенциям (\\"Расширение\\")", "Отсутствует конкретная информация о достижениях, результатах работы или используемых инструментах", "Местонахождение кандидата (Орёл) может потребовать релокации или удаленной работы, что не оговорено"], "model": "deepseek/deepseek-v4-flash", "summary": "Кандидат имеет 8,9 лет опыта в логистике и снабжении, включая руководящую должность. Отсутствует информация о конкретных навыках, релевантных указанному в вакансии (\\"Расширение\\"), и деталях опыта. Требуется уточнение соответствия текущим задачам.", "red_flags": ["Ключевое требование \\"Расширение\\" не раскрыто ни в навыках, ни в описании опыта", "Предыдущие версии резюме не предоставлены, сравнение невозможно", "Отсутствие конкретики: нет дат на местах работы, названий компаний или количественных показателей"], "scored_at": "2026-07-06T05:02:12.445Z", "strengths": ["Значительный общий стаж в логистике и снабжении (8,9 лет)", "Опыт руководящей работы (руководитель отдела снабжения)", "Разнообразные должности: от кладовщика до менеджера по логистике"], "tokens_used": 1704, "competencies": {"Расширение": {"score": 2, "reasoning": "Навык не подтвержден: ни в заголовке, ни в опыте, ни в навыках нет связи с расширением бизнеса или географии."}, "Управление поставками": {"score": 5, "reasoning": "Должность 'Руководитель отдела снабжения' указывает на опыт, но без информации о масштабе и результатах уверенно оценить нельзя."}, "Логистическое планирование": {"score": 6, "reasoning": "Опыт руководства отделом снабжения и должности логиста предполагают базовые компетенции, но отсутствие деталей снижает оценку."}}, "model_version": "deepseek/deepseek-v4-flash-20260423", "schema_version": 2, "relevance_score": 30, "suggested_grade": "M1 (условно, при подтверждении опыта)", "suggested_salary": 120000, "anti_fraud_signals": ["Текст резюме крайне лаконичен, отсутствуют шаблонные фразы, но и конкретика минимальна", "Нет типичных признаков ИИ-генерации (общих формулировок, повторов, избыточности)", "Однако отсутствие навыков и деталей опыта вызывает сомнения в полноте и достоверности"], "interview_questions": ["Какие конкретные инициативы по расширению (географии, ассортимента, каналов) вы реализовывали на предыдущих местах работы?", "Опишите самый сложный проект в области логистики, который вы вели. Какую роль вы играли и какие результаты были достигнуты?", "Почему в вашем резюме не указаны навыки и конкретные даты в опыте работы?", "Как вы оцениваете свою готовность к релокации или работе в удаленном формате из Орла?", "Какие KPI вы использовали для оценки эффективности отдела снабжения?"], "soft_skills_signals": ["Возможность работы на разных позициях в цепочке поставок указывает на адаптивность", "Опыт управления отделом может свидетельствовать о лидерских качествах"], "interview_focus_areas": ["Уточнение понимания требований 'Расширение' и релевантного опыта", "Детализация конкретных проектов или инициатив по развитию/расширению", "Оценка навыков в области построения процессов и управления изменениями", "Причины перехода на новую позицию и ожидания от работы", "Обсуждение возможностей релокации или удаленной работы"], "values_fit_hypothesis": "Кандидат с долгой карьерой в логистике вероятно ценит стабильность и практический опыт, однако без уточнения конкретных ценностей (ориентация на результат, инициативность) гипотеза неоднозначна."}, "status": "scored", "input_hash": "309d2e510a7f13673c4a23037c459b9fea619691dd6c23d8d05634e64865b2d1"}	2026-07-05 15:01:48.803	2026-07-06 05:02:12.449	{"hh_resume_id": "4981fbcc0004dd6fa400a886e645704f336138", "hh_negotiation_id": "5399368144"}	\N	\N	f	\N	\N	\N	\N
019f32cc-cbab-7c65-8c5c-f4d0c15227a9	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-cb99-7fae-b716-ce019cf12390	019e8d16-224f-77a8-b24d-4de278134fd3	new	\N	\N	{"result": {"gaps": ["Не указаны конкретные навыки (skills), соответствующие требованиям вакансии.", "Отсутствует детализация опыта: не указаны обязанности, достижения, масштаб задач.", "Название должности ('Менеджер внешней логистики') не совпадает с искомой ('Логист'), хотя и близко.", "Требуемый навык 'Расширение' не отражен в резюме.", "Опыт работы учителем и менеджером по работе с иностранными клиентами может указывать на смену профиля, но не раскрыт."], "model": "deepseek/deepseek-v4-flash", "summary": "Кандидат имеет 16+ лет общего опыта, в основном в логистике и ВЭД, но название должностей не детализировано, а требуемые навыки из вакансии отсутствуют. Местоположение (Москва) совпадает, но описание опыта слишком общее, без конкретных обязанностей и достижений. Текущая вакансия требует расширения, что не раскрыто в резюме.", "red_flags": ["У кандидата есть опыт работы учителем, что может свидетельствовать о нестабильности карьеры (без дополнительных пояснений).", "Названия должностей менеджера по логистике и ВЭД повторяются, но неясно, менялись ли компании/обязанности."], "scored_at": "2026-07-06T05:05:24.403Z", "strengths": ["Значительный общий опыт в логистике и внешнеэкономической деятельности (более 16 лет).", "Последовательное развитие в сфере логистики: от ассистента до менеджера внешней логистики.", "Два высших образования, в том числе техническое."], "tokens_used": 2601, "competencies": {"Работа с документацией": {"score": 4, "reasoning": "Опыт работы в ВЭД предполагает оформление документов, но не проверено."}, "Логистическое планирование": {"score": 4, "reasoning": "Из названий должностей видно, что кандидат занимался логистикой, но нет конкретики по планированию маршрутов, управления запасами и т.п."}, "Управление проектами расширения": {"score": 1, "reasoning": "Прямых указаний на опыт расширения нет, навык отсутствует в резюме."}, "Внешнеэкономическая деятельность": {"score": 5, "reasoning": "Должность 'Менеджер по логистике и ВЭД' предполагает знание ВЭД, но без деталей сложно оценить уровень."}}, "model_version": "deepseek/deepseek-v4-flash-20260423", "schema_version": 2, "relevance_score": 30, "suggested_grade": "М1", "suggested_salary": 80000, "anti_fraud_signals": ["Резюме выглядит шаблонным: отсутствуют конкретные даты, метрики, описания обязанностей.", "Список навыков пуст, что нетипично для опытного специалиста.", "Формулировки названий должностей повторяются без деталей, что может указывать на автоматическую генерацию или небрежное составление."], "interview_questions": ["Опишите ваш типичный рабочий день на позиции менеджера внешней логистики.", "Приведите пример задачи по расширению логистической сети, в которой вы участвовали, и ваш вклад.", "С какими системами автоматизации логистики вы работали?", "Как вы контролировали соблюдение сроков поставок при работе с иностранными партнерами?", "Почему после опыта в логистике вы работали учителем? Как это повлияло на вашу карьеру?"], "soft_skills_signals": [], "interview_focus_areas": ["Уточнить конкретный опыт в расширении логистических операций.", "Проверить реальные обязанности в должности 'Менеджер внешней логистики'.", "Выяснить причины смены профиля (работа учителем).", "Запросить примеры достижений с цифрами (объем поставок, сокращение сроков, затрат).", "Оценить знание специфики ВЭД и таможенного оформления."], "values_fit_hypothesis": "Ценности компании в вакансии не указаны. Можно предположить, что кандидат ориентирован на стабильную работу в логистике, но без деталей оценить соответствие корпоративной культуре сложно."}, "status": "scored", "input_hash": "3d6d5e77b4e34c454cc56bb32a0539992cc103ea1ea0f61c21a53db9531e23ab"}	2026-07-05 15:01:50.122	2026-07-06 05:05:24.404	{"hh_resume_id": "c765fb440000ded69d00a886e6666162366250", "hh_negotiation_id": "5408712813"}	\N	\N	f	\N	\N	\N	\N
019f32cc-cc89-7ee4-abf7-f1e46231cd08	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-cc79-7352-bd17-40ba3fd57aab	019e8d16-224f-77a8-b24d-4de278134fd3	new	\N	\N	{"result": {"gaps": ["Не указаны конкретные навыки (skills) из резюме, что не позволяет оценить соответствие требуемым компетенциям.", "Описание вакансии неполное: требуемые навыки и описание указаны как \\"Расширение\\", что не позволяет провести детальное сопоставление.", "Отсутствуют достижения и количественные результаты в опыте работы."], "model": "deepseek/deepseek-v4-flash", "summary": "Кандидат имеет образование и частичный опыт в логистике, но профиль вакансии неполный, что затрудняет точную оценку. В резюме указаны должности, связанные с логистикой, однако не указаны конкретные навыки и достижения. Требования вакансии не раскрыты, что снижает релевантность оценки.", "red_flags": ["Резюме предоставлено в неполном виде: отсутствуют навыки и детали опыта, что может свидетельствовать о попытке скрыть недостающие компетенции.", "Невозможно проверить непротиворечивость с предыдущими версиями резюме, так как они не предоставлены."], "scored_at": "2026-07-06T05:06:01.648Z", "strengths": ["Наличие опыта работы в логистике более 3 лет (47 месяцев).", "Опыт работы руководителем отдела логистики и Transit Team Leader.", "Образование в Стамбульском университете (2023), что может указывать на международную компетенцию.", "Опыт работы по импортным операциям (РФ/РБ – Турция), что релевантно для логистики."], "tokens_used": 2868, "competencies": {"Управление командой": {"score": 5, "reasoning": "Должность Transit Team Leader предполагает руководство, но нет описания масштаба команды и достижений."}, "Операционная логистика": {"score": 6, "reasoning": "Есть опыт в импортных операциях и руководстве, но нет подтверждения конкретными результатами и перечнем задач."}, "Международные перевозки": {"score": 7, "reasoning": "Опыт работы с Турцией и импортными операциями подтверждает наличие компетенции, хотя глубина не раскрыта."}}, "model_version": "deepseek/deepseek-v4-flash-20260423", "schema_version": 2, "relevance_score": 40, "suggested_grade": null, "suggested_salary": null, "anti_fraud_signals": ["Использование общих фраз без конкретики (например, название должности без описания обязанностей и достижений).", "Отсутствие количественных метрик и дат (кроме годов).", "Шаблонные формулировки в названиях должностей. Явных признаков не найдено, но резюме вызывает подозрения в формальности."], "interview_questions": ["Расскажите подробнее о вашем опыте управления отделом логистики: какое количество сотрудников было в подчинении, какие KPI вы использовали?", "Какие конкретные задачи вы решали при организации импортных поставок из Турции? Приведите пример сложной ситуации и её решения.", "В резюме не указаны навыки. Какими программными продуктами и системами управления логистикой вы владеете?", "Как вы оцениваете свой уровень владения иностранными языками (особенно турецким или английским) и как это применялось в работе?", "Какие у вас ожидания по зарплате и готовы ли вы к работе, связанной с расширением логистических операций?"], "soft_skills_signals": ["Опыт руководства отделом и командой (Transit Team Leader) может указывать на лидерские качества.", "Работа с международными перевозками (Турция) предполагает кросс-культурную коммуникацию."], "interview_focus_areas": ["Уточнить конкретные обязанности и достижения на позиции руководителя отдела логистики.", "Оценить компетенции в организации импортных операций и управления командой.", "Запросить информацию о навыках работы с логистическими системами и документооборотом.", "Прояснить причину отсутствия навыков в резюме и детали опыта."], "values_fit_hypothesis": "Кандидат, вероятно, ценит профессиональное развитие и международный опыт, что подтверждается обучением в Турции. Однако неясно, насколько его ценности совпадают с целями расширения, указанными в вакансии."}, "status": "scored", "input_hash": "415932a0c45112ac7fed3e0220b25f6f7b0babd87da9754c1e4998ec6e12f0c4"}	2026-07-05 15:01:50.344	2026-07-06 05:06:01.651	{"hh_resume_id": "948b5813000fb9b4fd00a886e6474c4e7a4676", "hh_negotiation_id": "5409199991"}	\N	\N	f	\N	\N	\N	\N
019f32cc-cd74-77e2-9224-6f30bf3eb0cd	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-cd6c-71ec-b291-f1b68b25ddd9	019e8d16-224f-77a8-b24d-4de278134fd3	new	\N	\N	{"result": {"gaps": ["В резюме не указаны конкретные обязанности или достижения на предыдущих местах работы", "Отсутствует требуемый навык «Расширение» (расширение рынков или географии)", "Нет информации о владении профильными программами или знании языков"], "model": "deepseek/deepseek-v4-flash", "summary": "Кандидат имеет 8 лет опыта, преимущественно в ролях логиста и менеджера по ВЭД. Образование включает ВШЭ (2023) и более ранний вуз (2012). В резюме отсутствуют конкретные обязанности, достижения и требуемые навыки, что снижает точность оценки.", "red_flags": ["Предыдущие версии резюме не предоставлены, поэтому невозможно выявить противоречия или изменения"], "scored_at": "2026-07-06T05:06:45.534Z", "strengths": ["Релевантный опыт работы в должности логиста и менеджера по ВЭД", "Наличие высшего образования в престижном вузе (ВШЭ)", "Общий стаж более 8 лет, что свидетельствует о стабильности"], "tokens_used": 2069, "model_version": "deepseek/deepseek-v4-flash-20260423", "schema_version": 2, "relevance_score": 65, "anti_fraud_signals": ["Резюме крайне лаконично, отсутствуют конкретные даты в опыте работы, метрики и детали проектов. Возможно, это краткая скрытая форма или автосгенерированный шаблон без фактического наполнения.", "Явных признаков ИИ-написания не найдено, однако подозрение вызывает обобщенность формулировок."], "interview_questions": ["Расскажите, пожалуйста, подробнее о вашем опыте работы логистом: с какими видами транспорта и маршрутами вы имели дело?", "Приходилось ли вам участвовать в проектах по расширению рынков или поиску новых перевозчиков?", "Какие таможенные процедуры вы оформляли и с какими базами данных работали?", "Почему вы решили указать резюме без описания обязанностей? Не могли бы вы сообщить больше деталей о ваших функциях на последнем месте работы?", "Как вы оцениваете свой уровень владения английским языком и какие программы для логистики вы знаете?"], "soft_skills_signals": ["Опыт ассистента руководителя может указывать на организационные навыки и умение работать с документацией"], "interview_focus_areas": ["Уточнить конкретный опыт в логистике: какие задачи решал, какие схемы перевозок использовал", "Выяснить, работал ли кандидат с расширением географии поставок или новыми направлениями", "Проверить знание таможенного оформления и документооборота ВЭД", "Оценить уровень владения иностранными языками и транспортными программами", "Понять мотивацию к работе в Ростове-на-Дону и готовность к командировкам"], "values_fit_hypothesis": "Кандидат с опытом вспомогательных и логистических ролей, вероятно, ценит стабильность и структурированность, но отсутствие указания на инициативы по развитию может говорить о пассивной позиции."}, "status": "scored", "input_hash": "e5cff3d132d5051d958590ff0b0214eb522ee317219b4ff7ef50f9435e2b30a6"}	2026-07-05 15:01:50.579	2026-07-06 05:06:45.539	{"hh_resume_id": "70469e9f000fe04e2b00a886e6546b4952704b", "hh_negotiation_id": "5409206234"}	\N	\N	f	\N	\N	\N	\N
019f32cc-c825-7778-b131-e12c9dc892e7	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c81d-76ef-b56f-5af440fa602d	019e8d16-224f-77a8-b24d-4de278134fd3	new	\N	\N	{"result": {"gaps": ["Отсутствуют конкретные навыки и компетенции в резюме, что затрудняет оценку соответствия требованиям вакансии.", "Описание вакансии не содержит деталей (требуемые навыки указаны как \\"Расширение\\", что непонятно).", "Нет информации о знании конкретных видов транспорта, складских систем или программного обеспечения."], "model": "deepseek/deepseek-v4-flash", "summary": "Кандидат имеет 13 лет опыта в логистике, включая транспортную логистику, ВЭД и управление отделами. Однако описание вакансии практически не содержит информации о требуемых навыках и обязанностях, что затрудняет точную оценку соответствия. Указанный единственный навык \\"Расширение\\" не даёт ясного понимания профиля вакансии, поэтому оценка снижена.", "red_flags": ["В резюме не указаны предыдущие версии для сравнения, поэтому материальные противоречия не выявлены."], "scored_at": "2026-07-06T05:03:30.882Z", "strengths": ["Более 13 лет опыта работы в логистике, включая роль начальника отдела логистики.", "Опыт работы в портовой логистике (экспедитор по вывозу из портов Новороссийска) — релевантно для Новороссийска.", "Управленческий опыт: начальник отдела логистики, начальник договорного отдела."], "tokens_used": 2549, "competencies": {"Транспортная логистика и ВЭД": {"score": 6, "reasoning": "Есть релевантный опыт, но отсутствие деталей снижает уверенность в глубине экспертизы."}, "Договорная и коммерческая работа": {"score": 7, "reasoning": "Опыт в договорном отделе и коммерческой деятельности — явные сигналы."}, "Управление логистическими процессами": {"score": 7, "reasoning": "Длительный опыт в логистике, включая руководящие должности, но без конкретных примеров масштаба и результатов."}}, "model_version": "deepseek/deepseek-v4-flash-20260423", "schema_version": 2, "relevance_score": 40, "suggested_grade": "M1", "suggested_salary": null, "anti_fraud_signals": ["Резюме написано лаконично, но отсутствие конкретных дат, метрик и навыков может указывать на шаблонный характер или неполноту.", "Общие формулировки должностей без описания обязанностей и достижений снижают доверие.", "Явных признаков AI-написанности не найдено."], "interview_questions": ["Опишите ваш самый значимый проект по оптимизации транспортной логистики или ВЭД. Какие результаты были достигнуты?", "С какими видами транспорта вы работали наиболее часто и в каком объёме?", "Какие критерии вы использовали при выборе перевозчиков или партнёров по ВЭД?", "Как вы оцениваете свой уровень владения 1С и другими логистическими программами?", "Приходилось ли вам внедрять или настраивать процессы с нуля? Расскажите о таком опыте."], "soft_skills_signals": ["Опыт руководства отделами указывает на лидерские качества и организационные способности.", "Работа в коммерческой деятельности и договорном отделе говорит о навыках переговоров и ведения документации."], "interview_focus_areas": ["Уточнить, какие именно навыки и обязанности подразумевает вакансия, поскольку описание неполное.", "Оценить опыт в ВЭД и знание таможенных процедур.", "Проверить управленческие достижения: размер команды, проекты по оптимизации.", "Выяснить, какие технологии или системы использовались (TMS, WMS, 1C и т.д.).", "Обсудить опыт организации перевозок через порты Новороссийска."], "values_fit_hypothesis": "Кандидат, вероятно, разделяет ценности структурированности и ответственности, так как имеет опыт управления и договорной работы. Возможно, он ориентирован на стабильность и расширение зоны ответственности."}, "status": "scored", "input_hash": "7d1ac1d80096e7908249fca9fa2aba8e6b087cb7e8f0e3768bc13688edfa539b"}	2026-07-05 15:01:49.219	2026-07-06 05:03:30.883	{"hh_resume_id": "fa3f615b000e03341d00a886e643517a48754d", "hh_negotiation_id": "5402829495"}	\N	[{"question": "В связи с планами расширения компании, какие шаги вы предприняли бы для масштабирования текущих логистических процессов, учитывая ваш опыт работы в портовой логистике Новороссийска?", "rationale": "Этот вопрос позволяет оценить способность кандидата разрабатывать стратегию масштабирования и адаптировать логистику к росту, что критически важно для этапа расширения.", "competency": "Стратегическое мышление и масштабирование"}, {"question": "Приведите пример из вашего опыта, когда вы успешно оптимизировали транспортные или складские процессы в условиях быстрого роста объёмов. Какие инструменты и метрики вы использовали?", "rationale": "Вопрос направлен на выявление практического опыта оптимизации в условиях роста, что напрямую связано с задачей расширения.", "competency": "Оптимизация процессов"}, {"question": "Как вы выстраиваете коммуникацию с таможенными органами и перевозчиками при изменении объёмов поставок? Расскажите о ваших подходах к управлению взаимоотношениями в портовой зоне.", "rationale": "Поскольку работа предполагает взаимодействие с портовой инфраструктурой и ВЭД, важно оценить знание специфики и навыки управления внешними контактами.", "competency": "Знание ВЭД и портовой логистики"}, {"question": "Какие вы видите основные риски при расширении логистических операций и как вы предлагаете их минимизировать, опираясь на ваш многолетний опыт?", "rationale": "Компетенция управления рисками особенно важна при расширении, когда нагрузка на процессы возрастает.", "competency": "Управление рисками"}]	f	\N	\N	\N	\N
019f32cc-c9cd-7c50-a956-3cb98e64e5f3	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c9b8-773a-a7f3-20ca9ff772de	019e8d16-224f-77a8-b24d-4de278134fd3	new	\N	\N	{"result": {"gaps": ["Отсутствие опыта работы в логистике или смежных областях.", "В резюме не указаны навыки, ключевые для логиста (управление цепочками поставок, работа с перевозчиками, знание таможни и т.д.).", "Не указано, как именно кандидат применял навык 'Расширение' в своей карьере."], "model": "deepseek/deepseek-v4-flash", "summary": "Кандидат имеет значительный опыт работы на руководящих должностях и в экономическом анализе, однако его образование и навыки не соответствуют требованиям вакансии 'Логист'. В резюме отсутствуют сведения о релевантном опыте в логистике, а требуемый навык 'Расширение' не раскрыт. Кандидат находится в Брянске, что может быть удалённым расположением для работодателя.", "red_flags": ["Ключевой требуемый навык 'Расширение' никак не подтверждён в резюме.", "Все позиции, кроме последней, датированы периодом до 2004 года, что может указывать на неполноту данных.", "Предыдущие версии резюме не предоставлены, поэтому невозможно выявить противоречия."], "scored_at": "2026-07-06T05:04:22.772Z", "strengths": ["Более 10 лет опыта работы на руководящих позициях (директор филиала).", "Наличие экономического образования и опыта работы экономистом.", "Длительный общий стаж работы (около 24 лет), что указывает на стабильность."], "tokens_used": 2182, "competencies": {"Навык 'Расширение'": {"score": 2, "reasoning": "Навык не раскрыт, нет примеров реализации."}, "Управление процессами": {"score": 5, "reasoning": "Опыт директора филиала предполагает управленческие навыки, но не в контексте логистики."}, "Знание транспортной логистики": {"score": 1, "reasoning": "В резюме нет упоминаний работы с транспортом, перевозками, цепочками поставок."}}, "model_version": "deepseek/deepseek-v4-flash-20260423", "schema_version": 2, "relevance_score": 25, "suggested_grade": null, "suggested_salary": null, "anti_fraud_signals": ["Резюме не содержит конкретных дат работы на последних позициях, что снижает доверие к хронологии.", "Список навыков пуст — это нетипично для хорошо составленного резюме.", "Отсутствуют метрики достижений и количественные результаты работы."], "interview_questions": ["Расскажите о вашем опыте в логистике или управлении цепочками поставок. Были ли у вас проекты, требующие организации перевозок?", "В вакансии указан навык 'Расширение'. Приведите конкретный пример из вашей работы, где вы способствовали расширению деятельности компании.", "Почему вы решили перейти в логистику, имея опыт в управлении и экономике?", "Как вы оцениваете свои знания в области складского учёта или таможенного оформления?", "Как вы строите коммуникацию с подрядчиками и контролируете выполнение KPI?"], "soft_skills_signals": ["Опыт руководства филиалом предполагает лидерские качества и навыки принятия решений.", "Работа на разных должностях (от инженера-аналитика до директора) указывает на адаптивность и широкий кругозор."], "interview_focus_areas": ["Проверить понимание основ логистики и цепочек поставок.", "Оценить готовность к переходу из управленческой роли в более операционную.", "Запросить примеры проектов, связанных с расширением (если таковые были).", "Уточнить причины смены карьерного направления."], "values_fit_hypothesis": "Кандидат, вероятно, ценит стабильность и карьерный рост, что проявляется в долгой работе в одной сфере. Однако его ценности могут не совпадать с динамичной, операционной спецификой логистики."}, "status": "scored", "input_hash": "f67317a345eda2addcf833fd68f8184f9f70625b33981352a61a7cfca7af2b83"}	2026-07-05 15:01:49.643	2026-07-06 05:04:22.773	{"hh_resume_id": "bd6a3dc20007212d8d00a886e662655a337365", "hh_negotiation_id": "5403413373"}	\N	\N	f	\N	\N	\N	\N
\.


--
-- Data for Name: assessment_answers; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.assessment_answers (id, session_id, question_id, answer, ai_grade, created_at) FROM stdin;
\.


--
-- Data for Name: assessment_questions; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.assessment_questions (id, template_id, question_order, type, prompt, options, rubric, competency, weight, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: assessment_sessions; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.assessment_sessions (id, tenant_id, template_id, application_id, invite_token, status, consent_recorded, started_at, submitted_at, trust_score, trust_signals, created_at) FROM stdin;
\.


--
-- Data for Name: assessment_templates; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.assessment_templates (id, tenant_id, vacancy_id, title, description, time_limit_min, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.audit_events (id, tenant_id, actor_user_id, action, entity_type, entity_id, diff, ip, user_agent, created_at) FROM stdin;
019e8d14-53bb-7c03-b847-41399e650b1c	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	org_unit.create	OrgUnit	019e8d14-53b6-7e8d-8b82-0ecc4c788206	{"name": "Тихоокеанская звезда"}	89.58.26.124	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 10:43:00.153
019e8d15-f693-71e5-ad95-2cfd4dd9fdd0	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	requisition.create	HiringRequisition	019e8d15-f68a-7485-b1d2-a43c965dfc1f	{"grade": "М1", "title": "Логист", "currency": "RUB", "orgUnitId": "019e8d14-53b6-7e8d-8b82-0ecc4c788206", "salaryMax": 300000, "salaryMin": 80000, "deadlineAt": "2026-06-30T00:00:00.000Z", "justification": "Расширение "}	89.58.26.124	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 10:44:47.378
019e8d16-0656-7f58-8d67-f8ffb6fcb287	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	requisition.transition	HiringRequisition	019e8d15-f68a-7485-b1d2-a43c965dfc1f	{"to": "submitted", "from": "draft", "actorUserId": "019e72e8-735d-7c54-b229-08222aa2c6ca"}	89.58.26.124	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 10:44:51.412
019e8d16-10e2-7ed8-a71b-432d5ee2a41a	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	requisition.transition	HiringRequisition	019e8d15-f68a-7485-b1d2-a43c965dfc1f	{"to": "manager_approved", "from": "submitted", "actorUserId": "019e72e8-735d-7c54-b229-08222aa2c6ca"}	89.58.26.124	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 10:44:54.112
019e8d16-184a-73eb-974d-eeabfa4cefa9	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	requisition.transition	HiringRequisition	019e8d15-f68a-7485-b1d2-a43c965dfc1f	{"to": "hr_approved", "from": "manager_approved", "actorUserId": "019e72e8-735d-7c54-b229-08222aa2c6ca"}	89.58.26.124	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 10:44:56.009
019e8d16-2254-7486-b42b-b18588b53dca	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	requisition.transition	HiringRequisition	019e8d15-f68a-7485-b1d2-a43c965dfc1f	{"to": "approved", "from": "hr_approved", "actorUserId": "019e72e8-735d-7c54-b229-08222aa2c6ca"}	89.58.26.124	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 10:44:58.579
019e8d16-298d-74df-9c21-672f281170bd	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	requisition.transition	HiringRequisition	019e8d15-f68a-7485-b1d2-a43c965dfc1f	{"to": "in_recruitment", "from": "approved", "actorUserId": "019e72e8-735d-7c54-b229-08222aa2c6ca"}	89.58.26.124	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 10:45:00.427
019e8d16-5b32-7ced-baad-64a0435446df	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	vacancy.publish	Vacancy	019e8d16-224f-77a8-b24d-4de278134fd3	{"isPublished": true}	89.58.26.124	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 10:45:13.136
019e8d16-694c-7f87-98af-51f231617776	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	vacancy.publish	Vacancy	019e8d16-224f-77a8-b24d-4de278134fd3	{"isPublished": false}	89.58.26.124	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-03 10:45:16.746
019e968b-70de-73db-adad-e7accf5b0472	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	vacancy.publish	Vacancy	019e8d16-224f-77a8-b24d-4de278134fd3	{"isPublished": true}	152.53.211.221	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-05 06:49:41.337
019e968b-7b2f-77d7-b959-7400c904c59d	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	vacancy.publish	Vacancy	019e8d16-224f-77a8-b24d-4de278134fd3	{"isPublished": false}	152.53.211.221	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	2026-06-05 06:49:43.981
019e9aa8-9989-738c-948f-ee35f34caa29	019e72e8-7296-7d04-86de-6766827d80f8	\N	data_retention.run	Tenant	019e72e8-7296-7d04-86de-6766827d80f8	{"runAt": "2026-06-06T02:00:01.140Z", "processedResumes": 0, "processedEmployees": 0, "processedCandidates": 0, "processedApplications": 0}	\N	\N	2026-06-06 02:00:01.157
019f1b67-9375-789c-a1fc-d17721ea0006	019e72e8-7296-7d04-86de-6766827d80f8	\N	data_retention.run	Tenant	019e72e8-7296-7d04-86de-6766827d80f8	{"runAt": "2026-07-01T02:00:00.613Z", "processedResumes": 0, "processedEmployees": 0, "processedCandidates": 0, "processedApplications": 0}	\N	\N	2026-07-01 02:00:00.625
019f32c6-86c8-7cad-9217-dab7a7bab218	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	vacancy.publish	Vacancy	019e8d16-224f-77a8-b24d-4de278134fd3	{"isPublished": true}	152.53.179.214	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-07-05 14:54:59.262
019f32cc-c419-74c5-a67f-4ec0d776dada	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-c3eb-7fa9-a694-bd52a1884a27	{"hh_resume_id": "720ba0a3000984305400a886e6626439556c77", "hh_negotiation_id": "5390276569"}	\N	\N	2026-07-05 15:01:48.183
019f32cc-c591-72f0-ad5a-3e959cf818b7	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-c53f-71a9-bdd8-26b660dc737a	{"hh_resume_id": "d3bb9777000234178800a886e66c444f683245", "hh_negotiation_id": "5397233021"}	\N	\N	2026-07-05 15:01:48.559
019f32cc-c68f-7a2f-9032-a57cd62a0450	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-c679-7ea2-9534-0c29e5f362b4	{"hh_resume_id": "4981fbcc0004dd6fa400a886e645704f336138", "hh_negotiation_id": "5399368144"}	\N	\N	2026-07-05 15:01:48.812
019f32cc-c761-7713-aa8b-cd6cb348dc9c	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-c751-72d0-93db-2f7c59349d4f	{"hh_resume_id": "1dd9f114000992d3e100a886e6643645644a37", "hh_negotiation_id": "5400900869"}	\N	\N	2026-07-05 15:01:49.023
019f32cc-c827-77ae-a9cd-6e8e28f861f2	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-c81d-76ef-b56f-5af440fa602d	{"hh_resume_id": "fa3f615b000e03341d00a886e643517a48754d", "hh_negotiation_id": "5402829495"}	\N	\N	2026-07-05 15:01:49.222
019f32cc-c8f0-7fd0-b5f4-133cebe5e1d0	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-c8e8-79b5-b6cd-5a1fa6c7a877	{"hh_resume_id": "41652be600107f873700a886e641575462634b", "hh_negotiation_id": "5403154710"}	\N	\N	2026-07-05 15:01:49.423
019f32cc-c9cf-7071-89f4-5c99c334dd59	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-c9b8-773a-a7f3-20ca9ff772de	{"hh_resume_id": "bd6a3dc20007212d8d00a886e662655a337365", "hh_negotiation_id": "5403413373"}	\N	\N	2026-07-05 15:01:49.646
019f32cc-cac9-79a0-b195-877a84774044	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-cabd-7522-a98b-4be3f9e61347	{"hh_resume_id": "c03c3c9b000b4957cb00a886e67869344b5653", "hh_negotiation_id": "5407960003"}	\N	\N	2026-07-05 15:01:49.896
019f32cc-cbbc-7fa9-89d3-079f3a32afb3	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-cb99-7fae-b716-ce019cf12390	{"hh_resume_id": "c765fb440000ded69d00a886e6666162366250", "hh_negotiation_id": "5408712813"}	\N	\N	2026-07-05 15:01:50.139
019f32cc-cc8d-75bf-92dd-f0a4e2bd92e9	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-cc79-7352-bd17-40ba3fd57aab	{"hh_resume_id": "948b5813000fb9b4fd00a886e6474c4e7a4676", "hh_negotiation_id": "5409199991"}	\N	\N	2026-07-05 15:01:50.348
019f32cc-cd77-700c-a2a8-c6c944018405	019e72e8-7296-7d04-86de-6766827d80f8	\N	hh.sync.candidate_imported	Candidate	019f32cc-cd6c-71ec-b291-f1b68b25ddd9	{"hh_resume_id": "70469e9f000fe04e2b00a886e6546b4952704b", "hh_negotiation_id": "5409206234"}	\N	\N	2026-07-05 15:01:50.583
019f32ce-2bff-7e6f-8f2e-c813169e932e	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.rescore_requested	Application	019f32cc-cd74-77e2-9224-6f30bf3eb0cd	{"queued": true, "reason": null}	152.53.179.214	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-07-05 15:03:20.316
019f32d1-4f13-7da0-bfc4-e3b3300733c0	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.score_feedback	Application	019f32cc-c40d-773f-9c71-e1a661d3e493	{"agrees": true, "has_note": false}	152.53.179.214	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	2026-07-05 15:06:45.901
019f32d9-eafd-795f-ab2f-c7274e0bdcaf	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c40d-773f-9c71-e1a661d3e493	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 45}	\N	\N	2026-07-05 15:16:10.098
019f32da-259e-7eda-863e-530e24763315	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c586-7566-8b94-75ed1e04e42d	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 75}	\N	\N	2026-07-05 15:16:25.113
019f32da-8b3d-7b8f-af21-54fe0c800dcf	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c686-721f-b2ed-8e74ef2a140d	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 40}	\N	\N	2026-07-05 15:16:51.129
019f32da-b35c-7651-803d-bf090877fb9e	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 85}	\N	\N	2026-07-05 15:17:01.398
019f32db-123d-703f-abf7-ae5646938065	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 65}	\N	\N	2026-07-05 15:17:25.688
019f32db-d6f1-76f4-84e6-9dc16111c5c1	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c8ee-744e-a7a6-812dbd88314f	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 60}	\N	\N	2026-07-05 15:18:16.044
019f32dc-2ee6-7b72-87e6-02cb73ac79dd	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c9cd-7c50-a956-3cb98e64e5f3	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 20}	\N	\N	2026-07-05 15:18:38.56
019f32dc-a725-769b-8010-88be02d2f2fd	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cac4-7e67-821a-52e13dcf340b	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 15}	\N	\N	2026-07-05 15:19:09.343
019f32dd-3a49-73c4-90a0-57a18636d87f	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cbab-7c65-8c5c-f4d0c15227a9	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 65}	\N	\N	2026-07-05 15:19:47.014
019f32dd-affb-7bed-addb-18da282a100b	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cc89-7ee4-abf7-f1e46231cd08	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 65}	\N	\N	2026-07-05 15:20:17.144
019f32de-9878-7697-838e-a44b2d60be8f	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cd74-77e2-9224-6f30bf3eb0cd	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 60}	\N	\N	2026-07-05 15:21:16.661
019f3562-88f5-71c8-9ed4-fe78f8a0cf76	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	application.auto_screened	Application	019f32cc-c586-7566-8b94-75ed1e04e42d	{"to": "screen", "from": "new", "threshold": 70, "relevance_score": 75}	\N	\N	2026-07-06 03:04:37.856
019f3562-88f6-72d2-90fb-fda4a3b19ef0	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	application.auto_screened	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"to": "screen", "from": "new", "threshold": 70, "relevance_score": 85}	\N	\N	2026-07-06 03:04:37.856
019f3574-ae53-77b7-8a23-c441dae8b048	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c40d-773f-9c71-e1a661d3e493	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 65}	\N	\N	2026-07-06 03:24:27.084
019f3574-d866-77b2-979b-8bec77e88221	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c586-7566-8b94-75ed1e04e42d	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 85}	\N	\N	2026-07-06 03:24:37.857
019f3575-543c-71be-ad70-dbfad273a58d	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c686-721f-b2ed-8e74ef2a140d	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 65}	\N	\N	2026-07-06 03:25:09.558
019f3575-fda3-747e-a930-855a2cf80db2	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 70}	\N	\N	2026-07-06 03:25:52.925
019f3576-9086-7851-8fdc-d8807d98864d	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c8ee-744e-a7a6-812dbd88314f	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 85}	\N	\N	2026-07-06 03:26:30.53
019f3576-90b1-7e18-b864-b9335e5ac48d	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	application.auto_screened	Application	019f32cc-c8ee-744e-a7a6-812dbd88314f	{"to": "screen", "from": "new", "threshold": 70, "relevance_score": 85}	\N	\N	2026-07-06 03:26:30.57
019f3576-d7d4-7c02-b208-4856d989d49a	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c9cd-7c50-a956-3cb98e64e5f3	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 25}	\N	\N	2026-07-06 03:26:48.785
019f3577-3a17-76e5-921a-d7583f9bbdd2	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cac4-7e67-821a-52e13dcf340b	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 45}	\N	\N	2026-07-06 03:27:13.94
019f3577-c215-7ce7-896b-04acdc0fc357	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.rescore_requested	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"queued": true, "reason": null}	89.58.27.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-06 03:27:48.749
019f3578-3181-7ff5-9fc8-1a0967e5a9d4	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cbab-7c65-8c5c-f4d0c15227a9	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 65}	\N	\N	2026-07-06 03:28:17.276
019f3578-7eb2-7b6f-aeef-69bc175673f4	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.score_feedback	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"agrees": true, "has_note": false}	89.58.27.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-06 03:28:37.034
019f3578-92d9-79a2-b622-54ddd1410f67	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.score_feedback	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"agrees": false, "has_note": false}	89.58.27.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-06 03:28:42.2
019f3579-31d9-7fb1-a146-a5516aeb61b1	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cc89-7ee4-abf7-f1e46231cd08	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 45}	\N	\N	2026-07-06 03:29:22.901
019f3579-5c95-7a9a-8111-477a7c8e7ea1	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cd74-77e2-9224-6f30bf3eb0cd	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 65}	\N	\N	2026-07-06 03:29:33.841
019f3579-9fbe-70fc-8e78-807f2ad660bf	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.rescore_requested	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"queued": true, "reason": null}	89.58.27.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-06 03:29:51.015
019f3579-c998-7edd-9b5e-ec6d1cf35538	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.ai_scored	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 80}	\N	\N	2026-07-06 03:30:01.751
019f3579-ca00-7279-91fb-bc063bbe79ca	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.auto_screened	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"to": "screen", "from": "new", "threshold": 70, "relevance_score": 80}	\N	\N	2026-07-06 03:30:01.855
019f3579-f345-7c3b-b21d-3b1be76964f7	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 60}	\N	\N	2026-07-06 03:30:12.414
019f357c-c9c7-7840-9c59-b1d90b45ef59	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	interview.create	Interview	019f357c-c9b6-755d-8c3b-7aec84e5a71c	{"applicationId": "019f32cc-c8ee-744e-a7a6-812dbd88314f"}	89.58.27.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-06 03:33:18.401
019f357d-09af-78be-8000-1fb3e7a2e2fa	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	interview.consent_updated	Interview	019f357c-c9b6-755d-8c3b-7aec84e5a71c	{"consentRecorded": true}	89.58.27.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-06 03:33:34.753
019f3589-dd70-7a71-b499-bd9adc016d04	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	application.questions_generated	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"count": 5}	\N	\N	2026-07-06 03:47:35.394
019f35c2-64bb-7c93-9564-68d674fd0039	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.questions_generated	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"count": 4}	\N	\N	2026-07-06 04:49:20.056
019f35c2-64c9-76d5-a6ee-e332afa68caa	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.questions_generated	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"count": 4}	89.58.26.124	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-06 04:49:20.069
019f35cb-86c8-7aaa-992d-2b15419d278b	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.move_stage	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"to": "new", "from": "screen", "actorUserId": "019f324a-0df9-7a4a-835a-f6f742e2d659"}	152.53.116.61	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-06 04:59:18.592
019f35cd-1502-752f-aac4-d93ffb87cd16	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c40d-773f-9c71-e1a661d3e493	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 70}	\N	\N	2026-07-06 05:01:00.542
019f35cd-1548-700d-836a-ed06fa802042	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	application.auto_screened	Application	019f32cc-c40d-773f-9c71-e1a661d3e493	{"to": "screen", "from": "new", "threshold": 70, "relevance_score": 70}	\N	\N	2026-07-06 05:01:00.615
019f35cd-443e-76a3-99e4-1f5987cc308c	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c586-7566-8b94-75ed1e04e42d	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 65}	\N	\N	2026-07-06 05:01:12.635
019f35ce-2df1-7dfd-b46b-68a388290ece	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c686-721f-b2ed-8e74ef2a140d	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 30}	\N	\N	2026-07-06 05:02:12.462
019f35cf-19bb-7e4c-ac6e-65de5c0ecc88	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 65}	\N	\N	2026-07-06 05:03:12.824
019f35cf-6059-77f5-b701-023033403682	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c825-7778-b131-e12c9dc892e7	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 40}	\N	\N	2026-07-06 05:03:30.898
019f35cf-c836-79f8-aceb-5dcffe28248f	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c8ee-744e-a7a6-812dbd88314f	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 0}	\N	\N	2026-07-06 05:03:57.489
019f35cf-c855-7eb0-9d57-cfc5a2957424	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	application.auto_returned_to_new	Application	019f32cc-c8ee-744e-a7a6-812dbd88314f	{"to": "new", "from": "screen", "threshold": 60, "relevance_score": 0}	\N	\N	2026-07-06 05:03:57.524
019f35d0-2b08-7a46-b37d-d021f658cfb3	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-c9cd-7c50-a956-3cb98e64e5f3	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 25}	\N	\N	2026-07-06 05:04:22.789
019f35d0-a0f4-77ca-9c4d-e488e9ad2899	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cac4-7e67-821a-52e13dcf340b	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 45}	\N	\N	2026-07-06 05:04:52.975
019f35d1-1bc5-7de5-828c-b2b3ce645833	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cbab-7c65-8c5c-f4d0c15227a9	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 30}	\N	\N	2026-07-06 05:05:24.418
019f35d1-ad4a-7ce1-acfb-f3e6424e3f58	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cc89-7ee4-abf7-f1e46231cd08	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 40}	\N	\N	2026-07-06 05:06:01.67
019f35d2-58bd-7567-a40b-722359bd6f9a	019e72e8-7296-7d04-86de-6766827d80f8	\N	application.ai_scored	Application	019f32cc-cd74-77e2-9224-6f30bf3eb0cd	{"model": "deepseek/deepseek-v4-flash", "status": "scored", "relevance_score": 65}	\N	\N	2026-07-06 05:06:45.56
019f39e5-a481-7d07-a9e6-b7d16f16d4b8	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.rescore_requested	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"queued": true, "reason": null}	89.58.27.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-07 00:06:18.985
019f39eb-a938-78b6-a0c1-52aee2229de2	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.rescore_requested	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"queued": true, "reason": null}	89.58.27.15	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-07 00:12:53.406
019f39f3-0333-7402-b5e1-912e22656187	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.rescore_requested	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"queued": true, "reason": null}	152.53.177.125	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-07 00:20:55.215
019f39ff-9023-7d48-b3a0-6ac2b0d5caa5	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.rescore_requested	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"queued": true, "reason": null}	152.53.106.220	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-07 00:34:37.72
019f3a0c-28d8-79d9-94c1-4de8177352da	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.rescore_requested	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"queued": true, "reason": null}	159.195.140.30	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-07 00:48:23.236
019f3a0d-016b-7bc1-9bb7-c6db4bd5fe59	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	application.rescore_requested	Application	019f32cc-c75b-7fc6-a540-cb753cc79f62	{"queued": true, "reason": null}	159.195.140.30	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	2026-07-07 00:49:18.659
019f3a0d-7d5a-7bab-a308-cf7c15f0fcb8	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "db:ping", "startedAt": "2026-07-07T00:49:50.181Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 00:49:50.421
019f3a0d-7d65-7c2a-8a0f-e0295069a73a	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "db:ping", "startedAt": "2026-07-07T00:49:50.181Z", "durationMs": 252, "finishedAt": "2026-07-07T00:49:50.433Z"}	\N	\N	2026-07-07 00:49:50.435
019f3a14-51c3-7e45-9368-4eaf2ac6c3ea	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T00:57:17.752Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 00:57:18.008
019f3a14-51d6-730f-9f60-0a6be82b2f08	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T00:57:17.752Z", "durationMs": 282, "finishedAt": "2026-07-07T00:57:18.034Z"}	\N	\N	2026-07-07 00:57:18.037
019f3a16-e592-7111-9c2b-545e35819099	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T01:00:06.628Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 01:00:06.924
019f3a16-e5a6-732d-be02-e7adef79c27a	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T01:00:06.628Z", "durationMs": 316, "finishedAt": "2026-07-07T01:00:06.944Z"}	\N	\N	2026-07-07 01:00:06.948
019f3a1b-4f8b-7111-a805-854572058998	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "selection.evaluate.recover", "startedAt": "2026-07-07T01:04:55.923Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 01:04:56.194
019f3a1b-4fb3-73b1-ad96-c9bd8ed0e493	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "selection.evaluate.recover", "startedAt": "2026-07-07T01:04:55.923Z", "durationMs": 316, "finishedAt": "2026-07-07T01:04:56.239Z"}	\N	\N	2026-07-07 01:04:56.242
019f3a1b-91c8-74b3-91e9-7223692e37aa	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "selection.evaluate.recover", "startedAt": "2026-07-07T01:05:12.894Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 01:05:13.155
019f3a1b-91e2-7455-8240-5cc119b3a299	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "selection.evaluate.recover", "startedAt": "2026-07-07T01:05:12.894Z", "durationMs": 286, "finishedAt": "2026-07-07T01:05:13.180Z"}	\N	\N	2026-07-07 01:05:13.183
019f3a23-9d5a-72ff-b7f9-2abf6fb89665	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T01:13:59.949Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 01:14:00.387
019f3a23-9d7e-791f-98e4-fee14bf45704	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T01:13:59.949Z", "durationMs": 493, "finishedAt": "2026-07-07T01:14:00.442Z"}	\N	\N	2026-07-07 01:14:00.444
019f3a24-a9bc-7b35-93f9-35c0d5a9cb84	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "selection.evaluate.recover", "startedAt": "2026-07-07T01:15:08.701Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 01:15:09.108
019f3a24-a9f1-7223-a111-d4ba92f48e7e	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "selection.evaluate.recover", "startedAt": "2026-07-07T01:15:08.701Z", "durationMs": 460, "finishedAt": "2026-07-07T01:15:09.161Z"}	\N	\N	2026-07-07 01:15:09.168
019f3a24-aa50-76ca-b738-50acd0c977c4	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T01:15:08.739Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 01:15:09.257
019f3a24-aa70-74a1-96fb-a9cc1a1f3cb3	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T01:15:08.739Z", "durationMs": 553, "finishedAt": "2026-07-07T01:15:09.292Z"}	\N	\N	2026-07-07 01:15:09.294
019f3a32-6681-7fcb-bdb9-12d91931d05a	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T01:30:08.949Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 01:30:09.396
019f3a32-668c-7a00-b6c7-71f4a8ad589a	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "selection.evaluate.recover", "startedAt": "2026-07-07T01:30:08.881Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 01:30:09.411
019f3a32-66a0-7fb1-9ab5-d27181a103a9	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T01:30:08.949Z", "durationMs": 485, "finishedAt": "2026-07-07T01:30:09.434Z"}	\N	\N	2026-07-07 01:30:09.438
019f3a32-66b5-7034-b100-1f01e445e25b	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "selection.evaluate.recover", "startedAt": "2026-07-07T01:30:08.881Z", "durationMs": 575, "finishedAt": "2026-07-07T01:30:09.456Z"}	\N	\N	2026-07-07 01:30:09.46
019f3a40-204f-79f3-aba6-a39ef9d28f8c	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "selection.evaluate.recover", "startedAt": "2026-07-07T01:45:08.519Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 01:45:08.939
019f3a40-2075-713e-b5c7-27d34d08a0d8	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "selection.evaluate.recover", "startedAt": "2026-07-07T01:45:08.519Z", "durationMs": 458, "finishedAt": "2026-07-07T01:45:08.977Z"}	\N	\N	2026-07-07 01:45:08.98
019f3a40-20cf-740c-9b8d-136f8581e624	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_started	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "running", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T01:45:08.681Z", "durationMs": null, "finishedAt": null}	\N	\N	2026-07-07 01:45:09.064
019f3a40-20df-7f98-ba71-afb78014fd82	019e72e8-7296-7d04-86de-6766827d80f8	\N	cron.job_succeeded	CronJob	019e72e8-7296-7d04-86de-6766827d80f8	{"error": null, "status": "succeeded", "jobName": "application.ai_scoring.recover", "startedAt": "2026-07-07T01:45:08.681Z", "durationMs": 401, "finishedAt": "2026-07-07T01:45:09.082Z"}	\N	\N	2026-07-07 01:45:09.086
\.


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.auth_sessions (id, user_id, refresh_token_hash, expires_at, revoked_at, user_agent, ip_address, created_at, updated_at) FROM stdin;
019e72f0-cd45-7f43-83a3-290d75394c13	019e72e8-735d-7c54-b229-08222aa2c6ca	ed4d40dc394eb4604aeab8cefc3ab06feaffa8ef7b1f2c5bb1c910293fd85693	2026-06-28 08:54:04.337	\N	curl/8.5.0	186.246.6.171	2026-05-29 08:54:04.35	2026-05-29 08:54:04.35
019e7304-c952-720f-ade2-af3a569f2b18	019e72e8-735d-7c54-b229-08222aa2c6ca	74d28815dcdea5e0778dda28b70e00ca031c3f5cc2695b49240142832129b4ab	2026-06-28 09:15:54.054	2026-05-29 10:26:57.952	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-05-29 09:15:54.056	2026-05-29 10:26:58.039
019e7345-d980-718b-b62b-e5d3f8f8aeba	019e72e8-735d-7c54-b229-08222aa2c6ca	c81a8cdd2783e2dc2bdd23fa1ef3ef27500427d6e2d7b42dc889017442478372	2026-06-28 10:26:58.021	2026-05-29 10:42:03.985	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-05-29 10:26:58.043	2026-05-29 10:42:04.009
019e7353-ac71-77a6-bfb5-f01c5d2b060f	019e72e8-735d-7c54-b229-08222aa2c6ca	4e3edf805d97074b8f1e0ab356f895980ed933551b6975230757d83ae837c1bd	2026-06-28 10:42:04.006	2026-05-29 10:43:42.211	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-05-29 10:42:04.013	2026-05-29 10:43:42.231
019e7355-2c1c-757e-b026-e30911df97fc	019e72e8-735d-7c54-b229-08222aa2c6ca	cab4c8065e71d187acdc5732fcbcb0e35c3a7c044f64b72a940988f5e946464c	2026-06-28 10:43:42.225	2026-05-29 11:04:26.994	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-05-29 10:43:42.234	2026-05-29 11:04:27.029
019e7368-2a9b-7aad-859b-ee3f5d2f31c1	019e72e8-735d-7c54-b229-08222aa2c6ca	a4f2bad6b91f35d8d5bacfde2da6ce51fd462dcbd1a6cdcd18968833b531495b	2026-06-28 11:04:27.024	2026-05-29 11:11:04.504	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-05-29 11:04:27.032	2026-05-29 11:11:04.513
019e736e-3b4d-7e67-b4b8-7a52d7dcb585	019e72e8-735d-7c54-b229-08222aa2c6ca	bdebd1887bfd84ccd620d5aceffe9319cb0119bda9f293d303621662afd43423	2026-06-28 11:11:04.51	2026-05-29 11:14:41.502	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-05-29 11:11:04.516	2026-05-29 11:14:41.508
019e7371-8ae9-7033-9573-6b8d13c012b4	019e72e8-735d-7c54-b229-08222aa2c6ca	ce6eacbe1ad476a9e85f41aa4df98fa06a5b0cc72d54c9382804c41a772e6811	2026-06-28 11:14:41.506	2026-05-29 11:17:25.851	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-05-29 11:14:41.51	2026-05-29 11:17:25.889
019e7374-0d08-7f81-90b3-3d6e56cb9929	019e72e8-735d-7c54-b229-08222aa2c6ca	3de0ee26b5d9dab544e670f8b850ff2cd94451cba0e8dd551945f9335e7711a0	2026-06-28 11:17:25.867	2026-05-29 11:57:18.893	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-05-29 11:17:25.892	2026-05-29 11:57:18.921
019e7398-90cf-7cf5-acdb-c9b4a7fae147	019e72e8-735d-7c54-b229-08222aa2c6ca	a33910d1fcba4865ffa820ff6218636c90c4e3fa3e7da4d9f12e28323afea43b	2026-06-28 11:57:18.918	2026-05-29 12:20:22.545	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.9	2026-05-29 11:57:18.924	2026-05-29 12:20:22.575
019e73ad-adb9-72ec-953f-dbfe846d398b	019e72e8-735d-7c54-b229-08222aa2c6ca	ca5133a9f37f34b0513816de53a6f99222c7f97917bd892588143e30797c0509	2026-06-28 12:20:22.572	2026-05-29 12:36:18.744	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-05-29 12:20:22.58	2026-05-29 12:36:18.784
019e73bc-44e9-7838-ac35-a5d3ae29c0cf	019e72e8-735d-7c54-b229-08222aa2c6ca	1813785681f570b8c79b0b6cdc1bb6fbf31e293187d2e63663a2fd13bd05e5b0	2026-06-28 12:36:18.781	2026-05-29 12:36:24.228	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-05-29 12:36:18.788	2026-05-29 12:36:24.235
019e73bc-5a32-7945-b37e-06a1cbacc3df	019e72e8-735d-7c54-b229-08222aa2c6ca	3c4385bbb043c648615829e57c21a46e61af937d963dfdad116fd17656bd60f9	2026-06-28 12:36:24.233	2026-05-29 13:10:01.378	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-05-29 12:36:24.237	2026-05-29 13:10:01.417
019e73db-21d2-7997-91a3-9d82fd5c2425	019e72e8-735d-7c54-b229-08222aa2c6ca	d86d2a2d4a9d8a0dc78b3b1e0817e024c679ce896423f6c5d1be7798387d6f13	2026-06-28 13:10:01.414	2026-05-29 13:10:19.581	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-05-29 13:10:01.42	2026-05-29 13:10:19.591
019e73db-68cc-7217-a42b-b3b78f17baf4	019e72e8-735d-7c54-b229-08222aa2c6ca	ad2cf94ff89c57bb03ec2ea88b9a1780bcb66f018b767d8aba190bc4916d974a	2026-06-28 13:10:19.588	2026-05-29 13:13:07.986	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-05-29 13:10:19.593	2026-05-29 13:13:07.993
019e73dd-faa5-7c55-a17d-461c84ccb1ed	019e72e8-735d-7c54-b229-08222aa2c6ca	836ac425a8d981697fa3cdedd9a14f82f26e8d95f49702b2e9990d6059491355	2026-06-28 13:13:07.991	2026-05-29 14:18:21.047	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-05-29 13:13:07.996	2026-05-29 14:18:21.077
019e7419-b01d-7380-acc9-d1ff9fed477f	019e72e8-735d-7c54-b229-08222aa2c6ca	ebdc77782c50d9cdd71bcbacaa9c60d8acce0fe2af209e43230afd06e0bfbb31	2026-06-28 14:18:21.071	2026-05-29 14:44:27.713	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-05-29 14:18:21.081	2026-05-29 14:44:27.734
019e7431-97df-713b-a509-8008ccc29211	019e72e8-735d-7c54-b229-08222aa2c6ca	570a7741eb5487d7fd6c7b4b0beb2ba727de614273513ba3c58140bd72aae34a	2026-06-28 14:44:27.732	2026-05-29 15:51:09.052	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-05-29 14:44:27.74	2026-05-29 15:51:09.073
019e746e-a61c-732c-9efb-351a787d15a1	019e72e8-735d-7c54-b229-08222aa2c6ca	31c4f5c7496a54661ebc5542511c5ef93b198259d7cdd3d119f6b835aeb44b83	2026-06-28 15:51:09.071	2026-05-29 16:39:02.676	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-05-29 15:51:09.081	2026-05-29 16:39:02.703
019e749a-7f34-71d5-b63e-c5a41b55b17a	019e72e8-735d-7c54-b229-08222aa2c6ca	5d75ae7a97f80a0aa4c618277a32a4a5867fdcfa93616976ba49760b219e9d1f	2026-06-28 16:39:02.7	2026-05-30 05:16:22.742	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-05-29 16:39:02.705	2026-05-30 05:16:22.766
019e774f-db74-7433-972b-a85648a66a4d	019e72e8-735d-7c54-b229-08222aa2c6ca	b7f7975e4da7488ccd564ff37394f07cc0a1625768be7612d7f7cb01e1f21821	2026-06-29 05:16:22.764	2026-05-30 14:36:39.318	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-05-30 05:16:22.769	2026-05-30 14:36:39.707
019e7950-cfb3-7103-ba30-3745ecdd0a67	019e72e8-735d-7c54-b229-08222aa2c6ca	a0c70bfaff3cf54cb0b6a9bb5892a0af3dbf0dba6eb24f56b07702229d73e155	2026-06-29 14:36:39.696	2026-05-31 13:44:08.337	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-05-30 14:36:39.717	2026-05-31 13:44:08.38
019e7e47-15c4-7472-9dc1-fd637343228b	019e72e8-735d-7c54-b229-08222aa2c6ca	310adf51c0364bbf57de4da24a99d721803925caac2a920f542295d7253091fe	2026-06-30 13:44:08.374	2026-05-31 14:12:25.364	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-05-31 13:44:08.383	2026-05-31 14:12:25.715
019e7e60-fc05-7b2b-9cf3-2bb9f2716a07	019e72e8-735d-7c54-b229-08222aa2c6ca	44ca9dc40cc1c0fb26912eef0db8bfc0466a6e579ca4eec106baa0281bb1dfe1	2026-06-30 14:12:25.706	2026-05-31 14:12:27.956	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-05-31 14:12:25.725	2026-05-31 14:12:27.964
019e7e61-04c1-7cbc-8b81-89e06ee5be1b	019e72e8-735d-7c54-b229-08222aa2c6ca	bfe659615b01acff4d0423addaaef86d3314c313e8020ee98d4276a61c1d493c	2026-06-30 14:12:27.961	2026-06-01 11:52:55.359	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-05-31 14:12:27.966	2026-06-01 11:52:55.406
019e8307-9f75-7c62-a7c7-69c2476601ab	019e72e8-735d-7c54-b229-08222aa2c6ca	af82f7278d4c47fe5631a3d92e712025f786f0fe74f581146d6b9d5f85e2eaaa	2026-07-01 11:52:55.4	2026-06-01 12:24:14.204	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-06-01 11:52:55.408	2026-06-01 12:24:14.228
019e8324-4aa4-72dd-b726-004b1f0b48c5	019e72e8-735d-7c54-b229-08222aa2c6ca	ae3ba7fa85b221dcd2089d795649e79f1cb3307bf7fa53a68769cb611d02139b	2026-07-01 12:24:14.225	2026-06-01 12:24:16.504	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-06-01 12:24:14.236	2026-06-01 12:24:16.512
019e8324-5385-70e6-9960-9567f90378ca	019e72e8-735d-7c54-b229-08222aa2c6ca	fc659051a60d37b09421b8b3fa0f741ab3259c4d407ddf5957a814f812c9bc8b	2026-07-01 12:24:16.511	2026-06-01 13:14:25.777	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-06-01 12:24:16.514	2026-06-01 13:14:25.807
019e8352-3e9b-7f4b-80a1-98938130abbb	019e72e8-735d-7c54-b229-08222aa2c6ca	1bc19b2baa691b9743137811071477af944b750738d2ac248b886758fea4e2f2	2026-07-01 13:14:25.805	2026-06-01 13:38:26.875	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-06-01 13:14:25.814	2026-06-01 13:38:26.905
019e8368-3bdf-7177-831b-6103e5f5e0ee	019e72e8-735d-7c54-b229-08222aa2c6ca	9cd8846c3481e9dadcb0bd6f21529801ade005fae60f92dbf5e4c506ec2f68c7	2026-07-01 13:38:26.899	2026-06-01 23:22:01.053	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.9	2026-06-01 13:38:26.907	2026-06-01 23:22:01.076
019e857e-81fb-7fc7-89f8-f0860327d7e3	019e72e8-735d-7c54-b229-08222aa2c6ca	eb51e27a67f0c9256f69685894fdb28c94d5303bc26f211ebe1dac51126355b6	2026-07-01 23:22:01.073	2026-06-01 23:37:09.945	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-01 23:22:01.08	2026-06-01 23:37:09.968
019e858c-6056-7d1a-bcef-134b68c428d8	019e72e8-735d-7c54-b229-08222aa2c6ca	26e84c424838205fe7073ac389da71c7d4f008226148ab9a09e01133debb5ac3	2026-07-01 23:37:09.967	2026-06-01 23:37:11.496	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-06-01 23:37:09.97	2026-06-01 23:37:11.502
019e858c-6652-78bb-8743-01dcacbf7942	019e72e8-735d-7c54-b229-08222aa2c6ca	7c3734780583f4bb1e479b3a3e158f2138419d487eda72bf89d34ee54ebe0b8a	2026-07-01 23:37:11.501	2026-06-02 04:57:12.275	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-06-01 23:37:11.504	2026-06-02 04:57:12.296
019e86b1-6172-7629-9aea-71359d3d3486	019e72e8-735d-7c54-b229-08222aa2c6ca	180c705d1bdf1058785b812edbceac6de8864ee006247b56c384b4f03f2f720f	2026-07-02 04:57:12.294	2026-06-02 06:03:38.357	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-02 04:57:12.302	2026-06-02 06:03:38.382
019e86ee-3414-7d3d-b93e-bb6d8de2a4d0	019e72e8-735d-7c54-b229-08222aa2c6ca	684cb2ea77977424ad3a0082e5ebeee1b6fc2e6d14bca9f0b30252af893de8de	2026-07-02 06:03:38.38	2026-06-02 09:57:06.359	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-06-02 06:03:38.384	2026-06-02 09:57:06.38
019e87c3-f2d2-77c8-8fc9-3f721abc9118	019e72e8-735d-7c54-b229-08222aa2c6ca	6a69d0091bfecab42107b03135bf15d00a9d8d3b08cb2ce5e398c1a319fd9245	2026-07-02 09:57:06.379	2026-06-02 13:06:29.393	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-06-02 09:57:06.382	2026-06-02 13:06:29.418
019e8871-55b0-7b8e-845c-ad60f4bd096c	019e72e8-735d-7c54-b229-08222aa2c6ca	df2a7d59a5482078373e84f940db771dc0ecc535e2eabeaa0f869606b55f407f	2026-07-02 13:06:29.416	2026-06-03 04:02:53.487	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.9	2026-06-02 13:06:29.421	2026-06-03 04:02:53.51
019e8bd6-0af0-70d4-81e6-6a3c9f530c89	019e8bd6-0aea-7b42-9ed7-28afab973de7	8fcdebb09d2c1e80706d21c612bd7ab1344de64158714b11a2cad74e7b84cd70	2026-07-03 04:55:21.07	2026-06-03 04:58:36.548	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/23F77 Safari/604.1	109.252.89.205	2026-06-03 04:55:21.071	2026-06-03 04:58:36.57
019e8bd9-069f-7f9b-aafa-260a7698ebb4	019e8bd6-0aea-7b42-9ed7-28afab973de7	6c2a26e8e8fc9db2336fb9f3c6b2dae167ff5fb0201fbabd262bba68731d8c16	2026-07-03 04:58:36.568	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/23F77 Safari/604.1	109.252.89.205	2026-06-03 04:58:36.572	2026-06-03 04:58:36.572
019e8ba6-03cb-7491-b402-a20eca76225f	019e72e8-735d-7c54-b229-08222aa2c6ca	8cb691cf22790d3b2ea9153abfda433c8c9d0be998b5ba50025a77efcb2e14ca	2026-07-03 04:02:53.509	2026-06-03 09:13:10.859	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	77.34.131.26	2026-06-03 04:02:53.511	2026-06-03 09:13:10.882
019e8cc2-17e9-716a-83f0-94e3e89b0bd3	019e72e8-735d-7c54-b229-08222aa2c6ca	a26138f46748aaf614bc440c49bdfe301366c9f05809996019d8e4bb75a38489	2026-07-03 09:13:10.88	2026-06-03 10:27:33.175	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-03 09:13:10.885	2026-06-03 10:27:33.491
019e8d06-3001-772d-9b9b-6662270ef500	019e72e8-735d-7c54-b229-08222aa2c6ca	00bc21f97b6813cef6db7e0b77898088bd6923d0452d46260eac031431228cc1	2026-07-03 10:27:33.482	2026-06-03 10:27:52.655	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-06-03 10:27:33.497	2026-06-03 10:27:52.666
019e8d06-7ae0-7ba0-89e9-eaa25b65ad98	019e72e8-735d-7c54-b229-08222aa2c6ca	5bfafde4c454f0b97e013d9d7497a53e8926466ece585114248579c5726c063f	2026-07-03 10:27:52.663	2026-06-03 10:39:01.997	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-06-03 10:27:52.668	2026-06-03 10:39:02.006
019e8d10-b17c-72da-8b32-32fad2d3095e	019e72e8-735d-7c54-b229-08222aa2c6ca	01a25951e4d8289c7ce839e88cc342b99e6f858faf6650cd869d842c3dfa0b9b	2026-07-03 10:39:02.004	2026-06-03 10:42:33.296	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-06-03 10:39:02.008	2026-06-03 10:42:33.311
019e8d13-eae9-780b-8847-fe579a0b4b43	019e72e8-735d-7c54-b229-08222aa2c6ca	64c0227a1e5b6668b600c6d84d13ca750852833c2a2d38c5a60ee5e7056e514b	2026-07-03 10:42:33.309	2026-06-03 10:42:59.704	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-06-03 10:42:33.316	2026-06-03 10:42:59.72
019e8d14-5213-71ee-8fda-4ccc51240c0a	019e72e8-735d-7c54-b229-08222aa2c6ca	0b9c05599aa554e0e0f28a575cfd36dcd5dbd22da06b68476b3ad55abe973095	2026-07-03 10:42:59.718	2026-06-03 10:43:09.803	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-06-03 10:42:59.727	2026-06-03 10:43:09.808
019e8d14-7975-7b60-a471-686f308fb430	019e72e8-735d-7c54-b229-08222aa2c6ca	4ea1e76cde459d9a0afe276d1bfada24d1974473e542a00e51a0f4e7f87ec61d	2026-07-03 10:43:09.807	2026-06-03 11:33:47.843	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-06-03 10:43:09.81	2026-06-03 11:33:47.866
019e8d42-d4df-7319-b3f6-56ab9e9cf95c	019e72e8-735d-7c54-b229-08222aa2c6ca	029c7243df36bf9e764b605bc115c46868b60f4ec39f75cd56a936e8f7d135a9	2026-07-03 11:33:47.864	2026-06-03 11:33:49.357	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-03 11:33:47.868	2026-06-03 11:33:49.361
019e8d42-dab4-708b-96e1-54a7c0702a7e	019e72e8-735d-7c54-b229-08222aa2c6ca	14520948f22e8f079349b832aff48c385edc1e4b83e574fae3050390d975c970	2026-07-03 11:33:49.36	2026-06-03 12:24:56.329	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-03 11:33:49.363	2026-06-03 12:24:56.354
019e8d71-a727-7d3d-9c49-c439b6d4ee67	019e72e8-735d-7c54-b229-08222aa2c6ca	05e0285f507c78bc1294a65e6d5deb306d7c1f486ea3a6d3d0ed3ee76a234df9	2026-07-03 12:24:56.351	2026-06-03 13:03:53.332	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-06-03 12:24:56.356	2026-06-03 13:03:53.353
019e8d95-500e-72aa-9eab-aee8050540fb	019e72e8-735d-7c54-b229-08222aa2c6ca	1704a5ef7893432dc6c1730b40979fc1218967ac16d717ede8389fe8336f5c4f	2026-07-03 13:03:53.351	2026-06-03 23:13:38.987	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.9	2026-06-03 13:03:53.355	2026-06-03 23:13:39.009
019e8fc3-90c6-7e3b-bf26-eb2e6acff454	019e72e8-735d-7c54-b229-08222aa2c6ca	29e7ba96abb54205089949f7d26a89d175932c68ab51749c0931ee7f00a3a879	2026-07-03 23:13:39.007	2026-06-03 23:29:12.942	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-03 23:13:39.011	2026-06-03 23:29:12.958
019e8fd1-d105-7d00-a7ec-c7fa4f15ff33	019e72e8-735d-7c54-b229-08222aa2c6ca	cbe390b1277d4cc1e3fc3a14617ab3d948e33b66db473e23708b9ffed7efcbcd	2026-07-03 23:29:12.956	2026-06-04 00:18:46.542	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-03 23:29:12.961	2026-06-04 00:18:46.562
019e8fff-30a9-7b66-b36f-6d494daf3cd5	019e72e8-735d-7c54-b229-08222aa2c6ca	75a437665df7843d905646b6b3531b37f02da9a8359a5612f50bb79187293842	2026-07-04 00:18:46.56	2026-06-04 02:21:40.272	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-04 00:18:46.566	2026-06-04 02:21:40.292
019e906f-b449-7625-83f1-d60f54f33ca9	019e72e8-735d-7c54-b229-08222aa2c6ca	6525469ac39bb0ac60056dfa2b999fd51e701fdc547ed0525206465ec2550c2f	2026-07-04 02:21:40.29	2026-06-04 02:52:29.322	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-04 02:21:40.294	2026-06-04 02:52:29.341
019e908b-eb21-7f52-91f1-b2c2ddf0a988	019e72e8-735d-7c54-b229-08222aa2c6ca	7b50a51b615b35cfa95edecbe0f677a0e42e28e627c1a4067dc24ecbbe071450	2026-07-04 02:52:29.337	2026-06-04 04:28:16.209	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.208.216	2026-06-04 02:52:29.342	2026-06-04 04:28:16.225
019e90e3-9be6-7174-9ebc-8388ef034d90	019e72e8-735d-7c54-b229-08222aa2c6ca	a750550f541f386212da1ccad52c60f40a41c1e51c8c80af33d9b9ab9289da58	2026-07-04 04:28:16.224	2026-06-04 06:34:04.709	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-04 04:28:16.226	2026-06-04 06:34:04.728
019e9156-ca3d-7e84-a93b-5a908d781bd1	019e72e8-735d-7c54-b229-08222aa2c6ca	30d03342f0a476646e3baf7546f1c4fffdfc6d114a69aa8c6b7465b6986ce2d5	2026-07-04 06:34:04.726	2026-06-04 08:41:17.876	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-04 06:34:04.73	2026-06-04 08:41:17.899
019e91cb-4350-7c8b-adc4-ff6d5ebeacf1	019e72e8-735d-7c54-b229-08222aa2c6ca	522a91e68e438563520e80cdcd49349424a6670a1dfb767d74dd6dde53eb35f7	2026-07-04 08:41:17.897	2026-06-04 09:29:21.696	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-04 08:41:17.901	2026-06-04 09:29:21.72
019e91f7-443e-701b-91a7-9ac0222b630e	019e72e8-735d-7c54-b229-08222aa2c6ca	615b763ff05da6a26e5d021c3a9829b1d994b1516f8bffd4f2564b7ae1203370	2026-07-04 09:29:21.719	2026-06-04 12:25:17.126	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-04 09:29:21.722	2026-06-04 12:25:17.151
019e9298-5464-749a-af05-0e9da53d6631	019e72e8-735d-7c54-b229-08222aa2c6ca	fff1c5e17fef19a2795c982a5e30425e8bfb56e4f7d2684270dc3db685006537	2026-07-04 12:25:17.148	2026-06-04 14:09:38.466	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.208.216	2026-06-04 12:25:17.153	2026-06-04 14:09:38.49
019e92f7-debe-7400-9a06-0e27c23b0fd6	019e72e8-735d-7c54-b229-08222aa2c6ca	3e5dc5261d92594f4fb8cc2b60887cc616239edb33a908ee2a3a2c787e3f977b	2026-07-04 14:09:38.487	2026-06-05 02:27:39.062	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.208.216	2026-06-04 14:09:38.491	2026-06-05 02:27:39.083
019e959b-89cf-73fa-b3c4-3e42c211b98d	019e72e8-735d-7c54-b229-08222aa2c6ca	e17924508693096812fd239c907bcc0a465dd6be88bdd88963fac9dd7f4dbe93	2026-07-05 02:27:39.081	2026-06-05 04:52:59.403	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.208.216	2026-06-05 02:27:39.085	2026-06-05 04:52:59.425
019e9620-99a5-7943-9487-989480949237	019e72e8-735d-7c54-b229-08222aa2c6ca	5787a95c01f50392cab2f68fb961a153a35f4584373542970e98a7deead49df9	2026-07-05 04:52:59.422	2026-06-05 05:38:22.204	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-05 04:52:59.426	2026-06-05 05:38:22.228
019e964a-2599-7baa-9f5d-df3c2509b1fa	019e72e8-735d-7c54-b229-08222aa2c6ca	0cc9cfc5dd8c0b8470de87a190c761a21355dfcba70d5eeb365d0c4b3c295bbd	2026-07-05 05:38:22.225	2026-06-05 06:42:25.127	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 05:38:22.23	2026-06-05 06:42:25.468
019e9684-ca4e-71f4-a99a-a5eca9fe072d	019e72e8-735d-7c54-b229-08222aa2c6ca	511909230808094d4c0c635c2ce39a5447206ec904f23baf272f2d9aa3543fa1	2026-07-05 06:42:25.461	2026-06-05 06:42:51.367	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 06:42:25.477	2026-06-05 06:42:51.374
019e9685-2f74-7434-81fd-f77a43ea057d	019e72e8-735d-7c54-b229-08222aa2c6ca	ca0755002168d43e0b1b3bf4b83844e0a2047dc47ef6964c607e97da799e11de	2026-07-05 06:42:51.372	2026-06-05 06:45:24.133	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 06:42:51.377	2026-06-05 06:45:24.149
019e9687-843e-7202-a460-d8f5cc2824b2	019e72e8-735d-7c54-b229-08222aa2c6ca	e5773722a00292586b75bc5707ab4fc7c0fa3077cd806bfc79acc915954a21c1	2026-07-05 06:45:24.147	2026-06-05 07:01:57.341	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 06:45:24.152	2026-06-05 07:01:57.365
019e9696-abfa-779f-8a3d-a4673220f929	019e72e8-735d-7c54-b229-08222aa2c6ca	6c644e4cd5880f20c8210c545d0c46f2f5b1dbeaa2feb5a36744fee64f4e4d3a	2026-07-05 07:01:57.363	2026-06-05 07:10:26.472	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 07:01:57.367	2026-06-05 07:10:26.494
019e969e-70c3-7006-b107-86edfb8075df	019e72e8-735d-7c54-b229-08222aa2c6ca	b25cac5c0f67875373d862acab288207587861e6d703516a0663444560c396eb	2026-07-05 07:10:26.488	2026-06-05 07:10:28.05	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 07:10:26.496	2026-06-05 07:10:28.056
019e969e-76dc-7e31-be13-4e74d3e55247	019e72e8-735d-7c54-b229-08222aa2c6ca	ec29b121488e83024220d18069e8087b750ec9cd397827017043ad24a75d7e39	2026-07-05 07:10:28.055	2026-06-05 07:25:01.921	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 07:10:28.057	2026-06-05 07:25:01.945
019e96ab-cc87-7cca-ba6c-5d6f69c36396	019e72e8-735d-7c54-b229-08222aa2c6ca	a557bc3446eb993f00b32b62121bf47aaab65c22bd5b7b0c88bef9cc7a8c8719	2026-07-05 07:25:01.932	2026-06-05 07:25:07.24	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 07:25:01.952	2026-06-05 07:25:07.254
019e96ab-e143-78ac-af2f-3e7e520a16e2	019e72e8-735d-7c54-b229-08222aa2c6ca	c1f808da037994fe66ce9b613b5fd60ccb56e69cd36bdf1cbc1435beb89caa2c	2026-07-05 07:25:07.251	2026-06-05 07:25:10.474	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 07:25:07.264	2026-06-05 07:25:10.479
019e96ab-edd2-7de3-b345-93371c83db50	019e72e8-735d-7c54-b229-08222aa2c6ca	cba919066437a697f2b6005d14488f618044a336a9103837100e013ec755ca8e	2026-07-05 07:25:10.478	2026-06-05 07:34:48.691	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 07:25:10.48	2026-06-05 07:34:48.698
019e96b4-c07f-7b43-be64-0aafbf615717	019e72e8-735d-7c54-b229-08222aa2c6ca	813fdf62e7e29656e24b840e84049c5aa649fb321fb57f19a69f05c145d9eb07	2026-07-05 07:34:48.695	2026-06-05 08:37:35.026	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 07:34:48.699	2026-06-05 08:37:35.399
019e96ee-3a46-7177-a426-7121f8936757	019e72e8-735d-7c54-b229-08222aa2c6ca	472fd00cb208ee7171bde8ce5d6a6328d96f58f38ed071998f4e8267dd79bcfd	2026-07-05 08:37:35.381	2026-06-05 08:37:35.832	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 08:37:35.417	2026-06-05 08:37:35.902
019e96f2-114f-747f-9432-2588177da367	019e72e8-735d-7c54-b229-08222aa2c6ca	1ebb8d4379fc3f5a852977922ff928cb8e3d670fa6c9adce3c70f492969a5245	2026-07-05 08:41:47.083	2026-06-05 09:12:01.228	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 08:41:47.084	2026-06-05 09:12:01.71
019e970d-c1c0-7a9c-8bff-9a6949e80f6c	019e72e8-735d-7c54-b229-08222aa2c6ca	3c0f13888c007b264a4b89e296de265e1e2d9547de271c7508df627ea22616be	2026-07-05 09:12:01.653	2026-06-05 09:13:13.855	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 09:12:01.72	2026-06-05 09:13:13.871
019e970e-db94-7c65-ba76-08230b4b669f	019e72e8-735d-7c54-b229-08222aa2c6ca	641a6284e4e296bd470499b1147af484e3c9046e0c93a3e4abd45c8bad4c1cf4	2026-07-05 09:13:13.87	2026-06-05 09:25:32.205	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 09:13:13.873	2026-06-05 09:25:32.212
019e971a-1fc4-7f27-b85c-0caed3a0f561	019e72e8-735d-7c54-b229-08222aa2c6ca	7d034bd6f4ee887002ce3c83a10b6708e11270c1724b5f96b2c947b5da0a81cd	2026-07-05 09:25:32.21	2026-06-05 09:25:34.643	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 09:25:32.215	2026-06-05 09:25:34.649
019e971a-293c-784a-8099-ed19ec3e0061	019e72e8-735d-7c54-b229-08222aa2c6ca	426ed9d57fcbbeb2841bc087298f818878928ee714d28bdadaee844f6d67734f	2026-07-05 09:25:34.647	2026-06-05 09:27:20.416	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 09:25:34.65	2026-06-05 09:27:20.43
019e971b-c67c-7037-93e6-e3f4afc41263	019e72e8-735d-7c54-b229-08222aa2c6ca	a229ebfb436129e3a201c4aed94735ab9615c0052a1447a44d00b4546ec0e76f	2026-07-05 09:27:20.423	2026-06-05 09:27:26.721	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 09:27:20.434	2026-06-05 09:27:26.728
019e971b-df0f-77ca-bdf5-921cc540d7f9	019e72e8-735d-7c54-b229-08222aa2c6ca	b95e1c1c3e35a5d53d3a484fb44b472f710958fec3d765248741dfbaf921ce4e	2026-07-05 09:27:26.727	2026-06-05 09:27:30.376	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 09:27:26.73	2026-06-05 09:27:30.391
019e971b-ed5c-76f0-a156-7126ed716704	019e72e8-735d-7c54-b229-08222aa2c6ca	9683ed5b4f91f5b689d307ad3669f6e09d18fa0e1fd67f3870811228e12068a4	2026-07-05 09:27:30.387	2026-06-05 09:27:51.488	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 09:27:30.393	2026-06-05 09:27:51.782
019e971c-40ed-7133-bf45-29aaa486f315	019e72e8-735d-7c54-b229-08222aa2c6ca	25927888203cbbdbc7d372dd768ceaf0854b4f080af538a027f675f98809a9d7	2026-07-05 09:27:51.773	2026-06-05 10:01:38.094	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 09:27:51.786	2026-06-05 10:01:38.124
019e973b-2c52-7976-a898-233f2d088b08	019e72e8-735d-7c54-b229-08222aa2c6ca	0c3a681c4df1cac65b0569dc094d3f972803203785b002a0e061d40c21ba5670	2026-07-05 10:01:38.12	2026-06-05 10:21:22.285	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.207	2026-06-05 10:01:38.126	2026-06-05 10:21:22.308
019e974d-3e0c-726a-88f2-f6e1e0cc43b4	019e72e8-735d-7c54-b229-08222aa2c6ca	4401b6c66bec346b0af6df56dd3e486a34a3932cce2d88dedcc81b60e3cbc7f2	2026-07-05 10:21:22.306	2026-06-05 11:01:20.882	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.9	2026-06-05 10:21:22.311	2026-06-05 11:01:20.907
019e9771-d791-7997-8b42-258abcb3d7fe	019e72e8-735d-7c54-b229-08222aa2c6ca	428c8c35365495edc499a28a5c43a88329787087c4be3505414537e597d135c9	2026-07-05 11:01:20.901	2026-06-05 11:16:45.175	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 11:01:20.909	2026-06-05 11:16:45.488
019e977f-f33a-7e63-9c49-47860ad7ab34	019e72e8-735d-7c54-b229-08222aa2c6ca	738271df54a1cbed25fe2856af1ee74e1caa111b59b91c173eab5e4e4e6ca32b	2026-07-05 11:16:45.479	2026-06-05 11:17:11.917	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 11:16:45.494	2026-06-05 11:17:11.945
019e9780-5a90-7c22-9cfb-75a2603db627	019e72e8-735d-7c54-b229-08222aa2c6ca	0a98e1561dac735e3be3473b24a99fd509d95b2542092657c29e944b8640dbd0	2026-07-05 11:17:11.941	2026-06-05 11:17:48.604	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 11:17:11.948	2026-06-05 11:17:48.628
019e9780-e9d8-7b90-9dfc-d862fe988381	019e72e8-735d-7c54-b229-08222aa2c6ca	affcfe64935f0d6996e9b99d7f1c9a3c2109276f40345626a9e7edaa746b3e4c	2026-07-05 11:17:48.623	2026-06-05 11:18:06.649	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 11:17:48.629	2026-06-05 11:18:06.673
019e9781-3055-72c5-9602-4582a458cd21	019e72e8-735d-7c54-b229-08222aa2c6ca	6fa5ab5a18db18d1a71ee1fc55f5e43cd8e105ea9fc4c435c3f14edff9b29ac3	2026-07-05 11:18:06.671	2026-06-05 11:18:18.512	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 11:18:06.675	2026-06-05 11:18:18.536
019e9781-5eaf-79da-b8c2-20dbd4495f2b	019e72e8-735d-7c54-b229-08222aa2c6ca	6c338fc1d0d5374999029a5cd5491ab34fbd62c9944150c7b6604afbcf76464d	2026-07-05 11:18:18.535	2026-06-05 12:00:26.642	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 11:18:18.54	2026-06-05 12:00:26.941
019e97a7-f349-7332-adad-a026c603064b	019e72e8-735d-7c54-b229-08222aa2c6ca	22477179bc1045d8639522b40c937437bd64ac72125747b8718740eb19f718d5	2026-07-05 12:00:26.933	2026-06-05 12:00:35.764	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 12:00:26.949	2026-06-05 12:00:35.77
019e97a8-15bc-7a97-ad09-572e0e1aff41	019e72e8-735d-7c54-b229-08222aa2c6ca	37daba56e206823a00792a14dab780f08578128df4fdda325eb3c1eacc46b881	2026-07-05 12:00:35.768	2026-06-05 12:00:45.655	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 12:00:35.771	2026-06-05 12:00:45.662
019e97a8-3c62-7f6b-abf9-b94a863a58d1	019e72e8-735d-7c54-b229-08222aa2c6ca	a0f6c12f6557e95764722edb4963d1d8e1455025ce7c1278c2293781ebe40cfd	2026-07-05 12:00:45.66	2026-06-05 12:38:15.837	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 12:00:45.664	2026-06-05 12:38:16.149
019e97ca-9367-77d8-994a-ce35ca68a6f9	019e72e8-735d-7c54-b229-08222aa2c6ca	95406ba1422ad4b6a35dffd1b2e83756b89a5b20ddce1d622ba265079debdd74	2026-07-05 12:38:16.142	2026-06-05 13:15:22.911	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 12:38:16.156	2026-06-05 13:15:22.932
019e97ec-8dba-766b-a3a9-ff0007e80097	019e72e8-735d-7c54-b229-08222aa2c6ca	ba5644b5f3138b2ca8354d684597fe900a92ec5d2236a2c78f817a4317336f6d	2026-07-05 13:15:22.93	2026-06-05 13:32:27.598	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 13:15:22.934	2026-06-05 13:32:27.621
019e97fc-306a-751b-adb8-bf454341224e	019e72e8-735d-7c54-b229-08222aa2c6ca	56ed010df503a701436ac97bb58658f7a0d72c857adf5d7f1337e13cdc1c3c28	2026-07-05 13:32:27.618	2026-06-05 14:27:23.293	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 13:32:27.623	2026-06-05 14:27:23.334
019e982e-7a4e-7315-b478-c9c8f0387dd7	019e72e8-735d-7c54-b229-08222aa2c6ca	b52b69b0312153aea287569b7014a3d39269e1e967d66dd814dd2d428ac85d12	2026-07-05 14:27:23.324	2026-06-06 13:16:33.805	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-05 14:27:23.338	2026-06-06 13:16:34.118
019e9d13-ffd5-7cb1-984b-21085da43df8	019e72e8-735d-7c54-b229-08222aa2c6ca	ec8445fb48f96d1e4256f8d987c24bdb7568e824f82169d9248e3744faedc699	2026-07-06 13:16:34.106	2026-06-06 13:42:14.295	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.9	2026-06-06 13:16:34.124	2026-06-06 13:42:14.319
019e9d2b-8035-727a-a945-e864faf3166d	019e72e8-735d-7c54-b229-08222aa2c6ca	fe6ad2b730ce16db0a4e7e7db9ef9da491d90afb5435b2fc09799c239279e758	2026-07-06 13:42:14.317	2026-06-07 11:07:56.642	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.211.221	2026-06-06 13:42:14.322	2026-06-07 11:07:56.671
019ea1c4-9986-7c12-a55d-35e3bc05deb2	019e72e8-735d-7c54-b229-08222aa2c6ca	818a7f2944dc131465c935c053fec7933f4c9c91e21c75a3e1b302ded93654fb	2026-07-07 11:07:56.669	2026-06-07 11:33:48.295	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-06-07 11:07:56.674	2026-06-07 11:33:48.318
019ea1dc-46a3-7449-bb95-00d741a11fea	019e72e8-735d-7c54-b229-08222aa2c6ca	91d34baabfbb18e6b0b56c87a93bb6f00f6d6700066793e70b92c59081953064	2026-07-07 11:33:48.316	2026-06-07 11:59:22.652	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.26.124	2026-06-07 11:33:48.32	2026-06-07 11:59:22.683
019ea1f3-b041-77ec-84b0-44212a1de9d3	019e72e8-735d-7c54-b229-08222aa2c6ca	2ef00d2c6779ddbc6d4821ec3571ac67987aa45fe7c7abc35637ea4ab7561cbf	2026-07-07 11:59:22.682	2026-06-08 05:09:14.443	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	31.200.232.9	2026-06-07 11:59:22.685	2026-06-08 05:09:14.746
019ea5a2-8f86-7554-89aa-4f5c0a333e3f	019e72e8-735d-7c54-b229-08222aa2c6ca	d2dbf17298ce31aaddc1144ec9d1b4ddd945e2d36b2e8a586b38d7d189fd0f5c	2026-07-08 05:09:14.715	2026-06-08 05:42:51.796	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-06-08 05:09:14.753	2026-06-08 05:42:51.819
019ea5c1-56b2-7f33-be48-7520638c7a87	019e72e8-735d-7c54-b229-08222aa2c6ca	377a8b665f155fc0e17b2c39c22bb27a279cc4133c1325ca85b96bb8d5cff03a	2026-07-08 05:42:51.817	2026-06-08 06:09:07.718	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-06-08 05:42:51.822	2026-06-08 06:09:07.741
019ea5d9-62a3-78a6-a8ac-76a78f20ef6a	019e72e8-735d-7c54-b229-08222aa2c6ca	4465bf27cdc809c27e2375a30bfdeb28f6ffe503c9c3aded7a59844befb55ed1	2026-07-08 06:09:07.739	2026-06-08 08:33:29.113	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-06-08 06:09:07.744	2026-06-08 08:33:29.141
019ea65d-8c3b-7f53-9a30-597a819466b5	019e72e8-735d-7c54-b229-08222aa2c6ca	cefe5b2aad0808380379d5ec777676c71090cdf4c1aae17e62ee432dd987135a	2026-07-08 08:33:29.138	2026-06-08 09:23:25.686	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-06-08 08:33:29.144	2026-06-08 09:23:25.709
019ea68b-4595-73f3-8d10-3170e7914deb	019e72e8-735d-7c54-b229-08222aa2c6ca	894cbb69faa0f347a74efe7884c7d6dc552449c429ba6be9e88491edfc403611	2026-07-08 09:23:25.707	2026-06-08 11:11:53.498	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-06-08 09:23:25.712	2026-06-08 11:11:53.527
019ea6ee-92be-7a13-b3c0-b412583173f4	019e72e8-735d-7c54-b229-08222aa2c6ca	ab95343676c097e7383f0d2b2492ddc08be961f63a5c4c12c112cdbec201f99b	2026-07-08 11:11:53.525	2026-06-09 06:59:17.81	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	89.58.27.15	2026-06-08 11:11:53.53	2026-06-09 06:59:17.833
019eab2d-accf-7e3a-8b67-03fcb5f62f78	019e72e8-735d-7c54-b229-08222aa2c6ca	972f34179a71ba9c3812205a5ce5ea010f56cddefb9ebce2321de20d6179f6e3	2026-07-09 06:59:17.831	2026-06-09 07:01:46.461	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	152.53.116.61	2026-06-09 06:59:17.835	2026-06-09 07:01:46.479
019eab2f-f178-7c6f-8f62-7202eee19d69	019e72e8-735d-7c54-b229-08222aa2c6ca	5a4c23b2100e350e12a65d8b6f8f62e3ccd669a8d814aa9e0d393c84d2de8c18	2026-07-09 07:01:46.476	2026-06-09 08:50:10.374	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.26.124	2026-06-09 07:01:46.484	2026-06-09 08:50:10.396
019eab93-2f62-723e-a8ef-2a84d498daf4	019e72e8-735d-7c54-b229-08222aa2c6ca	09682145e85e255b6579ce6318924e67e7325783917bd9a861b74c8e074aba9b	2026-07-09 08:50:10.391	2026-06-09 09:33:26.651	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-06-09 08:50:10.398	2026-06-09 09:33:26.673
019eabba-cd17-70c5-ab87-22871d9cfb06	019e72e8-735d-7c54-b229-08222aa2c6ca	3f2c9f2c5cd0a82f60908096df95a8cae062328967e7ea8bbc5e390c8effec9b	2026-07-09 09:33:26.671	2026-06-09 10:17:56.795	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-06-09 09:33:26.675	2026-06-09 10:17:56.818
019eabe3-8b58-7917-81e1-a91650bad090	019e72e8-735d-7c54-b229-08222aa2c6ca	e525813a13b147b1489a4b0cd10f8ecff2ef198d951fc590dbc558a04aed7225	2026-07-09 10:17:56.817	2026-06-09 10:49:05.241	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-06-09 10:17:56.821	2026-06-09 10:49:05.264
019eac00-0df9-7f93-ad39-e3038fb08d30	019e72e8-735d-7c54-b229-08222aa2c6ca	9c1d77a145dc92bdff6887323efce4f72a91f98c960743a83c658ac2e0f0737c	2026-07-09 10:49:05.262	2026-06-09 11:58:12.14	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.211.221	2026-06-09 10:49:05.267	2026-06-09 11:58:12.163
019eac3f-54ca-782e-bd04-4fbbde43d473	019e72e8-735d-7c54-b229-08222aa2c6ca	28365734382aebbdd7cf01796e8c8fb8179d70717dc1f15e9b5bee9834050a67	2026-07-09 11:58:12.161	2026-06-10 02:39:08.801	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.208.216	2026-06-09 11:58:12.166	2026-06-10 02:39:08.825
019eaf65-dc1e-7238-b0a9-99602064dd32	019e72e8-735d-7c54-b229-08222aa2c6ca	7d9206b05c970a3cda8b953ef3f1627039a4b3b423844591d4411b1fc8cfe032	2026-07-10 02:39:08.821	2026-06-10 03:10:08.235	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	91.79.245.58	2026-06-10 02:39:08.826	2026-06-10 03:10:08.251
019eaf82-3b83-7025-b9e5-9d6762291189	019e72e8-735d-7c54-b229-08222aa2c6ca	5a14c4428dac22ed728f9706d76739c102f01ea93f319f89f0b0c4f3fee035b4	2026-07-10 03:10:08.25	2026-06-10 11:08:16.875	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	91.79.245.58	2026-06-10 03:10:08.256	2026-06-10 11:08:16.898
019eb137-fc87-7900-8780-12ac7ec12775	019e72e8-735d-7c54-b229-08222aa2c6ca	a3ed97b78a2a52998af5153b7c249faea2de39f6db4d3263f21586ec767d35df	2026-07-10 11:08:16.896	2026-06-10 23:48:03.228	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-10 11:08:16.9	2026-06-10 23:48:03.248
019eb3ef-9435-758d-9be9-f2adc419581b	019e72e8-735d-7c54-b229-08222aa2c6ca	f30bbb753f2ad2b6310d3f184a1f8c600f830385a6479af1c1e1c2a438da48a8	2026-07-10 23:48:03.244	2026-06-11 00:26:48.331	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.27.15	2026-06-10 23:48:03.249	2026-06-11 00:26:48.349
019eb413-0ea5-7df9-b163-0e65f46decdd	019e72e8-735d-7c54-b229-08222aa2c6ca	e704069fb9c2b9691916cda0767f4dd55246d51864d4cfc4ebcca237723a5a85	2026-07-11 00:26:48.347	2026-06-11 03:23:07.311	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-06-11 00:26:48.351	2026-06-11 03:23:07.331
019eb4b4-7ac8-73c3-ace6-25ab377d8fbe	019e72e8-735d-7c54-b229-08222aa2c6ca	46ddb3389a8d3e15eaf9e24ef45dce726afd58a4e7defe55b1422d32b183ea00	2026-07-11 03:23:07.327	2026-06-11 10:10:01.084	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-06-11 03:23:07.333	2026-06-11 10:10:01.105
019eb629-0117-7d4e-aff2-de0a13accf2a	019e72e8-735d-7c54-b229-08222aa2c6ca	d2c025b6f74da776cc3ff1268984bb71c861c2c3fd4b7417a49f2210fe092ef7	2026-07-11 10:10:01.103	2026-06-11 13:54:45.476	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.27.15	2026-06-11 10:10:01.107	2026-06-11 13:54:45.495
019eb6f6-c280-7914-ad5a-f62cd81066b8	019e72e8-735d-7c54-b229-08222aa2c6ca	657f68c6be98a25133e0550743830726390a353484cdf79916f4ba2e1e096e17	2026-07-11 13:54:45.493	2026-06-11 14:13:46.137	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.26.124	2026-06-11 13:54:45.5	2026-06-11 14:13:46.158
019eb708-2a35-7e88-af5a-b565eff92917	019e72e8-735d-7c54-b229-08222aa2c6ca	914c4afe948bbb388d05f0d3c361fe00e276fdccd809509de639827f93c123d6	2026-07-11 14:13:46.154	2026-06-11 14:31:20.045	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.26.124	2026-06-11 14:13:46.16	2026-06-11 14:31:20.068
019eb718-3f08-7d8b-8659-f79ffbf30c83	019e72e8-735d-7c54-b229-08222aa2c6ca	cfc606210679228b0d298872060db9149c8491dca5843aa1c73bb9445e621b7e	2026-07-11 14:31:20.066	2026-06-12 14:17:11.468	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.26.124	2026-06-11 14:31:20.069	2026-06-12 14:17:11.498
019ebc31-a856-7816-bd08-99737e1445d5	019e72e8-735d-7c54-b229-08222aa2c6ca	500db86832ad3d33540cafcf2a09ad7e83ed803c97477876e5bd8dbcc48a410a	2026-07-12 14:17:11.495	2026-06-13 03:37:28.933	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-06-12 14:17:11.504	2026-06-13 03:37:28.954
019ebf0e-587e-7faa-af7f-d4cc1246564a	019e72e8-735d-7c54-b229-08222aa2c6ca	8f3910f3ae44d4b2bf554811c1cea07ece4d4c80e559b0485b97a842b64f309f	2026-07-13 03:37:28.952	2026-06-14 16:03:53.363	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-06-13 03:37:28.955	2026-06-14 16:03:53.386
019ec6e0-0fb0-79bd-b136-ade39bb8e506	019e72e8-735d-7c54-b229-08222aa2c6ca	2a877c3a56c743028d376e697ee5fe22eaede37e42a5f4a790f0c695d9e47b0b	2026-07-14 16:03:53.385	2026-06-14 16:05:36.647	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.27.15	2026-06-14 16:03:53.388	2026-06-14 16:05:36.669
019ec6e1-a322-765f-9514-01112f097735	019e72e8-735d-7c54-b229-08222aa2c6ca	0b3de6192c755f00402bd92b3b0c544f9ff3b4e5104d0474b7b9dabd5f99d202	2026-07-14 16:05:36.667	2026-06-15 00:04:58.176	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.27.15	2026-06-14 16:05:36.67	2026-06-15 00:04:58.192
019ec898-80d9-7197-ba80-0e5369133d31	019e72e8-735d-7c54-b229-08222aa2c6ca	9cf736a62548beaac58d0a4ef27df1047260b54c25a034eb41da202883a77de7	2026-07-15 00:04:58.191	2026-06-15 10:12:15.208	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-06-15 00:04:58.196	2026-06-15 10:12:15.227
019ecac4-7d03-7164-ab96-fd770e4872dc	019e72e8-735d-7c54-b229-08222aa2c6ca	06fa782cba543ca4b51c91ff784fb7a14f2be5164b6d209f6d7697dc303d3c3d	2026-07-15 10:12:15.225	2026-06-15 10:37:55.017	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.208.216	2026-06-15 10:12:15.232	2026-06-15 10:37:55.04
019ecadb-fbe4-76e6-a5c9-0fb021bdb1c3	019e72e8-735d-7c54-b229-08222aa2c6ca	e25abebabd0a59eeb1278e1470235061b9c308b1e6806fe84cd95e83dc656123	2026-07-15 10:37:55.037	2026-06-15 11:03:25.202	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-15 10:37:55.041	2026-06-15 11:03:25.223
019ecaf3-552c-7a27-96fc-1376b8aa122a	019e72e8-735d-7c54-b229-08222aa2c6ca	58bf44280edb0a904f6510f254a16dcefdc97a256056e886d6b3402e48a38380	2026-07-15 11:03:25.221	2026-06-15 23:29:03.093	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.208.216	2026-06-15 11:03:25.225	2026-06-15 23:29:03.115
019ecd9d-fa90-7e00-9389-070d8fa91d6d	019e72e8-735d-7c54-b229-08222aa2c6ca	4286d804b3ccc974c6e3b30e5290ba7d792df60c7585a0508b194728fa8919a8	2026-07-15 23:29:03.113	2026-06-15 23:50:44.41	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.208.216	2026-06-15 23:29:03.116	2026-06-15 23:50:44.432
019ecdb1-d5d5-7461-93f0-c76d38149950	019e72e8-735d-7c54-b229-08222aa2c6ca	0fd5ac69db9d1b1ddab0ebe9d7f139dac2e32e163f28d3688dde32cfd0d28c45	2026-07-15 23:50:44.43	2026-06-17 00:12:21.144	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.211.221	2026-06-15 23:50:44.433	2026-06-17 00:12:21.159
019ed2eb-fb2b-7439-909b-265555005d87	019e72e8-735d-7c54-b229-08222aa2c6ca	df142794d99464cba521afeea516e432706ac57ba670a4e962bbf6c475497a66	2026-07-17 00:12:21.158	2026-06-17 04:03:04.837	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-17 00:12:21.16	2026-06-17 04:03:04.856
019ed3bf-381c-7409-b5a9-6d81a3cfa863	019e72e8-735d-7c54-b229-08222aa2c6ca	7b7433366a0cb6169ab8e3c4f9c455722e562489b591d91300d42fdd623949d5	2026-07-17 04:03:04.852	2026-06-18 06:44:07.365	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-17 04:03:04.858	2026-06-18 06:44:07.384
019ed979-045d-784b-9748-e5998d9d80f6	019e72e8-735d-7c54-b229-08222aa2c6ca	b7a0a3418d7a3d192134fc44178cd3223b48ba8d2f8bbd6e154e3a0ecc5985ef	2026-07-18 06:44:07.382	2026-06-18 06:59:41.904	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	45.94.38.2	2026-06-18 06:44:07.386	2026-06-18 06:59:41.927
019ed987-46ec-7bed-bf37-a0d6395e4ad4	019e72e8-735d-7c54-b229-08222aa2c6ca	cd29473b4a68180cc13cfda4d9ccb2a39669e0c3ec6927b1aa4f27ff7cad20df	2026-07-18 06:59:41.925	2026-06-19 14:20:07.049	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-18 06:59:41.929	2026-06-19 14:20:07.073
019ee040-da26-7a30-b95a-68d120ae85c6	019e72e8-735d-7c54-b229-08222aa2c6ca	133dbbea17eacbdb2902f1a5b50316b3b76eb1b238b01363af6e4144fc521216	2026-07-19 14:20:07.069	2026-06-20 06:21:35.854	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	91.79.240.134	2026-06-19 14:20:07.075	2026-06-20 06:21:35.878
019ee3b1-1d0a-7c1f-9ced-676c42b88aa1	019e72e8-735d-7c54-b229-08222aa2c6ca	011f1458af9708127da58db07f9c4485d334b5b33ba1854880413d39961bae94	2026-07-20 06:21:35.873	2026-06-20 15:08:09.141	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	91.78.243.117	2026-06-20 06:21:35.88	2026-06-20 15:08:09.176
019ee593-305e-7277-8f61-0e2cbe7e6bf0	019e72e8-735d-7c54-b229-08222aa2c6ca	c972c5f666612a90fdbde68bac5087f1e42a05325d774d65ba9d51c352891598	2026-07-20 15:08:09.169	2026-06-20 15:10:52.74	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	91.78.242.119	2026-06-20 15:08:09.179	2026-06-20 15:10:52.755
019ee595-af57-7618-af5c-8da25f90a9be	019e72e8-735d-7c54-b229-08222aa2c6ca	f623d0a0c6fd17ea4ecf63d9914ecbe85011a5a1b1c36ab827e1f89ed9513b4b	2026-07-20 15:10:52.753	2026-06-21 13:42:48.599	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	91.78.242.119	2026-06-20 15:10:52.756	2026-06-21 13:42:48.619
019eea6b-6a2f-7188-801e-7226e9f4a8f3	019e72e8-735d-7c54-b229-08222aa2c6ca	c67a216071dfe43001c7de999703af5d96fe55ece780d297ea761acd01f89911	2026-07-21 13:42:48.614	2026-06-22 00:55:50.933	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	91.78.242.192	2026-06-21 13:42:48.621	2026-06-22 00:55:50.947
019eecd3-99a6-7282-81c2-430ebc364fff	019e72e8-735d-7c54-b229-08222aa2c6ca	f8a3418b1ef15e0a60f069c96f25bd39373188f59eb2caca3a5f9064213d6910	2026-07-22 00:55:50.946	2026-06-22 02:03:52.118	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.27.15	2026-06-22 00:55:50.948	2026-06-22 02:03:52.131
019eed11-dfc7-72e8-a591-5724c19dc199	019e72e8-735d-7c54-b229-08222aa2c6ca	11896141bb18c7a184e0dcf7c01768836a771b12ae1447dd2b762efcc523186a	2026-07-22 02:03:52.13	2026-06-22 08:25:54.568	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.26.124	2026-06-22 02:03:52.132	2026-06-22 08:25:54.582
019eee6f-a49a-7267-a78e-3731b7702684	019e72e8-735d-7c54-b229-08222aa2c6ca	bc77f773d12a84ede1ea1569024da6fc610490114e3b8e7b28def11e1cc60608	2026-07-22 08:25:54.581	2026-06-22 09:01:46.794	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.27.15	2026-06-22 08:25:54.584	2026-06-22 09:01:46.811
019eee90-7bc2-760b-aa2d-3b91f15cf29a	019e72e8-735d-7c54-b229-08222aa2c6ca	847b30b29db1542c4005d7a9142362ba51d7fbd1295350f8ebfeb6998e6ed6bc	2026-07-22 09:01:46.81	2026-06-23 00:32:23.788	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.106.220	2026-06-22 09:01:46.815	2026-06-23 00:32:23.808
019ef1e4-7d04-7fac-a0b2-24b201691b80	019e72e8-735d-7c54-b229-08222aa2c6ca	0e71dde5ae1560da00750c2813575569abc09fccae22316a5eeb0bb272d231db	2026-07-23 00:32:23.803	2026-06-23 04:03:07.156	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-23 00:32:23.809	2026-06-23 04:03:07.17
019ef2a5-6926-709c-907d-6d5566d4993d	019e72e8-735d-7c54-b229-08222aa2c6ca	34d77d27552afaaacf0680ab0fe4aff6b03a81f7a0de484515b8038e44486512	2026-07-23 04:03:07.168	2026-06-23 07:04:11.932	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-23 04:03:07.171	2026-06-23 07:04:11.946
019ef34b-31b1-7bf8-bfb4-c36bf6bd1403	019e72e8-735d-7c54-b229-08222aa2c6ca	0a9dc8b7056c7b7720079cc2e36ce0af1dca4b761bec7fead28b893a5a1a6f13	2026-07-23 07:04:11.944	2026-06-23 23:17:16.185	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.106.220	2026-06-23 07:04:11.951	2026-06-23 23:17:16.199
019ef6c6-112b-77ac-9bce-a8bc874e6a10	019e72e8-735d-7c54-b229-08222aa2c6ca	1bf7360b2c0f6a34d28ef213ba42df0a650c32bb70b51dd3e5be250fbec943e5	2026-07-23 23:17:16.198	2026-06-24 03:58:02.289	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-23 23:17:16.2	2026-06-24 03:58:02.303
019ef7c7-1e46-74ed-81c5-62b194895595	019e72e8-735d-7c54-b229-08222aa2c6ca	9827863887fe097445503426cafba4b630d8b7c63a885448e31fc34d4599ecc3	2026-07-24 03:58:02.302	2026-06-24 04:26:00.11	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-06-24 03:58:02.307	2026-06-24 04:26:00.127
019ef7e0-b844-770a-b827-9b239434a574	019e72e8-735d-7c54-b229-08222aa2c6ca	ed52c88e35242c319e166e6a5388aca5c3701647e1b089122d4c15c127023f34	2026-07-24 04:26:00.125	2026-06-24 04:45:51.084	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-06-24 04:26:00.129	2026-06-24 04:45:51.104
019ef7f2-e484-783e-9fde-9913fc81fd56	019e72e8-735d-7c54-b229-08222aa2c6ca	bfd6af2cccfacc333be56bc3b826cba083c507e6fb352761f3501dcbbb5f683c	2026-07-24 04:45:51.102	2026-06-24 06:14:28.089	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.106.220	2026-06-24 04:45:51.106	2026-06-24 06:14:28.102
019ef844-060a-7a34-8aca-af6222eb0d66	019e72e8-735d-7c54-b229-08222aa2c6ca	1a3a06a54347c17cd08fc2cc0783fc759e980631f0125346b4f8471e3b8e64bf	2026-07-24 06:14:28.101	2026-06-24 09:11:25.362	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.106.220	2026-06-24 06:14:28.103	2026-06-24 09:11:25.377
019ef8e6-07c8-70bd-b806-5bcd8fccf91f	019e72e8-735d-7c54-b229-08222aa2c6ca	219fc5c97d3211d6dd28875fbf0e3a6cae931b89cff8794a1249aebd769b304b	2026-07-24 09:11:25.376	2026-06-24 09:16:45.112	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.106.220	2026-06-24 09:11:25.381	2026-06-24 09:16:45.125
019ef8ea-e8c8-7a92-86a3-d29723f6b01d	019e72e8-735d-7c54-b229-08222aa2c6ca	cf1a13dbe2477cf435d45da08cbfb31bf6413449f78877d7861d8b341abc0b40	2026-07-24 09:16:45.124	2026-06-24 09:19:56.182	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.106.220	2026-06-24 09:16:45.126	2026-06-24 09:19:56.186
019ef8ed-d31e-7b01-8cca-eee76e6ef52d	019e72e8-735d-7c54-b229-08222aa2c6ca	2ea11977375e82455733288e0b27b5ecedd5bc915b063c9be9ed0dc9a05cc502	2026-07-24 09:19:56.185	2026-06-24 09:30:33.695	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.106.220	2026-06-24 09:19:56.187	2026-06-24 09:30:33.7
019ef8f7-8d67-7726-8304-4249399d52e7	019e72e8-735d-7c54-b229-08222aa2c6ca	08407c65533163ce16303fa70582cb0d2cc27a9d4151ec1184e4bb0f2a901fc1	2026-07-24 09:30:33.698	2026-06-24 10:45:05.59	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-06-24 09:30:33.701	2026-06-24 10:45:05.612
019ef93b-c9d1-750f-a551-a3bf974312d5	019e72e8-735d-7c54-b229-08222aa2c6ca	a5c4ca99bc6f75e991e36a2c06ea02bca19fba8208fb64960543375ac65c3d29	2026-07-24 10:45:05.61	2026-06-24 10:50:15.924	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-24 10:45:05.614	2026-06-24 10:50:15.945
019ef940-860e-75cf-beae-0f04c2e576e1	019e72e8-735d-7c54-b229-08222aa2c6ca	9800610d0005af4deafedb675db449d3efefa216090493d23fa40c3d84cdd522	2026-07-24 10:50:15.943	2026-06-24 12:03:59.454	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-24 10:50:15.947	2026-06-24 12:03:59.471
019ef984-0573-7979-8c4a-123ad1267939	019e72e8-735d-7c54-b229-08222aa2c6ca	e7bdda5115fd1d320794a69b558e1216747d2314543851baf835b6020a036123	2026-07-24 12:03:59.47	2026-06-24 12:19:02.791	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-06-24 12:03:59.472	2026-06-24 12:19:02.811
019ef991-ce20-7c60-ad31-8a7c41108796	019e72e8-735d-7c54-b229-08222aa2c6ca	96f88f04ff160f11847e4f036d51b1165377070282499eabbd5155ed4f191c35	2026-07-24 12:19:02.807	2026-06-24 13:04:12.904	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-06-24 12:19:02.813	2026-06-24 13:04:12.919
019ef9bb-287e-74ef-8b7a-0d0f80081e84	019e72e8-735d-7c54-b229-08222aa2c6ca	be90f1724aeb7f123535d73a9991f29aba2a249fb28dab084416488af08ed712	2026-07-24 13:04:12.918	2026-06-24 23:30:26.32	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-06-24 13:04:12.923	2026-06-24 23:30:26.335
019efbf8-7ba3-75aa-89ae-8c58a576bd36	019e72e8-735d-7c54-b229-08222aa2c6ca	bb5bb56315ad28f7526b6df6a7d88027c0293dbcce7e3d9a030c64083175a587	2026-07-24 23:30:26.334	2026-06-25 03:33:21.411	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-24 23:30:26.336	2026-06-25 03:33:21.426
019efcd6-e197-71dd-8510-8f5d1f8e6de2	019e72e8-735d-7c54-b229-08222aa2c6ca	c09a7ae49477d54b27db71b26d0a5e5597356bd253cc7d5465f935003d4033b7	2026-07-25 03:33:21.425	2026-06-25 03:37:55.418	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-06-25 03:33:21.428	2026-06-25 03:37:55.431
019efcdb-0fec-72fb-a4f9-27f240ebc017	019e72e8-735d-7c54-b229-08222aa2c6ca	fae2c66d96f51476044f6d537a1c64ce826b00043eb930829d572b9b333658ae	2026-07-25 03:37:55.43	2026-06-25 04:26:44.848	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-25 03:37:55.432	2026-06-25 04:26:44.862
019efd07-c302-7d9a-8994-f96007e1f592	019e72e8-735d-7c54-b229-08222aa2c6ca	19e13241a4fff14de0944700e2cd4a72097e81b82115d6432a10c8a9cc7bc793	2026-07-25 04:26:44.861	2026-06-25 07:00:17.114	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-25 04:26:44.863	2026-06-25 07:00:17.128
019efd94-546c-7ffd-b1fd-c041a7e4dc80	019e72e8-735d-7c54-b229-08222aa2c6ca	586adbe416b0a291bf751db2b702c2bd784fdfa64b419672c1d8950403821086	2026-07-25 07:00:17.127	2026-06-26 00:18:38.192	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-06-25 07:00:17.129	2026-06-26 00:18:38.204
019f014a-f7ff-78f5-a27b-bcf1fb8fa949	019e72e8-735d-7c54-b229-08222aa2c6ca	d9bffb2429ce0b0f5372c5584ed346f9c264895323a4687e953775d69f95b947	2026-07-26 00:18:38.203	2026-06-26 11:33:39.176	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-06-26 00:18:38.205	2026-06-26 11:33:39.192
019f03b4-f6fc-7f2e-888d-b0e4f02f960b	019e72e8-735d-7c54-b229-08222aa2c6ca	66dac0891a61c6bfc1b10ba03a8d7da140b6122d7ea1d98932310afc8507dbef	2026-07-26 11:33:39.192	2026-06-28 04:55:29.535	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-06-26 11:33:39.194	2026-06-28 04:55:29.554
019f0c95-2816-7b4c-9932-c58ac3467a80	019e72e8-735d-7c54-b229-08222aa2c6ca	da65be6e2b11d8a2ebe3ae070925b4900619796c4a8898b5f567ff176dd0732f	2026-07-28 04:55:29.552	2026-06-28 10:24:10.179	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-06-28 04:55:29.555	2026-06-28 10:24:10.194
019f0dc2-11d6-73e2-8cb7-6869eaa3e7a0	019e72e8-735d-7c54-b229-08222aa2c6ca	e5864a420db21a978f771f9e57fa27500ca1085f240ed5d8a76f7cab01031c78	2026-07-28 10:24:10.192	2026-06-28 14:19:52.283	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-06-28 10:24:10.195	2026-06-28 14:19:52.298
019f0e99-dc70-7d91-bbb5-ad895f91db1b	019e72e8-735d-7c54-b229-08222aa2c6ca	119af58f56bf7ab8b6ca0ec9b5fb49e9f1baaa0c2412f2725795c6b5017b72dc	2026-07-28 14:19:52.297	2026-06-29 02:09:52.501	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.106.220	2026-06-28 14:19:52.299	2026-06-29 02:09:52.514
019f1123-e385-7f50-b195-3eebf286793c	019e72e8-735d-7c54-b229-08222aa2c6ca	67042b0315cd4761d57e4953d4cd5eb436ae27dd63c756de981c225b2e11b201	2026-07-29 02:09:52.513	2026-06-29 05:37:36.029	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	91.79.245.173	2026-06-29 02:09:52.514	2026-06-29 05:37:36.043
019f11e2-1132-7269-915e-e0d21ed70949	019e72e8-735d-7c54-b229-08222aa2c6ca	617a505245b25205eba0b54e8b285af99dabbce2725cc0bcd498482d1269af71	2026-07-29 05:37:36.042	2026-06-29 11:17:02.405	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	91.79.244.65	2026-06-29 05:37:36.048	2026-06-29 11:17:02.423
019f1318-d55d-71b6-a42b-12e1548566fb	019e72e8-735d-7c54-b229-08222aa2c6ca	eac9f24d85a615885172bc2da5e785ca60e3d7a6e80ef8929d528d8866224f5e	2026-07-29 11:17:02.422	2026-06-29 12:09:54.634	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-06-29 11:17:02.426	2026-06-29 12:09:54.649
019f1349-3cdf-7e8a-ae39-84c377f14ec0	019e72e8-735d-7c54-b229-08222aa2c6ca	d0651cac98c0c11a834172baebfb01d776627d477f696c042dd67e7ee1329655	2026-07-29 12:09:54.648	2026-06-29 13:50:45.482	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-06-29 12:09:54.653	2026-06-29 13:50:45.497
019f13a5-9101-78be-b9f2-dffb83c3dfa9	019e72e8-735d-7c54-b229-08222aa2c6ca	206c28db82dba0ddfc8adee31de9a3e0a1be363cbf9006fe5317d8d0c0b102f3	2026-07-29 13:50:45.496	2026-06-29 23:38:54.92	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-06-29 13:50:45.501	2026-06-29 23:38:54.932
019f15c0-0a59-7572-8fe2-5a7b44747517	019e72e8-735d-7c54-b229-08222aa2c6ca	f8974a430d24ae2d8bad9d167f064d7d5de2808d0bd448b3734029ddd29b9b61	2026-07-29 23:38:54.931	2026-06-30 06:40:08.51	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-29 23:38:54.934	2026-06-30 06:40:08.53
019f1741-af57-7df4-85d4-7fdad09f9ce8	019e72e8-735d-7c54-b229-08222aa2c6ca	4bd54be5f69e1c127e18d069ad3010f5deb1f525a4f2ddae47fbd487c1ca1d36	2026-07-30 06:40:08.528	2026-06-30 09:47:19.674	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-30 06:40:08.532	2026-06-30 09:47:19.696
019f17ed-0f15-7768-92cf-9e11f8585f96	019e72e8-735d-7c54-b229-08222aa2c6ca	46c67f979121fa217e059e75b101b26ab5cb6468a44fa564ec752e2f8ee86333	2026-07-30 09:47:19.694	2026-07-01 03:03:19.038	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.207	2026-06-30 09:47:19.698	2026-07-01 03:03:19.054
019f1ba1-8912-7b59-a121-c682448839e6	019e72e8-735d-7c54-b229-08222aa2c6ca	13f7483f9b15e9fdb642063e46f9bb4565ccde98d34c686b946a55886264a709	2026-07-31 03:03:19.053	2026-07-01 11:44:17.849	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-07-01 03:03:19.055	2026-07-01 11:44:17.867
019f1d7e-81cf-7fe3-83ea-442c54dc6229	019e72e8-735d-7c54-b229-08222aa2c6ca	8c5ebd8665522d5e44c8238020bc5d540de0226536cc333d458ff90ce1be1abf	2026-07-31 11:44:17.865	2026-07-02 03:16:43.168	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-07-01 11:44:17.868	2026-07-02 03:16:43.183
019f20d4-2a35-7470-94d0-a34c4ddc780c	019e72e8-735d-7c54-b229-08222aa2c6ca	67d4f4c7141be1ca11ac69a9054f7109e4e988c0e067bafc15a7373e1f506959	2026-08-01 03:16:43.182	2026-07-02 04:14:52.665	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.177.125	2026-07-02 03:16:43.184	2026-07-02 04:14:52.678
019f2109-690a-7156-8f14-7680f47e399d	019e72e8-735d-7c54-b229-08222aa2c6ca	95793a44f773f908010d46ba3fb4a7751f74ddc869f8007e86b6ae0e01820ae7	2026-08-01 04:14:52.677	2026-07-02 10:00:07.436	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.27.15	2026-07-02 04:14:52.679	2026-07-02 10:00:07.453
019f2245-7e24-7478-b555-92c81e64d88b	019e72e8-735d-7c54-b229-08222aa2c6ca	ac9c5149364c5dd6657ae95d88b1765b90a403ecdb31f6d89ca4ee18c323448a	2026-08-01 10:00:07.451	2026-07-02 12:47:36.348	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.26.124	2026-07-02 10:00:07.457	2026-07-02 12:47:36.361
019f22de-d3ad-7022-8420-e488cb9ced16	019e72e8-735d-7c54-b229-08222aa2c6ca	88e0d03b0a64f265ea8627eb5a2f7090a605b3d8aed5aa2fab039fd7e88a6481	2026-08-01 12:47:36.36	2026-07-02 13:07:09.764	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-07-02 12:47:36.362	2026-07-02 13:07:09.78
019f22f0-bb59-7050-9a1b-147753084dd0	019e72e8-735d-7c54-b229-08222aa2c6ca	8070bf09b3df2e0cfe381f63450ec4ec21b6a2952b24f30beb38129e7171c802	2026-08-01 13:07:09.779	2026-07-03 14:04:56.21	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-07-02 13:07:09.782	2026-07-03 14:04:56.224
019f284b-fc24-7851-b827-afe9fdb626df	019e72e8-735d-7c54-b229-08222aa2c6ca	ad786b289f0060be4d05184309994f35396912936bb1a69c7251fd2af95292ce	2026-08-02 14:04:56.223	2026-07-03 15:36:09.668	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-07-03 14:04:56.225	2026-07-03 15:36:09.683
019f289f-80da-70ee-bf34-aff1180abda2	019e72e8-735d-7c54-b229-08222aa2c6ca	1af171f18a315ae58567b921a735fae4fe49f96e2bfe61c72f01f69397aeb7ec	2026-08-02 15:36:09.682	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.106.220	2026-07-03 15:36:09.687	2026-07-03 15:36:09.687
019f324a-0dfe-7cc7-a706-1a42e0c1b22a	019f324a-0df9-7a4a-835a-f6f742e2d659	998e91943e11890d143f96c30868d7ec1301a9e09131f197a528f70acae05b5e	2026-08-04 12:39:01.884	2026-07-05 12:39:30.5	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.177.125	2026-07-05 12:39:01.885	2026-07-05 12:39:30.507
019f324a-7dd0-7528-9ad0-37401937fe58	019f324a-0df9-7a4a-835a-f6f742e2d659	9c06b4ec677b55b7a67cd500b5d490dd517a714bd21d28e6969095d2d17728a5	2026-08-04 12:39:30.505	2026-07-05 12:39:53.966	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.177.125	2026-07-05 12:39:30.509	2026-07-05 12:39:53.971
019f324a-d97a-74d9-861e-c0e42f069f22	019f324a-0df9-7a4a-835a-f6f742e2d659	d6756de6caee6a6b6ca960766dbe6d344e23532d481f0f0458799f827143a994	2026-08-04 12:39:53.969	2026-07-05 12:40:02.125	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.177.125	2026-07-05 12:39:53.972	2026-07-05 12:40:02.132
019f324a-f959-7aa9-97da-100772114282	019f324a-0df9-7a4a-835a-f6f742e2d659	f5d3d9b8a6e2b87b4e522eaaa666644aa65f2c607e45fb43973996e54eb179c0	2026-08-04 12:40:02.131	2026-07-05 12:40:03.706	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.177.125	2026-07-05 12:40:02.134	2026-07-05 12:40:03.712
019f324a-ff85-725a-83fa-5f1364d20289	019f324a-0df9-7a4a-835a-f6f742e2d659	2fd54c94243c9b9e145eb7cf1ea8d5fb5ddeaaa8cdf43f0e7d962a65e2032c73	2026-08-04 12:40:03.71	2026-07-05 12:40:07.855	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.177.125	2026-07-05 12:40:03.716	2026-07-05 12:40:07.858
019f324b-0fb4-7e54-b619-d67c3fe8b582	019f324a-0df9-7a4a-835a-f6f742e2d659	45960f69ede6f678fb769492ed78448a9b3696403f70f4495a1a22fb9a2ab942	2026-08-04 12:40:07.857	2026-07-05 13:01:05.598	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.177.125	2026-07-05 12:40:07.859	2026-07-05 13:01:05.625
019f325e-40dd-7ee7-b1ab-bd089704852f	019f324a-0df9-7a4a-835a-f6f742e2d659	698ba4700b647d96e86b7b045f86cc20452ba87a6b0c661290f5c91aae714280	2026-08-04 13:01:05.617	2026-07-05 13:01:10.062	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-07-05 13:01:05.626	2026-07-05 13:01:10.068
019f325e-5237-751c-99b7-f3937d784840	019f324a-0df9-7a4a-835a-f6f742e2d659	1d2982410df256f651aec00f082691ee7a593099531dedc6244d133768960840	2026-08-04 13:01:10.066	2026-07-05 13:01:50.731	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-07-05 13:01:10.069	2026-07-05 13:01:50.742
019f325f-4255-7ac2-baa1-1a2602a490d9	019f324a-0df9-7a4a-835a-f6f742e2d659	df99d78f7ebf4ce1b3289b6a63b4ac791230830605d0b655030b1c01132f26d6	2026-08-04 13:02:11.537	2026-07-05 13:02:19.932	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-07-05 13:02:11.538	2026-07-05 13:02:19.934
019f3260-3cd2-72fd-86e0-06b084ce4150	019f324a-0df9-7a4a-835a-f6f742e2d659	234ba3a15860f241178397ab1ac8dfb0921e21de106aff969d555385009d12a2	2026-08-04 13:03:15.662	2026-07-05 13:29:32.451	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-07-05 13:03:15.662	2026-07-05 13:29:32.47
019f3278-4c3c-7ca6-a25c-f9ab016af584	019f324a-0df9-7a4a-835a-f6f742e2d659	d1d82058f15300c87f816e8cc972480641be17997569bc97863b8d19a6487143	2026-08-04 13:29:32.468	2026-07-05 13:33:10.846	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.26.124	2026-07-05 13:29:32.473	2026-07-05 13:33:10.851
019f327b-a147-7022-9cd4-e64bedc5a36c	019f324a-0df9-7a4a-835a-f6f742e2d659	1bd706bf213b2871a5b72764fb52c7f1d993bdf642c41e96ca2352a9829e2f71	2026-08-04 13:33:10.849	2026-07-05 14:02:26.453	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.26.124	2026-07-05 13:33:10.852	2026-07-05 14:02:26.857
019f3296-6cc2-71ee-b7dc-6162ee4a8abf	019f324a-0df9-7a4a-835a-f6f742e2d659	2f963f5655c1ac014484a182ef633b6649dfc787299af4ea837939cc7b8d63e8	2026-08-04 14:02:26.843	2026-07-05 14:02:34.308	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-07-05 14:02:26.872	2026-07-05 14:02:34.312
019f32aa-ea6e-7c3d-b813-7d5f06b5ecfb	019f324a-0df9-7a4a-835a-f6f742e2d659	53f9e97cb1ab6733293b38c0feb66c6c3bdf7479fe5b7577d3ee00067e97cf6b	2026-08-04 14:24:49.698	2026-07-05 14:29:02.76	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.208.216	2026-07-05 14:24:49.738	2026-07-05 14:29:02.795
019f32ae-c6d2-7f97-ba6c-5b71a07d7c86	019f324a-0df9-7a4a-835a-f6f742e2d659	8090dcbae53bf4cec2a99c510af8292a6fc8e9d83ad2f27d7973d961c980ae86	2026-08-04 14:29:02.773	2026-07-05 14:30:37.239	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.208.216	2026-07-05 14:29:02.799	2026-07-05 14:30:37.258
019f32b0-37cf-7a06-9c8e-69a997c21bfc	019f324a-0df9-7a4a-835a-f6f742e2d659	bd7a02a01ffa16cd05a11fda92d0fda51ffdb52c3be8416bfe17f3d483d61124	2026-08-04 14:30:37.256	2026-07-05 14:49:15.892	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	31.200.232.92	2026-07-05 14:30:37.261	2026-07-05 14:49:15.983
019f32c1-49e4-7483-b75f-baf6709f0327	019f324a-0df9-7a4a-835a-f6f742e2d659	4e77a2377278976379766e091fea5a95427a49e168de8a21bcfd2114ceba6863	2026-08-04 14:49:15.973	2026-07-05 14:54:48.891	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	159.195.140.30	2026-07-05 14:49:15.994	2026-07-05 14:54:48.921
019f32c6-5e67-7751-b1af-379ba47ba092	019f324a-0df9-7a4a-835a-f6f742e2d659	01cb7ecb6b76437704c3ed5c9f598d6dfad89dcc4f607de75f0abe0364be7784	2026-08-04 14:54:48.906	2026-07-05 15:03:08.72	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.179.214	2026-07-05 14:54:48.928	2026-07-05 15:03:08.745
019f32cd-fedd-71b5-99c5-a02645aadeae	019f324a-0df9-7a4a-835a-f6f742e2d659	06bab1812669d40c8b8fea5ee7c418efb0de1432268c9e7f54a08a83ada3203a	2026-08-04 15:03:08.732	2026-07-05 15:06:11.243	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.179.214	2026-07-05 15:03:08.76	2026-07-05 15:06:11.251
019f32d0-c7bb-7d50-837c-8027412d8977	019f324a-0df9-7a4a-835a-f6f742e2d659	2767ae4d5ebf5607b351255053125d7c2d1a39f06cffc6990a6c381430d51ef2	2026-08-04 15:06:11.248	2026-07-05 15:16:54.748	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.179.214	2026-07-05 15:06:11.254	2026-07-05 15:16:54.777
019f32da-9987-7e1c-ac0f-e28569e20a99	019f324a-0df9-7a4a-835a-f6f742e2d659	9c02bc652de86990bc240184fb8b481cf452e71ac352803ecc428da6d04f5dcf	2026-08-04 15:16:54.761	2026-07-05 15:19:28.952	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-07-05 15:16:54.787	2026-07-05 15:19:28.965
019f32dc-f3ca-7100-9680-b5b165d4ad1b	019f324a-0df9-7a4a-835a-f6f742e2d659	c35493372a11edbd1767508610ae9184138381e8f57190d23056dd7d98341b81	2026-08-04 15:19:28.959	2026-07-05 15:20:59.815	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-07-05 15:19:28.966	2026-07-05 15:20:59.822
019f32de-56b2-7e09-84aa-36fbb4324335	019f324a-0df9-7a4a-835a-f6f742e2d659	ad1d643138d85387721daca1662b93f6636c304fa87e37c11cb502f8826c29d5	2026-08-04 15:20:59.819	2026-07-06 02:40:26.69	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.116.61	2026-07-05 15:20:59.823	2026-07-06 02:40:26.717
019f354c-6464-7075-bc0b-a91e5eda3879	019f324a-0df9-7a4a-835a-f6f742e2d659	8803ee8eb0c2f7d52d91c756de29608fee3140789a609324512a366d2f486387	2026-08-05 02:40:26.715	2026-07-06 02:50:27.512	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.179.214	2026-07-06 02:40:26.721	2026-07-06 02:50:27.524
019f3555-8f5f-70a0-8da8-9651c4d030bf	019f324a-0df9-7a4a-835a-f6f742e2d659	01626446c5eb8b34e1941374168c42077dc7f69f4482cc7c527a8e4d7281d699	2026-08-05 02:50:27.518	2026-07-06 02:58:16.632	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.53.179.214	2026-07-06 02:50:27.536	2026-07-06 02:58:16.639
019f355c-b7c5-7e79-b8da-aebb932ee6f7	019f324a-0df9-7a4a-835a-f6f742e2d659	f0e31537f420690bf330df77e68d13267bc04e3718e384d0949df2558a20726a	2026-08-05 02:58:16.637	2026-07-06 02:59:10.327	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.27.15	2026-07-06 02:58:16.64	2026-07-06 02:59:10.345
019f355d-8990-7e2f-bc26-74c5682580ff	019f324a-0df9-7a4a-835a-f6f742e2d659	2a1ea71e7f6cabfbe915c61d53f3f95edeaa0f3bd2729458c50222305c3aed3d	2026-08-05 02:59:10.334	2026-07-06 02:59:47.767	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.27.15	2026-07-06 02:59:10.347	2026-07-06 02:59:47.776
019f355e-1bca-75f3-9ffe-1d4a5fd54f7a	019f324a-0df9-7a4a-835a-f6f742e2d659	f67f9a5a1bfc8430d1b4279d3e998b75e82af092ce6d1d92ceacd8d94128b2e3	2026-08-05 02:59:47.775	2026-07-06 03:09:41.661	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	89.58.27.15	2026-07-06 02:59:47.784	2026-07-06 03:09:41.689
019f3567-2bc0-7d23-9e84-3aa971c36788	019f324a-0df9-7a4a-835a-f6f742e2d659	70b2b4f4b345eb5bd62f74e59d5a683256a5db4d9595a0cf1f60946a4fe726c3	2026-08-05 03:09:41.677	2026-07-06 03:14:14.351	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	152.53.116.61	2026-07-06 03:09:41.692	2026-07-06 03:14:14.398
019f356b-5510-78b6-9be3-eaf3e5ca6e04	019f324a-0df9-7a4a-835a-f6f742e2d659	69b64b4950743fb1931465c9d34214610e0087cb377544625154ae4815a6d46c	2026-08-05 03:14:14.385	2026-07-06 03:27:33.333	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	152.53.177.125	2026-07-06 03:14:14.405	2026-07-06 03:27:33.362
019f3577-8600-72f9-a516-33b5d206af1c	019f324a-0df9-7a4a-835a-f6f742e2d659	c3e5fb4264f814613651350a313e0e8f771912d05016b27b25ab6585e32df94d	2026-08-05 03:27:33.356	2026-07-06 03:35:39.313	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	89.58.27.15	2026-07-06 03:27:33.37	2026-07-06 03:35:39.319
019f357e-f03d-7e4d-9f28-66d437ec3502	019f324a-0df9-7a4a-835a-f6f742e2d659	9940d2336877f7d9ddbdb247269767c827617a4e8609319019cf4d97b2af8b71	2026-08-05 03:35:39.316	2026-07-06 04:49:04.105	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	89.58.27.15	2026-07-06 03:35:39.32	2026-07-06 04:49:04.491
019f35c2-27f6-733c-a798-68131f8a57cc	019f324a-0df9-7a4a-835a-f6f742e2d659	7c407bfcc0c5ab69e8f30e1c800df35973e778bd45dc5b28330f997a7926d790	2026-08-05 04:49:04.482	2026-07-06 04:49:25.615	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	89.58.26.124	2026-07-06 04:49:04.499	2026-07-06 04:49:25.62
019f35c2-7a77-7f96-bf36-b8581f0c8334	019f324a-0df9-7a4a-835a-f6f742e2d659	1e97b883175abceae775fa92c915e19d9a005c32dba615f210d4c203fcef94cd	2026-08-05 04:49:25.618	2026-07-06 04:55:14.859	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	89.58.26.124	2026-07-06 04:49:25.622	2026-07-06 04:55:14.866
019f35c7-ceb7-7131-83c2-66bb7c0cf99c	019f324a-0df9-7a4a-835a-f6f742e2d659	7942f8bfca99443c4b37a7b1f022d8d36dd291fb00d8297fcfa55799ba54b38b	2026-08-05 04:55:14.863	2026-07-06 04:59:10.807	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	152.53.116.61	2026-07-06 04:55:14.868	2026-07-06 04:59:10.842
019f3723-206e-758a-9535-ed7d1bf153a3	019e72e8-735d-7c54-b229-08222aa2c6ca	4f4d912a64398af9d58a8b7c7cfab7eaa8a90985dec2013265d9661d904eced3	2026-08-05 11:14:36.762	\N	Bun/1.2.23	\N	2026-07-06 11:14:36.771	2026-07-06 11:14:36.771
019f35cb-689a-725b-bf5d-e6bd9e6249e3	019f324a-0df9-7a4a-835a-f6f742e2d659	6220cd815a25bce02c083dabc4989f645e1b64db905c0e492429eb8937f8820c	2026-08-05 04:59:10.819	2026-07-06 12:42:43.683	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	152.53.116.61	2026-07-06 04:59:10.854	2026-07-06 12:42:43.72
019f3773-cc90-7009-ad8f-7c3356b2fe30	019f324a-0df9-7a4a-835a-f6f742e2d659	ca418fa89e4fa48d940d5f092e0fed7a4e4976381b2384fd952753fb8738f21a	2026-08-05 12:42:43.711	2026-07-07 00:06:06.835	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	152.53.179.214	2026-07-06 12:42:43.725	2026-07-07 00:06:06.85
019f39e5-7509-734e-bf52-3e690eae5a7f	019f324a-0df9-7a4a-835a-f6f742e2d659	7f127ea65c179059f8579569b66a3578800f8c8b109570ae4350a14b6b2cbad2	2026-08-06 00:06:06.849	2026-07-07 00:06:27.351	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	89.58.27.15	2026-07-07 00:06:06.854	2026-07-07 00:06:27.358
019f39e5-c521-740f-bc37-cbf4c51f803c	019f324a-0df9-7a4a-835a-f6f742e2d659	0189b9812ee22cc4cb5bf97e21de46fa9a1e269787f9df02b7d4b28c16b94f6b	2026-08-06 00:06:27.356	2026-07-07 00:20:45.734	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	89.58.27.15	2026-07-07 00:06:27.36	2026-07-07 00:20:45.748
019f39f2-de41-7239-8592-3a227b265462	019f324a-0df9-7a4a-835a-f6f742e2d659	2f6b2c6974b7fad4e913f24554561762a529199ea4fa3b7e9e86c07ac7ab95c0	2026-08-06 00:20:45.742	2026-07-07 00:25:34.678	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	152.53.177.125	2026-07-07 00:20:45.754	2026-07-07 00:25:34.693
019f39f7-46eb-7783-94fc-5dd291660e90	019f324a-0df9-7a4a-835a-f6f742e2d659	9da611c59bd6182229e9cadb4ab21019b87b963d89b9a8209f982eac9790f323	2026-08-06 00:25:34.691	2026-07-07 00:25:39.082	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	152.53.177.125	2026-07-07 00:25:34.696	2026-07-07 00:25:39.087
019f39f7-5813-7a33-b08d-2433a9514a65	019f324a-0df9-7a4a-835a-f6f742e2d659	b3306ec8537a94e43d7ebda5ab3e4ea281730abe6fc6d6f21ed6c53ab6de989f	2026-08-06 00:25:39.085	2026-07-07 00:25:45.421	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	152.53.177.125	2026-07-07 00:25:39.089	2026-07-07 00:25:45.424
019f39f7-70d2-7a67-8f1b-01ff871976d7	019f324a-0df9-7a4a-835a-f6f742e2d659	c83f569c8acc8dfef31254d61a200cf72c7f258fdcac0b49ea0f3fdaac9ee074	2026-08-06 00:25:45.423	2026-07-07 00:26:20.948	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	152.53.177.125	2026-07-07 00:25:45.425	2026-07-07 00:26:20.955
019f39f7-fba0-74f6-a386-cc10986149df	019f324a-0df9-7a4a-835a-f6f742e2d659	85b92bc3741c56e50d62cac8fb641e0a715b78c8a2dd94188789dfa4efcdc289	2026-08-06 00:26:20.953	2026-07-07 00:41:33.874	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	152.53.177.125	2026-07-07 00:26:20.956	2026-07-07 00:41:34.194
019f3a05-eb04-7af0-908e-45f66f4665a8	019f324a-0df9-7a4a-835a-f6f742e2d659	703ddda3f137d5d8a552dea295153275c530571d6cbbaedbd4d09c84633c5aaa	2026-08-06 00:41:34.187	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	159.195.140.30	2026-07-07 00:41:34.204	2026-07-07 00:41:34.204
\.


--
-- Data for Name: candidates; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.candidates (id, tenant_id, full_name, email, phone, location, source, external_ids, created_at, updated_at, consent_context) FROM stdin;
019f32cc-c53f-71a9-bdd8-26b660dc737a	019e72e8-7296-7d04-86de-6766827d80f8	Андрей Крылов	krand2009@mail.ru	+7 926 068-76-28	Электросталь (Московская область)	hh_ru	{"hh_resume_id": "d3bb9777000234178800a886e66c444f683245", "hh_negotiation_id": "5397233021", "hh_resume_history": [{"title": "Менеджер по транспортной логистике", "skills": [], "location": "Электросталь (Московская область)", "education": ["Российская академия транспорта Российского Университета транспорта · 2022", "Российская академия предпринимательства, Москва · 2015"], "experience": ["Менеджер по логистике", "Специалист по логистике", "Ведущий специалист компании", "менеджер склада компании", "диспетчер компании"], "imported_at": "2026-07-06T05:00:31.102Z", "hh_resume_id": "d3bb9777000234178800a886e66c444f683245", "hh_negotiation_id": "5397233021", "total_experience_months": 189}], "hh_resume_snapshot": {"title": "Менеджер по транспортной логистике", "skills": [], "location": "Электросталь (Московская область)", "education": ["Российская академия транспорта Российского Университета транспорта · 2022", "Российская академия предпринимательства, Москва · 2015"], "experience": ["Менеджер по логистике", "Специалист по логистике", "Ведущий специалист компании", "менеджер склада компании", "диспетчер компании"], "total_experience_months": 189}}	2026-07-05 15:01:48.477	2026-07-06 05:00:31.105	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:48.477Z", "hh_negotiation_id": "5397233021"}
019f32cc-c679-7ea2-9534-0c29e5f362b4	019e72e8-7296-7d04-86de-6766827d80f8	Андрей Денискин	deniskin-av@mail.ru	+7 929 206-10-30	Орел	hh_ru	{"hh_resume_id": "4981fbcc0004dd6fa400a886e645704f336138", "hh_negotiation_id": "5399368144", "hh_resume_history": [{"title": "Специалист по логистике и снабжению", "skills": [], "location": "Орел", "education": ["Институт деловой карьеры, Москва · 2006", "СПТУ 143 · 1999"], "experience": ["Логист", "Старший кладовщик", "Руководитель отдела снабжения", "Менеджер по логистике", "Менеджер по работе с перевозчиками"], "imported_at": "2026-07-06T05:00:31.109Z", "hh_resume_id": "4981fbcc0004dd6fa400a886e645704f336138", "hh_negotiation_id": "5399368144", "total_experience_months": 107}], "hh_resume_snapshot": {"title": "Специалист по логистике и снабжению", "skills": [], "location": "Орел", "education": ["Институт деловой карьеры, Москва · 2006", "СПТУ 143 · 1999"], "experience": ["Логист", "Старший кладовщик", "Руководитель отдела снабжения", "Менеджер по логистике", "Менеджер по работе с перевозчиками"], "total_experience_months": 107}}	2026-07-05 15:01:48.79	2026-07-06 05:00:31.109	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:48.790Z", "hh_negotiation_id": "5399368144"}
019f32cc-c81d-76ef-b56f-5af440fa602d	019e72e8-7296-7d04-86de-6766827d80f8	Филипп Разаренов	filipp0501@mail.ru	+7 960 476-15-55	Новороссийск	hh_ru	{"hh_resume_id": "fa3f615b000e03341d00a886e643517a48754d", "hh_negotiation_id": "5402829495", "hh_resume_history": [{"title": "Менеджер по транспортной логистике и ВЭД", "skills": [], "location": "Новороссийск", "education": ["Адыгейский государственный университет, Майкоп · 2009"], "experience": ["Менеджер по логистике", "Экспедитор по вывозу из портов Новороссийска", "Менеджер по логистике", "Менеджер по коммерческой деятельности", "Начальник отдела логистики, администратор Мегацентра", "Начальник договорного отдела"], "imported_at": "2026-07-06T05:00:31.130Z", "hh_resume_id": "fa3f615b000e03341d00a886e643517a48754d", "hh_negotiation_id": "5402829495", "total_experience_months": 159}], "hh_resume_snapshot": {"title": "Менеджер по транспортной логистике и ВЭД", "skills": [], "location": "Новороссийск", "education": ["Адыгейский государственный университет, Майкоп · 2009"], "experience": ["Менеджер по логистике", "Экспедитор по вывозу из портов Новороссийска", "Менеджер по логистике", "Менеджер по коммерческой деятельности", "Начальник отдела логистики, администратор Мегацентра", "Начальник договорного отдела"], "total_experience_months": 159}}	2026-07-05 15:01:49.21	2026-07-06 05:00:31.131	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:49.209Z", "hh_negotiation_id": "5402829495"}
019f32cc-c8e8-79b5-b6cd-5a1fa6c7a877	019e72e8-7296-7d04-86de-6766827d80f8	Сeргeй Мирoшничeнкo	sm-v@bk.ru	+7 958 200-03-19	Москва	hh_ru	{"hh_resume_id": "41652be600107f873700a886e641575462634b", "hh_negotiation_id": "5403154710", "hh_resume_history": [{"title": "Менеджер по транспортной логистике / Клиентский менеджер (KAM)", "skills": [], "location": "Москва", "education": ["ХИСП (Харьковский институт социального прогресса) · 1997"], "experience": ["Руководитель отдела перевозок генеральных грузов", "Ведущий менеджер отдела логистики", "Ведущий логист отдела экспедирования FTL (Китай, ЕС, СНГ)", "Ведущий специалист по транспортной логистике", "Специалист оперативного отделения по работе с Китаем (импорт)", "Менеджер по транспортной логистике", "Ведущий логист отдела экспедирования", "Руководитель отдела логистики", "Руководитель направления автомобильных и морских перевозок", "Менеджер отдела международных перевозок", "Ведущий менеджер отдела международных перевозок", "Заместитель директора по производственным вопросам (все виды транспорта)"], "imported_at": "2026-07-06T05:00:31.144Z", "hh_resume_id": "41652be600107f873700a886e641575462634b", "hh_negotiation_id": "5403154710", "total_experience_months": 318}], "hh_resume_snapshot": {"title": "Менеджер по транспортной логистике / Клиентский менеджер (KAM)", "skills": [], "location": "Москва", "education": ["ХИСП (Харьковский институт социального прогресса) · 1997"], "experience": ["Руководитель отдела перевозок генеральных грузов", "Ведущий менеджер отдела логистики", "Ведущий логист отдела экспедирования FTL (Китай, ЕС, СНГ)", "Ведущий специалист по транспортной логистике", "Специалист оперативного отделения по работе с Китаем (импорт)", "Менеджер по транспортной логистике", "Ведущий логист отдела экспедирования", "Руководитель отдела логистики", "Руководитель направления автомобильных и морских перевозок", "Менеджер отдела международных перевозок", "Ведущий менеджер отдела международных перевозок", "Заместитель директора по производственным вопросам (все виды транспорта)"], "total_experience_months": 318}}	2026-07-05 15:01:49.415	2026-07-06 05:00:31.145	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:49.414Z", "hh_negotiation_id": "5403154710"}
019f32cc-c9b8-773a-a7f3-20ca9ff772de	019e72e8-7296-7d04-86de-6766827d80f8	Алексей Фещенко	oooblc@mail.ru	+7 961 102-44-21	Брянск	hh_ru	{"hh_resume_id": "bd6a3dc20007212d8d00a886e662655a337365", "hh_negotiation_id": "5403413373", "hh_resume_history": [{"title": "Руководитель. Менеджер", "skills": [], "location": "Брянск", "education": ["Российская академия народного хозяйства и государственной службы при Президенте РФ, Москва · 2004", "Брянский государственный технический университет, Брянск · 2001", "Брянский государственный технический университет, Брянск · 2000"], "experience": ["Директор филиала", "Инженер-аналитик", "Экономист по труду и заработной плате, инженер-программист 1 категории", "Ведущий экономист"], "imported_at": "2026-07-06T05:00:31.161Z", "hh_resume_id": "bd6a3dc20007212d8d00a886e662655a337365", "hh_negotiation_id": "5403413373", "total_experience_months": 286}], "hh_resume_snapshot": {"title": "Руководитель. Менеджер", "skills": [], "location": "Брянск", "education": ["Российская академия народного хозяйства и государственной службы при Президенте РФ, Москва · 2004", "Брянский государственный технический университет, Брянск · 2001", "Брянский государственный технический университет, Брянск · 2000"], "experience": ["Директор филиала", "Инженер-аналитик", "Экономист по труду и заработной плате, инженер-программист 1 категории", "Ведущий экономист"], "total_experience_months": 286}}	2026-07-05 15:01:49.623	2026-07-06 05:00:31.162	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:49.622Z", "hh_negotiation_id": "5403413373"}
019f32cc-cb99-7fae-b716-ce019cf12390	019e72e8-7296-7d04-86de-6766827d80f8	Екатерина Чупинина	katyusha2407@mail.ru	+7 929 557-79-45	Москва	hh_ru	{"hh_resume_id": "c765fb440000ded69d00a886e6666162366250", "hh_negotiation_id": "5408712813", "hh_resume_history": [{"title": "Менеджер внешней логистики", "skills": [], "location": "Москва", "education": ["Брянский государственный технический университет, Брянск · 2014", "Брянский государственный университет им. И.Г. Петровского, Брянск · 2011"], "experience": ["Менеджер по логистике и ВЭД", "Менеджер по логистике и ВЭД", "Менеджер по внешней логистике", "Помощник операционного директора", "Ассистент операционного департамента", "учитель", "менеджер по работе с иностранными клиентами"], "imported_at": "2026-07-06T05:00:31.167Z", "hh_resume_id": "c765fb440000ded69d00a886e6666162366250", "hh_negotiation_id": "5408712813", "total_experience_months": 199}], "hh_resume_snapshot": {"title": "Менеджер внешней логистики", "skills": [], "location": "Москва", "education": ["Брянский государственный технический университет, Брянск · 2014", "Брянский государственный университет им. И.Г. Петровского, Брянск · 2011"], "experience": ["Менеджер по логистике и ВЭД", "Менеджер по логистике и ВЭД", "Менеджер по внешней логистике", "Помощник операционного директора", "Ассистент операционного департамента", "учитель", "менеджер по работе с иностранными клиентами"], "total_experience_months": 199}}	2026-07-05 15:01:50.104	2026-07-06 05:00:31.167	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:50.103Z", "hh_negotiation_id": "5408712813"}
019f32cc-cd6c-71ec-b291-f1b68b25ddd9	019e72e8-7296-7d04-86de-6766827d80f8	Елена Эстер	ealfredovna@yandex.ru	+7 920 526-88-28	Ростов-на-Дону	hh_ru	{"hh_resume_id": "70469e9f000fe04e2b00a886e6546b4952704b", "hh_negotiation_id": "5409206234", "hh_resume_history": [{"title": "Менеджер по ВЭД, Логист", "skills": [], "location": "Ростов-на-Дону", "education": ["Национальный исследовательский университет «Высшая школа экономики», Москва · 2023", "Елецкий государственный университет имени И.А. Бунина, Елец · 2012"], "experience": ["Логист, менеджер вэд", "Ведущий менеджер ВЭД, Логист", "Менеджер ВЭД, Логист", "Бизнес ассистент", "Помощник генерального директора", "Помощник/ассистент руководителя"], "imported_at": "2026-07-06T05:00:31.175Z", "hh_resume_id": "70469e9f000fe04e2b00a886e6546b4952704b", "hh_negotiation_id": "5409206234", "total_experience_months": 107}], "hh_resume_snapshot": {"title": "Менеджер по ВЭД, Логист", "skills": [], "location": "Ростов-на-Дону", "education": ["Национальный исследовательский университет «Высшая школа экономики», Москва · 2023", "Елецкий государственный университет имени И.А. Бунина, Елец · 2012"], "experience": ["Логист, менеджер вэд", "Ведущий менеджер ВЭД, Логист", "Менеджер ВЭД, Логист", "Бизнес ассистент", "Помощник генерального директора", "Помощник/ассистент руководителя"], "total_experience_months": 107}}	2026-07-05 15:01:50.571	2026-07-06 05:00:31.177	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:50.571Z", "hh_negotiation_id": "5409206234"}
019f32cc-c3eb-7fa9-a694-bd52a1884a27	019e72e8-7296-7d04-86de-6766827d80f8	Влада Московкина	v_gamora99@mail.ru	+7 968 106-09-63	Омск	hh_ru	{"hh_resume_id": "720ba0a3000984305400a886e6626439556c77", "hh_negotiation_id": "5390276569", "hh_resume_history": [{"title": "Менеджер", "skills": [], "location": "Омск", "education": ["Омская гуманитарная академия, Омск · 2023"], "experience": ["Менеджер по транспортной логистике", "Менеджер по транспортной логистике", "Ведущий специалист по документообороту", "Специалист по закупкам"], "imported_at": "2026-07-06T05:00:31.077Z", "hh_resume_id": "720ba0a3000984305400a886e6626439556c77", "hh_negotiation_id": "5390276569", "total_experience_months": 59}], "hh_resume_snapshot": {"title": "Менеджер", "skills": [], "location": "Омск", "education": ["Омская гуманитарная академия, Омск · 2023"], "experience": ["Менеджер по транспортной логистике", "Менеджер по транспортной логистике", "Ведущий специалист по документообороту", "Специалист по закупкам"], "total_experience_months": 59}}	2026-07-05 15:01:48.128	2026-07-06 05:00:31.09	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:48.119Z", "hh_negotiation_id": "5390276569"}
019f32cc-c751-72d0-93db-2f7c59349d4f	019e72e8-7296-7d04-86de-6766827d80f8	Георгий Гергешания	gergeshanya@yandex.ru	+7 968 855-40-93	Красногорск (Московская область)	hh_ru	{"hh_resume_id": "1dd9f114000992d3e100a886e6643645644a37", "hh_negotiation_id": "5400900869", "hh_resume_history": [{"title": "Менеджер по логистике", "skills": [], "location": "Красногорск (Московская область)", "education": ["Институт мировой экономики и информатизации, Москва · 2017", "Московский радиотехнический колледж имени А.А. Расплетина · 2013"], "experience": ["Руководитель отдела логистики", "Руководитель отдела логистики", "Координатор отдела продаж", "Специалист по логистике"], "imported_at": "2026-07-06T05:00:31.113Z", "hh_resume_id": "1dd9f114000992d3e100a886e6643645644a37", "hh_negotiation_id": "5400900869", "total_experience_months": 125}], "hh_resume_snapshot": {"title": "Менеджер по логистике", "skills": [], "location": "Красногорск (Московская область)", "education": ["Институт мировой экономики и информатизации, Москва · 2017", "Московский радиотехнический колледж имени А.А. Расплетина · 2013"], "experience": ["Руководитель отдела логистики", "Руководитель отдела логистики", "Координатор отдела продаж", "Специалист по логистике"], "total_experience_months": 125}}	2026-07-05 15:01:49.007	2026-07-06 05:00:31.113	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:49.007Z", "hh_negotiation_id": "5400900869"}
019f32cc-cabd-7522-a98b-4be3f9e61347	019e72e8-7296-7d04-86de-6766827d80f8	Мария Панченко	mvasileva912@mail.ru	+7 987 792-80-77	Кумертау	hh_ru	{"hh_resume_id": "c03c3c9b000b4957cb00a886e67869344b5653", "hh_negotiation_id": "5407960003", "hh_resume_history": [{"title": "Координатор", "skills": [], "location": "Кумертау", "education": ["Оренбургский государственный университет, Оренбург · 2009"], "experience": ["Координатор", "Статистик", "Ведущий кредитный менеджер", "Менеджер по работе с клиентами", "Администратор клиентского зала", "Специалист отдела обеспечения бизнеса", "Бухгалтер-экономист"], "imported_at": "2026-07-06T05:00:31.182Z", "hh_resume_id": "c03c3c9b000b4957cb00a886e67869344b5653", "hh_negotiation_id": "5407960003", "total_experience_months": 195}], "hh_resume_snapshot": {"title": "Координатор", "skills": [], "location": "Кумертау", "education": ["Оренбургский государственный университет, Оренбург · 2009"], "experience": ["Координатор", "Статистик", "Ведущий кредитный менеджер", "Менеджер по работе с клиентами", "Администратор клиентского зала", "Специалист отдела обеспечения бизнеса", "Бухгалтер-экономист"], "total_experience_months": 195}}	2026-07-05 15:01:49.884	2026-07-06 05:00:31.182	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:49.884Z", "hh_negotiation_id": "5407960003"}
019f32cc-cc79-7352-bd17-40ba3fd57aab	019e72e8-7296-7d04-86de-6766827d80f8	Эге Якут	egeyakut@mail.ru	+7 916 159-27-69	Москва	hh_ru	{"hh_resume_id": "948b5813000fb9b4fd00a886e6474c4e7a4676", "hh_negotiation_id": "5409199991", "hh_resume_history": [{"title": "Руководитель отдела логистики", "skills": [], "location": "Москва", "education": ["Стамбульский университет · 2023", "Казанский (Приволжский) федеральный университет, Казань · 2020"], "experience": ["Transit Team Leader", "Специалист по импортным операциям (РФ/РБ – Турция)"], "imported_at": "2026-07-06T05:00:31.187Z", "hh_resume_id": "948b5813000fb9b4fd00a886e6474c4e7a4676", "hh_negotiation_id": "5409199991", "total_experience_months": 47}], "hh_resume_snapshot": {"title": "Руководитель отдела логистики", "skills": [], "location": "Москва", "education": ["Стамбульский университет · 2023", "Казанский (Приволжский) федеральный университет, Казань · 2020"], "experience": ["Transit Team Leader", "Специалист по импортным операциям (РФ/РБ – Турция)"], "total_experience_months": 47}}	2026-07-05 15:01:50.328	2026-07-06 05:00:31.189	{"basis": "hh_negotiation_applicant_initiated", "imported_at": "2026-07-05T15:01:50.328Z", "hh_negotiation_id": "5409199991"}
\.


--
-- Data for Name: comp_bands; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.comp_bands (id, tenant_id, grade, currency, min_salary, mid_salary, max_salary, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: comp_plan_items; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.comp_plan_items (id, tenant_id, plan_id, employee_id, current_salary, proposed_salary, currency, change_pct, reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: comp_plans; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.comp_plans (id, tenant_id, name, effective_date, budget_currency, budget_total, status, notes, created_by_user_id, approved_by_user_id, approved_at, applied_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.conversations (id, tenant_id, candidate_id, application_id, subject, last_message_at, created_at, updated_at) FROM stdin;
019f32cc-c436-77d0-9bde-ecd4835c01f3	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c3eb-7fa9-a694-bd52a1884a27	019f32cc-c40d-773f-9c71-e1a661d3e493	Влада Московкина - Логист (HH.ru)	\N	2026-07-05 15:01:48.213	2026-07-05 15:01:48.213
019f32cc-c5b1-7fc8-bf2c-a9111a85bf1a	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c53f-71a9-bdd8-26b660dc737a	019f32cc-c586-7566-8b94-75ed1e04e42d	Андрей Крылов - Логист (HH.ru)	\N	2026-07-05 15:01:48.586	2026-07-05 15:01:48.586
019f32cc-c697-7483-8858-fc898e7f1214	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c679-7ea2-9534-0c29e5f362b4	019f32cc-c686-721f-b2ed-8e74ef2a140d	Андрей Денискин - Логист (HH.ru)	\N	2026-07-05 15:01:48.822	2026-07-05 15:01:48.822
019f32cc-c76b-7722-ba70-8c88dee7c6c5	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c751-72d0-93db-2f7c59349d4f	019f32cc-c75b-7fc6-a540-cb753cc79f62	Георгий Гергешания - Логист (HH.ru)	\N	2026-07-05 15:01:49.033	2026-07-05 15:01:49.033
019f32cc-c830-78b1-9b66-c036cab2e355	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c81d-76ef-b56f-5af440fa602d	019f32cc-c825-7778-b131-e12c9dc892e7	Филипп Разаренов - Логист (HH.ru)	\N	2026-07-05 15:01:49.231	2026-07-05 15:01:49.231
019f32cc-c8f5-7473-8632-170a15f797e5	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c8e8-79b5-b6cd-5a1fa6c7a877	019f32cc-c8ee-744e-a7a6-812dbd88314f	Сeргeй Мирoшничeнкo - Логист (HH.ru)	\N	2026-07-05 15:01:49.427	2026-07-05 15:01:49.427
019f32cc-c9d5-7dac-8742-0ce74f81cc58	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c9b8-773a-a7f3-20ca9ff772de	019f32cc-c9cd-7c50-a956-3cb98e64e5f3	Алексей Фещенко - Логист (HH.ru)	\N	2026-07-05 15:01:49.652	2026-07-05 15:01:49.652
019f32cc-cad3-7d51-90d0-9f593b69bfe2	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-cabd-7522-a98b-4be3f9e61347	019f32cc-cac4-7e67-821a-52e13dcf340b	Мария Панченко - Логист (HH.ru)	\N	2026-07-05 15:01:49.906	2026-07-05 15:01:49.906
019f32cc-cbce-7dbe-9739-7d7e02a4a9fc	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-cb99-7fae-b716-ce019cf12390	019f32cc-cbab-7c65-8c5c-f4d0c15227a9	Екатерина Чупинина - Логист (HH.ru)	\N	2026-07-05 15:01:50.157	2026-07-05 15:01:50.157
019f32cc-cc92-75e6-a5ab-02adb01ecda2	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-cc79-7352-bd17-40ba3fd57aab	019f32cc-cc89-7ee4-abf7-f1e46231cd08	Эге Якут - Логист (HH.ru)	\N	2026-07-05 15:01:50.352	2026-07-05 15:01:50.352
019f32cc-cd84-70f2-ba1b-0f457dc50c6a	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-cd6c-71ec-b291-f1b68b25ddd9	019f32cc-cd74-77e2-9224-6f30bf3eb0cd	Елена Эстер - Логист (HH.ru)	\N	2026-07-05 15:01:50.595	2026-07-05 15:01:50.595
\.


--
-- Data for Name: cron_job_runs; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.cron_job_runs (id, job_name, tenant_id, scheduled_window, started_at, finished_at, status, attempt, error, created_at, updated_at) FROM stdin;
b8584fc2-2fac-481d-b8ac-b94b23d08e74	analytics.snapshot	\N	2026-06-06	2026-06-06 01:00:01.224	2026-06-06 01:00:01.346	succeeded	1	\N	2026-06-06 01:00:01.224	2026-06-06 01:00:01.346
9fbd4e15-340b-4ead-ac4e-215233d27c07	probation.reminder	\N	2026-06-06	2026-06-06 01:15:01.325	2026-06-06 01:15:01.351	succeeded	1	\N	2026-06-06 01:15:01.325	2026-06-06 01:15:01.351
5779718b-0408-4c30-9dc0-fd8d73f8f6a7	1on1.reminder	\N	2026-06-06	2026-06-06 01:30:01.115	2026-06-06 01:30:01.15	succeeded	1	\N	2026-06-06 01:30:01.115	2026-06-06 01:30:01.15
55266657-fbed-4d7e-9ff3-a52ad190d4b1	review.reminder	\N	2026-06-06	2026-06-06 01:45:01.205	2026-06-06 01:45:01.229	succeeded	1	\N	2026-06-06 01:45:01.205	2026-06-06 01:45:01.229
cbfd802c-3259-499e-942b-87394cdf3f4d	data.retention	\N	2026-06	2026-06-06 02:00:01.127	2026-06-06 02:00:01.171	succeeded	1	\N	2026-06-06 02:00:01.127	2026-06-06 02:00:01.171
84359154-635e-4cf0-99e8-2a02d9e38486	signals.compute	\N	2026-06-06	2026-06-06 02:15:01.106	2026-06-06 02:15:01.13	succeeded	1	\N	2026-06-06 02:15:01.106	2026-06-06 02:15:01.13
29907a8e-5ca8-4a2c-9848-6805a39a240c	selection.retention_outcomes	\N	2026-06-06	2026-06-06 02:30:01.119	2026-06-06 02:30:01.141	succeeded	1	\N	2026-06-06 02:30:01.119	2026-06-06 02:30:01.141
02f212bc-85da-4ce0-b709-fcf47dbecd62	hh.sourcing	\N	2026-06-06	2026-06-06 03:15:01.118	2026-06-06 03:15:01.137	succeeded	1	\N	2026-06-06 03:15:01.118	2026-06-06 03:15:01.137
4b3b1c96-a080-453c-8bdc-d3d1b2385b42	analytics.snapshot	\N	2026-06-07	2026-06-07 01:00:01.109	2026-06-07 01:00:01.185	succeeded	1	\N	2026-06-07 01:00:01.109	2026-06-07 01:00:01.185
82972412-ddbf-49c5-b3a0-b174c3640051	probation.reminder	\N	2026-06-07	2026-06-07 01:15:01.071	2026-06-07 01:15:01.097	succeeded	1	\N	2026-06-07 01:15:01.071	2026-06-07 01:15:01.097
8e2ef0d1-0e45-4df7-87dd-53e69ef585ed	1on1.reminder	\N	2026-06-07	2026-06-07 01:30:00.963	2026-06-07 01:30:00.993	succeeded	1	\N	2026-06-07 01:30:00.963	2026-06-07 01:30:00.993
09500252-4b98-43fd-b625-ad49ab0751fe	review.reminder	\N	2026-06-07	2026-06-07 01:45:00.945	2026-06-07 01:45:00.974	succeeded	1	\N	2026-06-07 01:45:00.945	2026-06-07 01:45:00.974
f86915a3-a262-4e9d-858a-08059a98f07b	signals.compute	\N	2026-06-07	2026-06-07 02:15:00.949	2026-06-07 02:15:00.978	succeeded	1	\N	2026-06-07 02:15:00.949	2026-06-07 02:15:00.978
dea927cc-722f-42ab-86f9-7f7677bc1bc0	selection.retention_outcomes	\N	2026-06-07	2026-06-07 02:30:00.946	2026-06-07 02:30:00.964	succeeded	1	\N	2026-06-07 02:30:00.946	2026-06-07 02:30:00.964
4b0e0579-7e12-411d-b373-890c60eb3b68	hh.sourcing	\N	2026-06-07	2026-06-07 03:15:01.018	2026-06-07 03:15:01.038	succeeded	1	\N	2026-06-07 03:15:01.018	2026-06-07 03:15:01.038
ee28f93f-f7f3-42ea-92cf-9337616fe7b1	analytics.snapshot	\N	2026-06-08	2026-06-08 01:00:01.866	2026-06-08 01:00:02.038	succeeded	1	\N	2026-06-08 01:00:01.866	2026-06-08 01:00:02.038
b3b72fb4-5e1b-46d1-b858-ae6f12158f78	probation.reminder	\N	2026-06-08	2026-06-08 01:15:01.499	2026-06-08 01:15:01.528	succeeded	1	\N	2026-06-08 01:15:01.499	2026-06-08 01:15:01.528
9b8d0e64-1859-45cc-9a43-7400c90789fa	1on1.reminder	\N	2026-06-08	2026-06-08 01:30:01.656	2026-06-08 01:30:01.697	succeeded	1	\N	2026-06-08 01:30:01.656	2026-06-08 01:30:01.697
2842e1e5-fcc7-4ab0-9429-85e12ac98f57	review.reminder	\N	2026-06-08	2026-06-08 01:45:01.533	2026-06-08 01:45:01.568	succeeded	1	\N	2026-06-08 01:45:01.533	2026-06-08 01:45:01.568
55193c10-64a6-49c0-85c6-b96388c2f69e	signals.compute	\N	2026-06-08	2026-06-08 02:15:01.521	2026-06-08 02:15:01.554	succeeded	1	\N	2026-06-08 02:15:01.521	2026-06-08 02:15:01.554
d0096d17-6109-4951-944b-e92ace57f91e	selection.retention_outcomes	\N	2026-06-08	2026-06-08 02:30:01.519	2026-06-08 02:30:01.54	succeeded	1	\N	2026-06-08 02:30:01.519	2026-06-08 02:30:01.54
3cbcbde5-3462-4253-aa8c-d3645bd76303	selection.retention_calibration	\N	2026-06-08	2026-06-08 02:45:01.575	2026-06-08 02:45:01.659	succeeded	1	\N	2026-06-08 02:45:01.575	2026-06-08 02:45:01.659
1a8653bd-fdea-4c4c-8ba6-34bcc1978411	hh.sourcing	\N	2026-06-08	2026-06-08 03:15:01.559	2026-06-08 03:15:01.59	succeeded	1	\N	2026-06-08 03:15:01.559	2026-06-08 03:15:01.59
6810bd8e-3ce2-4d85-8347-828eeeedd027	analytics.snapshot	\N	2026-06-09	2026-06-09 01:00:00.82	2026-06-09 01:00:00.888	succeeded	1	\N	2026-06-09 01:00:00.82	2026-06-09 01:00:00.888
a2dcdc29-b784-4781-a418-392417d4228f	probation.reminder	\N	2026-06-09	2026-06-09 01:15:00.741	2026-06-09 01:15:00.766	succeeded	1	\N	2026-06-09 01:15:00.741	2026-06-09 01:15:00.766
e032f715-3e40-4969-93d9-826fae593a05	1on1.reminder	\N	2026-06-09	2026-06-09 01:30:00.856	2026-06-09 01:30:00.89	succeeded	1	\N	2026-06-09 01:30:00.856	2026-06-09 01:30:00.89
526bb9d1-c089-49b6-aee9-16dc0159a41c	review.reminder	\N	2026-06-09	2026-06-09 01:45:00.769	2026-06-09 01:45:00.789	succeeded	1	\N	2026-06-09 01:45:00.769	2026-06-09 01:45:00.789
3b31dd0d-1b17-4182-9903-d2226f4de5c0	signals.compute	\N	2026-06-09	2026-06-09 02:15:00.935	2026-06-09 02:15:00.957	succeeded	1	\N	2026-06-09 02:15:00.935	2026-06-09 02:15:00.957
af84bb3a-27d2-4535-ae42-9a9193e56b00	selection.retention_outcomes	\N	2026-06-09	2026-06-09 02:30:00.765	2026-06-09 02:30:00.786	succeeded	1	\N	2026-06-09 02:30:00.765	2026-06-09 02:30:00.786
b24a1f31-738d-4584-ab03-856c06cbb516	hh.sourcing	\N	2026-06-09	2026-06-09 03:15:00.784	2026-06-09 03:15:00.806	succeeded	1	\N	2026-06-09 03:15:00.784	2026-06-09 03:15:00.806
88661869-82b8-4f72-8fe9-d15e06e64dae	analytics.snapshot	\N	2026-06-10	2026-06-10 01:00:01.324	2026-06-10 01:00:01.404	succeeded	1	\N	2026-06-10 01:00:01.324	2026-06-10 01:00:01.404
81b50795-4af8-4eea-8e33-0c08908a9b1f	probation.reminder	\N	2026-06-10	2026-06-10 01:15:01.097	2026-06-10 01:15:01.12	succeeded	1	\N	2026-06-10 01:15:01.097	2026-06-10 01:15:01.12
0100536b-cc71-4305-a645-83d61f0f1e19	1on1.reminder	\N	2026-06-10	2026-06-10 01:30:01.132	2026-06-10 01:30:01.171	succeeded	1	\N	2026-06-10 01:30:01.132	2026-06-10 01:30:01.171
a60d7187-9019-4635-9d44-4762bb194661	review.reminder	\N	2026-06-10	2026-06-10 01:45:01.157	2026-06-10 01:45:01.183	succeeded	1	\N	2026-06-10 01:45:01.157	2026-06-10 01:45:01.183
04c4d676-a5cd-43a2-9d10-ba378a3d7199	signals.compute	\N	2026-06-10	2026-06-10 02:15:01.136	2026-06-10 02:15:01.172	succeeded	1	\N	2026-06-10 02:15:01.136	2026-06-10 02:15:01.172
7444a3c3-c071-41f9-a5dd-f89ae47e6f08	selection.retention_outcomes	\N	2026-06-10	2026-06-10 02:30:01.161	2026-06-10 02:30:01.183	succeeded	1	\N	2026-06-10 02:30:01.161	2026-06-10 02:30:01.183
0c5487a6-2808-4227-bb66-f6d7db9e04c3	hh.sourcing	\N	2026-06-10	2026-06-10 03:15:01.201	2026-06-10 03:15:01.227	succeeded	1	\N	2026-06-10 03:15:01.201	2026-06-10 03:15:01.227
798714d2-b3db-4631-b47b-d71e8201b83b	analytics.snapshot	\N	2026-06-11	2026-06-11 01:00:01.425	2026-06-11 01:00:01.518	succeeded	1	\N	2026-06-11 01:00:01.425	2026-06-11 01:00:01.518
8ce7ebaa-c9dc-4055-be9f-2d8c2b5df752	probation.reminder	\N	2026-06-11	2026-06-11 01:15:01.381	2026-06-11 01:15:01.41	succeeded	1	\N	2026-06-11 01:15:01.381	2026-06-11 01:15:01.41
dd4d74a1-d6e5-4e96-ab90-5c5d978db1dd	1on1.reminder	\N	2026-06-11	2026-06-11 01:30:01.536	2026-06-11 01:30:01.577	succeeded	1	\N	2026-06-11 01:30:01.536	2026-06-11 01:30:01.577
7cd04816-e5ad-4f64-9e51-c699fe9b40e0	review.reminder	\N	2026-06-11	2026-06-11 01:45:01.395	2026-06-11 01:45:01.421	succeeded	1	\N	2026-06-11 01:45:01.395	2026-06-11 01:45:01.421
a940e44f-9393-4f64-b2d0-6fa87f641095	signals.compute	\N	2026-06-11	2026-06-11 02:15:01.445	2026-06-11 02:15:01.474	succeeded	1	\N	2026-06-11 02:15:01.445	2026-06-11 02:15:01.474
847bef89-be0f-4046-bb98-361d8007b1c6	selection.retention_outcomes	\N	2026-06-11	2026-06-11 02:30:01.417	2026-06-11 02:30:01.435	succeeded	1	\N	2026-06-11 02:30:01.417	2026-06-11 02:30:01.435
63d7c654-7d57-49e2-b263-efe3799e905a	hh.sourcing	\N	2026-06-11	2026-06-11 03:15:01.482	2026-06-11 03:15:01.502	succeeded	1	\N	2026-06-11 03:15:01.482	2026-06-11 03:15:01.502
d154c1ad-7546-41de-9d74-9fdc097a721a	analytics.snapshot	\N	2026-06-12	2026-06-12 01:00:00.923	2026-06-12 01:00:00.991	succeeded	1	\N	2026-06-12 01:00:00.923	2026-06-12 01:00:00.991
12afe0bc-f668-444c-9734-08c2751fb2a5	probation.reminder	\N	2026-06-12	2026-06-12 01:15:00.767	2026-06-12 01:15:00.791	succeeded	1	\N	2026-06-12 01:15:00.767	2026-06-12 01:15:00.791
ce5adc55-f9b2-487a-afa8-83eb7ea6c31a	1on1.reminder	\N	2026-06-12	2026-06-12 01:30:00.781	2026-06-12 01:30:00.816	succeeded	1	\N	2026-06-12 01:30:00.781	2026-06-12 01:30:00.816
30681621-3cf4-41ab-9eea-2b268598a5a9	review.reminder	\N	2026-06-12	2026-06-12 01:45:00.715	2026-06-12 01:45:00.735	succeeded	1	\N	2026-06-12 01:45:00.715	2026-06-12 01:45:00.735
1c9ee8ab-6bff-452f-a2cb-2aed79b581f1	signals.compute	\N	2026-06-12	2026-06-12 02:15:00.895	2026-06-12 02:15:00.922	succeeded	1	\N	2026-06-12 02:15:00.895	2026-06-12 02:15:00.922
3eba7a59-58a2-4215-95d4-044c73244f80	selection.retention_outcomes	\N	2026-06-12	2026-06-12 02:30:00.787	2026-06-12 02:30:00.807	succeeded	1	\N	2026-06-12 02:30:00.787	2026-06-12 02:30:00.807
ab7585fb-73f3-41a7-b4d0-a08329a724c0	hh.sourcing	\N	2026-06-12	2026-06-12 03:15:00.755	2026-06-12 03:15:00.772	succeeded	1	\N	2026-06-12 03:15:00.755	2026-06-12 03:15:00.772
3f40eb65-20b4-4977-af6d-c0e6724ed2b5	analytics.snapshot	\N	2026-06-13	2026-06-13 01:00:01.11	2026-06-13 01:00:01.188	succeeded	1	\N	2026-06-13 01:00:01.11	2026-06-13 01:00:01.188
025285b7-9553-4f64-ac9f-93b608c9fcc3	probation.reminder	\N	2026-06-13	2026-06-13 01:15:01.028	2026-06-13 01:15:01.054	succeeded	1	\N	2026-06-13 01:15:01.028	2026-06-13 01:15:01.054
a945fea5-7e71-4ec1-a5a7-ea18701a6e6c	1on1.reminder	\N	2026-06-13	2026-06-13 01:30:01.137	2026-06-13 01:30:01.17	succeeded	1	\N	2026-06-13 01:30:01.137	2026-06-13 01:30:01.17
4fcf9cda-1fd6-4abd-b522-9f7c6d7acd98	review.reminder	\N	2026-06-13	2026-06-13 01:45:01.042	2026-06-13 01:45:01.069	succeeded	1	\N	2026-06-13 01:45:01.042	2026-06-13 01:45:01.069
339b0714-2ab5-484d-844c-53940886690b	signals.compute	\N	2026-06-13	2026-06-13 02:15:01.133	2026-06-13 02:15:01.159	succeeded	1	\N	2026-06-13 02:15:01.133	2026-06-13 02:15:01.159
99a993e0-33fe-4b1c-a9a2-2d2c18f19ba2	selection.retention_outcomes	\N	2026-06-13	2026-06-13 02:30:01.129	2026-06-13 02:30:01.151	succeeded	1	\N	2026-06-13 02:30:01.129	2026-06-13 02:30:01.151
c2314023-9504-4a34-82b6-676feca0c66a	hh.sourcing	\N	2026-06-13	2026-06-13 03:15:01.077	2026-06-13 03:15:01.1	succeeded	1	\N	2026-06-13 03:15:01.077	2026-06-13 03:15:01.1
09a769ef-1376-47f7-91b8-2859db04d901	analytics.snapshot	\N	2026-06-14	2026-06-14 01:00:01.401	2026-06-14 01:00:01.482	succeeded	1	\N	2026-06-14 01:00:01.401	2026-06-14 01:00:01.482
99761057-3885-45d1-80b7-06fbcff9f077	probation.reminder	\N	2026-06-14	2026-06-14 01:15:01.423	2026-06-14 01:15:01.455	succeeded	1	\N	2026-06-14 01:15:01.423	2026-06-14 01:15:01.455
65fd285f-fca7-4c9a-9546-3dbfc5d3667d	1on1.reminder	\N	2026-06-14	2026-06-14 01:30:01.367	2026-06-14 01:30:01.408	succeeded	1	\N	2026-06-14 01:30:01.367	2026-06-14 01:30:01.408
78698c18-c6a5-461b-bf5a-36de866faf8e	review.reminder	\N	2026-06-14	2026-06-14 01:45:01.67	2026-06-14 01:45:01.701	succeeded	1	\N	2026-06-14 01:45:01.67	2026-06-14 01:45:01.701
1b6371fa-cbeb-44d4-9bb7-8e47ad791dd7	signals.compute	\N	2026-06-14	2026-06-14 02:15:01.443	2026-06-14 02:15:01.475	succeeded	1	\N	2026-06-14 02:15:01.443	2026-06-14 02:15:01.475
77d0fc41-6842-4904-ab2e-e200f75dc244	selection.retention_outcomes	\N	2026-06-14	2026-06-14 02:30:01.362	2026-06-14 02:30:01.385	succeeded	1	\N	2026-06-14 02:30:01.362	2026-06-14 02:30:01.385
2263c4f0-e1c9-4db7-bdde-efa9db736bb2	hh.sourcing	\N	2026-06-14	2026-06-14 03:15:01.423	2026-06-14 03:15:01.446	succeeded	1	\N	2026-06-14 03:15:01.423	2026-06-14 03:15:01.446
fc031784-9cca-4984-bc7c-398aaddc57f1	analytics.snapshot	\N	2026-06-15	2026-06-15 01:00:00.774	2026-06-15 01:00:00.84	succeeded	1	\N	2026-06-15 01:00:00.774	2026-06-15 01:00:00.84
8303c53f-a1be-4f34-8149-f0729c77b364	probation.reminder	\N	2026-06-15	2026-06-15 01:15:00.669	2026-06-15 01:15:00.696	succeeded	1	\N	2026-06-15 01:15:00.669	2026-06-15 01:15:00.696
ba74769d-f6af-49bc-bd4e-4b4021dc6e7c	1on1.reminder	\N	2026-06-15	2026-06-15 01:30:00.76	2026-06-15 01:30:00.799	succeeded	1	\N	2026-06-15 01:30:00.76	2026-06-15 01:30:00.799
9afc9a3d-bd2e-4631-9333-e81488c08860	review.reminder	\N	2026-06-15	2026-06-15 01:45:00.691	2026-06-15 01:45:00.715	succeeded	1	\N	2026-06-15 01:45:00.691	2026-06-15 01:45:00.715
ed82d90a-c52b-4422-a93f-d52fb04f856d	signals.compute	\N	2026-06-15	2026-06-15 02:15:00.77	2026-06-15 02:15:00.792	succeeded	1	\N	2026-06-15 02:15:00.77	2026-06-15 02:15:00.792
e0539e29-b364-408d-b4ae-b38464f4776c	selection.retention_outcomes	\N	2026-06-15	2026-06-15 02:30:00.701	2026-06-15 02:30:00.725	succeeded	1	\N	2026-06-15 02:30:00.701	2026-06-15 02:30:00.725
b743f6c8-3ba6-42e5-aa89-f69ca3930b67	selection.retention_calibration	\N	2026-06-15	2026-06-15 02:45:00.734	2026-06-15 02:45:00.786	succeeded	1	\N	2026-06-15 02:45:00.734	2026-06-15 02:45:00.786
05e4f344-e642-4bb6-83c1-7dfa3ec79b20	hh.sourcing	\N	2026-06-15	2026-06-15 03:15:00.73	2026-06-15 03:15:00.751	succeeded	1	\N	2026-06-15 03:15:00.73	2026-06-15 03:15:00.751
6cfef06b-304b-4c20-aa66-5fbc9be6965a	analytics.snapshot	\N	2026-06-16	2026-06-16 01:00:01.204	2026-06-16 01:00:01.293	succeeded	1	\N	2026-06-16 01:00:01.204	2026-06-16 01:00:01.293
8d4238c9-34bb-4ff3-9bee-384999c3e1d9	probation.reminder	\N	2026-06-16	2026-06-16 01:15:01.053	2026-06-16 01:15:01.079	succeeded	1	\N	2026-06-16 01:15:01.053	2026-06-16 01:15:01.079
3e91a828-d121-4fce-a39a-d1711ff42817	1on1.reminder	\N	2026-06-16	2026-06-16 01:30:01.044	2026-06-16 01:30:01.09	succeeded	1	\N	2026-06-16 01:30:01.044	2026-06-16 01:30:01.09
b55cfb95-a7dd-42a3-8281-41d21297a22c	review.reminder	\N	2026-06-16	2026-06-16 01:45:01.162	2026-06-16 01:45:01.196	succeeded	1	\N	2026-06-16 01:45:01.162	2026-06-16 01:45:01.196
17484ce9-2075-444e-8850-712f158fd709	signals.compute	\N	2026-06-16	2026-06-16 02:15:01.29	2026-06-16 02:15:01.339	succeeded	1	\N	2026-06-16 02:15:01.29	2026-06-16 02:15:01.339
1bc967ed-4f12-46fe-b73a-5cc9a4c3fedb	selection.retention_outcomes	\N	2026-06-16	2026-06-16 02:30:01.165	2026-06-16 02:30:01.192	succeeded	1	\N	2026-06-16 02:30:01.165	2026-06-16 02:30:01.192
473cab06-76b3-4ab1-b562-a71926633182	hh.sourcing	\N	2026-06-16	2026-06-16 03:15:01.07	2026-06-16 03:15:01.092	succeeded	1	\N	2026-06-16 03:15:01.07	2026-06-16 03:15:01.092
f5523d25-9090-466a-9325-06b55f175471	analytics.snapshot	\N	2026-06-17	2026-06-17 01:00:01.475	2026-06-17 01:00:01.573	succeeded	1	\N	2026-06-17 01:00:01.475	2026-06-17 01:00:01.573
efc435a2-2e59-44a8-84b3-b3503620dba9	probation.reminder	\N	2026-06-17	2026-06-17 01:15:01.326	2026-06-17 01:15:01.357	succeeded	1	\N	2026-06-17 01:15:01.326	2026-06-17 01:15:01.357
2a865337-e3bf-4734-89d5-750628617560	1on1.reminder	\N	2026-06-17	2026-06-17 01:30:01.397	2026-06-17 01:30:01.437	succeeded	1	\N	2026-06-17 01:30:01.397	2026-06-17 01:30:01.437
ef22aa45-b98e-4762-b064-7808a833f0ad	review.reminder	\N	2026-06-17	2026-06-17 01:45:01.318	2026-06-17 01:45:01.35	succeeded	1	\N	2026-06-17 01:45:01.318	2026-06-17 01:45:01.35
158f25ab-36a7-4bde-834f-2db2a824acd5	signals.compute	\N	2026-06-17	2026-06-17 02:15:01.375	2026-06-17 02:15:01.405	succeeded	1	\N	2026-06-17 02:15:01.375	2026-06-17 02:15:01.405
e35bd292-ff6a-4614-85e6-abe305313f56	selection.retention_outcomes	\N	2026-06-17	2026-06-17 02:30:01.397	2026-06-17 02:30:01.415	succeeded	1	\N	2026-06-17 02:30:01.397	2026-06-17 02:30:01.415
baa7311f-66f0-496f-aca2-c8be58875f66	hh.sourcing	\N	2026-06-17	2026-06-17 03:15:01.362	2026-06-17 03:15:01.386	succeeded	1	\N	2026-06-17 03:15:01.362	2026-06-17 03:15:01.386
d83ea3fa-2b55-4dfa-a3ba-a00d1d3c108d	analytics.snapshot	\N	2026-06-18	2026-06-18 01:00:00.691	2026-06-18 01:00:00.759	succeeded	1	\N	2026-06-18 01:00:00.691	2026-06-18 01:00:00.759
e1371d00-15f4-4c6b-980e-e8c9ff8316c8	probation.reminder	\N	2026-06-18	2026-06-18 01:15:00.668	2026-06-18 01:15:00.692	succeeded	1	\N	2026-06-18 01:15:00.668	2026-06-18 01:15:00.692
43985b28-a464-4582-853f-17b67f57e24a	1on1.reminder	\N	2026-06-18	2026-06-18 01:30:00.66	2026-06-18 01:30:00.693	succeeded	1	\N	2026-06-18 01:30:00.66	2026-06-18 01:30:00.693
f2ea760f-0401-43a3-8121-079fee6f42e3	review.reminder	\N	2026-06-18	2026-06-18 01:45:00.646	2026-06-18 01:45:00.675	succeeded	1	\N	2026-06-18 01:45:00.646	2026-06-18 01:45:00.675
d520b83b-db51-480b-ba8d-81b1ab5bad69	signals.compute	\N	2026-06-18	2026-06-18 02:15:00.625	2026-06-18 02:15:00.648	succeeded	1	\N	2026-06-18 02:15:00.625	2026-06-18 02:15:00.648
aa4722c3-7fa0-488b-97c5-a0ecab5d7e12	selection.retention_outcomes	\N	2026-06-18	2026-06-18 02:30:00.696	2026-06-18 02:30:00.717	succeeded	1	\N	2026-06-18 02:30:00.696	2026-06-18 02:30:00.717
ebd52515-3b93-4c57-a317-7f7f579c14d7	hh.sourcing	\N	2026-06-18	2026-06-18 03:15:00.747	2026-06-18 03:15:00.763	succeeded	1	\N	2026-06-18 03:15:00.747	2026-06-18 03:15:00.763
e603bd5a-2193-4087-8be2-fcbf339ad85c	analytics.snapshot	\N	2026-06-19	2026-06-19 01:00:01.009	2026-06-19 01:00:01.091	succeeded	1	\N	2026-06-19 01:00:01.009	2026-06-19 01:00:01.091
6f282265-f026-49aa-ae73-4d5e015481c1	probation.reminder	\N	2026-06-19	2026-06-19 01:15:00.893	2026-06-19 01:15:00.916	succeeded	1	\N	2026-06-19 01:15:00.893	2026-06-19 01:15:00.916
cad0b31b-c07d-456c-b28d-0ac8b98ac3f8	1on1.reminder	\N	2026-06-19	2026-06-19 01:30:00.92	2026-06-19 01:30:00.948	succeeded	1	\N	2026-06-19 01:30:00.92	2026-06-19 01:30:00.948
e77f9fc2-6ff5-4e01-9f1e-0cc2dd6ef423	review.reminder	\N	2026-06-19	2026-06-19 01:45:00.957	2026-06-19 01:45:00.978	succeeded	1	\N	2026-06-19 01:45:00.957	2026-06-19 01:45:00.978
be7dc6b4-a298-432c-9313-f2be4200a60f	signals.compute	\N	2026-06-19	2026-06-19 02:15:00.945	2026-06-19 02:15:00.968	succeeded	1	\N	2026-06-19 02:15:00.945	2026-06-19 02:15:00.968
c18af95f-3644-47f1-8922-880d955d12eb	selection.retention_outcomes	\N	2026-06-19	2026-06-19 02:30:00.957	2026-06-19 02:30:00.973	succeeded	1	\N	2026-06-19 02:30:00.957	2026-06-19 02:30:00.973
a389ebe6-f595-4ae4-9047-86668ae1eb7b	hh.sourcing	\N	2026-06-19	2026-06-19 03:15:00.928	2026-06-19 03:15:00.944	succeeded	1	\N	2026-06-19 03:15:00.928	2026-06-19 03:15:00.944
deab32a2-23cb-447b-9a48-60af6cf95ba4	analytics.snapshot	\N	2026-06-20	2026-06-20 01:00:01.312	2026-06-20 01:00:01.415	succeeded	1	\N	2026-06-20 01:00:01.312	2026-06-20 01:00:01.415
5bd7b0ea-febe-480e-90d5-c161aed14d71	probation.reminder	\N	2026-06-20	2026-06-20 01:15:01.349	2026-06-20 01:15:01.376	succeeded	1	\N	2026-06-20 01:15:01.349	2026-06-20 01:15:01.376
adf28eb2-cab7-4b6c-af8b-0b152e586a2f	1on1.reminder	\N	2026-06-20	2026-06-20 01:30:01.478	2026-06-20 01:30:01.527	succeeded	1	\N	2026-06-20 01:30:01.478	2026-06-20 01:30:01.527
82d1dc6f-d5bb-44cf-b92c-beaddb0028a6	review.reminder	\N	2026-06-20	2026-06-20 01:45:01.448	2026-06-20 01:45:01.474	succeeded	1	\N	2026-06-20 01:45:01.448	2026-06-20 01:45:01.474
f335bc91-6c76-49a6-a284-24e58fa0e63e	signals.compute	\N	2026-06-20	2026-06-20 02:15:01.278	2026-06-20 02:15:01.304	succeeded	1	\N	2026-06-20 02:15:01.278	2026-06-20 02:15:01.304
d9aeb3f6-82a8-4a07-9278-15b924a12d85	selection.retention_outcomes	\N	2026-06-20	2026-06-20 02:30:01.288	2026-06-20 02:30:01.312	succeeded	1	\N	2026-06-20 02:30:01.288	2026-06-20 02:30:01.312
ac183dcb-3a0d-455c-9b36-25fbe363eac0	hh.sourcing	\N	2026-06-20	2026-06-20 03:15:01.441	2026-06-20 03:15:01.461	succeeded	1	\N	2026-06-20 03:15:01.441	2026-06-20 03:15:01.461
8504b31e-7e63-4a09-bc7f-b49b4403067e	analytics.snapshot	\N	2026-06-21	2026-06-21 01:00:01.674	2026-06-21 01:00:01.752	succeeded	1	\N	2026-06-21 01:00:01.674	2026-06-21 01:00:01.752
e4c388b5-dbd5-4094-9a78-b5437b83476c	probation.reminder	\N	2026-06-21	2026-06-21 01:15:00.566	2026-06-21 01:15:00.586	succeeded	1	\N	2026-06-21 01:15:00.566	2026-06-21 01:15:00.586
43fda576-c3e1-446b-b0a6-b332410288c3	1on1.reminder	\N	2026-06-21	2026-06-21 01:30:00.598	2026-06-21 01:30:00.63	succeeded	1	\N	2026-06-21 01:30:00.598	2026-06-21 01:30:00.63
f076f2f6-4497-4204-a51f-88b7ff44e118	review.reminder	\N	2026-06-21	2026-06-21 01:45:00.57	2026-06-21 01:45:00.589	succeeded	1	\N	2026-06-21 01:45:00.57	2026-06-21 01:45:00.589
0e06a025-70a3-48ec-a87d-42a92d92d505	signals.compute	\N	2026-06-21	2026-06-21 02:15:00.643	2026-06-21 02:15:00.673	succeeded	1	\N	2026-06-21 02:15:00.643	2026-06-21 02:15:00.673
2262e6a8-9fb7-4a9e-93e1-c1a299b57e84	selection.retention_outcomes	\N	2026-06-21	2026-06-21 02:30:00.579	2026-06-21 02:30:00.595	succeeded	1	\N	2026-06-21 02:30:00.579	2026-06-21 02:30:00.595
029ebad8-eed9-47a3-b8a7-b8b4f741baad	hh.sourcing	\N	2026-06-21	2026-06-21 03:15:00.657	2026-06-21 03:15:00.674	succeeded	1	\N	2026-06-21 03:15:00.657	2026-06-21 03:15:00.674
d37f8208-1aa6-4285-b875-d71db140c987	analytics.snapshot	\N	2026-06-22	2026-06-22 01:00:00.856	2026-06-22 01:00:00.937	succeeded	1	\N	2026-06-22 01:00:00.856	2026-06-22 01:00:00.937
2d8f2f7e-3c6c-4a0c-9ed4-3e6397c46659	probation.reminder	\N	2026-06-22	2026-06-22 01:15:00.863	2026-06-22 01:15:00.884	succeeded	1	\N	2026-06-22 01:15:00.863	2026-06-22 01:15:00.884
e970607b-fa78-48bc-ae0f-d97762bfa79a	1on1.reminder	\N	2026-06-22	2026-06-22 01:30:00.899	2026-06-22 01:30:00.937	succeeded	1	\N	2026-06-22 01:30:00.899	2026-06-22 01:30:00.937
4983600d-0e3f-43b8-afbb-1ecad96a9606	review.reminder	\N	2026-06-22	2026-06-22 01:45:00.884	2026-06-22 01:45:00.904	succeeded	1	\N	2026-06-22 01:45:00.884	2026-06-22 01:45:00.904
f661c8bf-ab93-44e6-9e50-5dcfe5773194	signals.compute	\N	2026-06-22	2026-06-22 02:15:00.901	2026-06-22 02:15:00.923	succeeded	1	\N	2026-06-22 02:15:00.901	2026-06-22 02:15:00.923
490e397c-a7d4-43b4-9173-cc8a779760dc	selection.retention_outcomes	\N	2026-06-22	2026-06-22 02:30:00.908	2026-06-22 02:30:00.931	succeeded	1	\N	2026-06-22 02:30:00.908	2026-06-22 02:30:00.931
4019592c-bea0-4216-8ee0-c24ba39f9183	selection.retention_calibration	\N	2026-06-22	2026-06-22 02:45:00.939	2026-06-22 02:45:00.997	succeeded	1	\N	2026-06-22 02:45:00.939	2026-06-22 02:45:00.997
b69892af-3bc5-44b1-b9b8-347e1757f025	hh.sourcing	\N	2026-06-22	2026-06-22 03:15:00.881	2026-06-22 03:15:00.896	succeeded	1	\N	2026-06-22 03:15:00.881	2026-06-22 03:15:00.896
ac7903af-f319-40f4-8f67-ef9429b5fb5d	analytics.snapshot	\N	2026-06-23	2026-06-23 01:00:01.286	2026-06-23 01:00:01.366	succeeded	1	\N	2026-06-23 01:00:01.286	2026-06-23 01:00:01.366
1b84b7c1-15cf-475c-bc50-175d9760efee	probation.reminder	\N	2026-06-23	2026-06-23 01:15:01.194	2026-06-23 01:15:01.219	succeeded	1	\N	2026-06-23 01:15:01.194	2026-06-23 01:15:01.219
61c3ef96-e60c-43d9-86bf-06dba6026840	1on1.reminder	\N	2026-06-23	2026-06-23 01:30:01.317	2026-06-23 01:30:01.352	succeeded	1	\N	2026-06-23 01:30:01.317	2026-06-23 01:30:01.352
00bd19b8-1f44-4923-b185-e21dc80b90ab	review.reminder	\N	2026-06-23	2026-06-23 01:45:01.2	2026-06-23 01:45:01.227	succeeded	1	\N	2026-06-23 01:45:01.2	2026-06-23 01:45:01.227
972c69be-b113-42f5-b9b0-e34ad0eef097	signals.compute	\N	2026-06-23	2026-06-23 02:15:01.35	2026-06-23 02:15:01.383	succeeded	1	\N	2026-06-23 02:15:01.35	2026-06-23 02:15:01.383
2cef2b6b-9893-4114-8b4e-9e1ba89e449e	selection.retention_outcomes	\N	2026-06-23	2026-06-23 02:30:01.205	2026-06-23 02:30:01.222	succeeded	1	\N	2026-06-23 02:30:01.205	2026-06-23 02:30:01.222
c3f6286d-b5e9-4320-8df5-51c2512a2ba6	hh.sourcing	\N	2026-06-23	2026-06-23 03:15:01.209	2026-06-23 03:15:01.229	succeeded	1	\N	2026-06-23 03:15:01.209	2026-06-23 03:15:01.229
bc9342c8-77a1-4439-9ae6-1048e2eb285b	analytics.snapshot	\N	2026-06-24	2026-06-24 01:00:01.548	2026-06-24 01:00:01.629	succeeded	1	\N	2026-06-24 01:00:01.548	2026-06-24 01:00:01.629
7120d47b-7041-42f2-ac76-1224727dc7e7	probation.reminder	\N	2026-06-24	2026-06-24 01:15:01.576	2026-06-24 01:15:01.606	succeeded	1	\N	2026-06-24 01:15:01.576	2026-06-24 01:15:01.606
9e136e16-1af0-4a9e-87f7-4835dc83fa7e	1on1.reminder	\N	2026-06-24	2026-06-24 01:30:01.583	2026-06-24 01:30:01.621	succeeded	1	\N	2026-06-24 01:30:01.583	2026-06-24 01:30:01.621
874b69c1-6ecb-45a8-9ec1-c0ca25df4850	review.reminder	\N	2026-06-24	2026-06-24 01:45:01.61	2026-06-24 01:45:01.633	succeeded	1	\N	2026-06-24 01:45:01.61	2026-06-24 01:45:01.633
1192fa89-c5bd-4568-9865-c43604c88a7e	signals.compute	\N	2026-06-24	2026-06-24 02:15:01.555	2026-06-24 02:15:01.585	succeeded	1	\N	2026-06-24 02:15:01.555	2026-06-24 02:15:01.585
b24f78a3-b2e6-43e0-9dda-f7b0dbe563a1	selection.retention_outcomes	\N	2026-06-24	2026-06-24 02:30:01.656	2026-06-24 02:30:01.687	succeeded	1	\N	2026-06-24 02:30:01.656	2026-06-24 02:30:01.687
53556030-b978-48a2-a39f-0d74a3cac7a4	hh.sourcing	\N	2026-06-24	2026-06-24 03:15:01.624	2026-06-24 03:15:01.644	succeeded	1	\N	2026-06-24 03:15:01.624	2026-06-24 03:15:01.644
55250ad4-97d5-4108-ac9d-f8cc2f19216f	analytics.snapshot	\N	2026-06-25	2026-06-25 01:00:00.851	2026-06-25 01:00:00.913	succeeded	1	\N	2026-06-25 01:00:00.851	2026-06-25 01:00:00.913
a0619a97-6efe-4f06-818c-da80253819fe	probation.reminder	\N	2026-06-25	2026-06-25 01:15:00.789	2026-06-25 01:15:00.814	succeeded	1	\N	2026-06-25 01:15:00.789	2026-06-25 01:15:00.814
5f7a9025-db77-4ca6-863b-89895e635702	1on1.reminder	\N	2026-06-25	2026-06-25 01:30:00.835	2026-06-25 01:30:00.864	succeeded	1	\N	2026-06-25 01:30:00.835	2026-06-25 01:30:00.864
2d982719-27a0-4969-9b56-1111a98784e7	review.reminder	\N	2026-06-25	2026-06-25 01:45:00.883	2026-06-25 01:45:00.902	succeeded	1	\N	2026-06-25 01:45:00.883	2026-06-25 01:45:00.902
264b2906-a870-4d86-8c8d-50907ddfb007	signals.compute	\N	2026-06-25	2026-06-25 02:15:00.857	2026-06-25 02:15:00.884	succeeded	1	\N	2026-06-25 02:15:00.857	2026-06-25 02:15:00.884
f18d07af-c06b-4416-8cd2-38cf88f16b53	selection.retention_outcomes	\N	2026-06-25	2026-06-25 02:30:00.874	2026-06-25 02:30:00.894	succeeded	1	\N	2026-06-25 02:30:00.874	2026-06-25 02:30:00.894
efd04cd0-9946-4816-8e37-4caed609f5a4	hh.sourcing	\N	2026-06-25	2026-06-25 03:15:00.905	2026-06-25 03:15:00.923	succeeded	1	\N	2026-06-25 03:15:00.905	2026-06-25 03:15:00.923
77ef1ccc-f1b2-48cc-9192-7128f947606d	analytics.snapshot	\N	2026-06-26	2026-06-26 01:00:01.168	2026-06-26 01:00:01.236	succeeded	1	\N	2026-06-26 01:00:01.168	2026-06-26 01:00:01.236
53a6918a-7716-42ce-b51d-286096f72d9f	probation.reminder	\N	2026-06-26	2026-06-26 01:15:01.149	2026-06-26 01:15:01.173	succeeded	1	\N	2026-06-26 01:15:01.149	2026-06-26 01:15:01.173
77c0be9c-6039-4320-a11a-f638470015a9	1on1.reminder	\N	2026-06-26	2026-06-26 01:30:01.19	2026-06-26 01:30:01.218	succeeded	1	\N	2026-06-26 01:30:01.19	2026-06-26 01:30:01.218
700aa4ed-a482-42dd-9fbb-c86aa482ff5f	review.reminder	\N	2026-06-26	2026-06-26 01:45:01.163	2026-06-26 01:45:01.198	succeeded	1	\N	2026-06-26 01:45:01.163	2026-06-26 01:45:01.198
24cc8d09-149d-47e9-a0b4-2056626c17b1	signals.compute	\N	2026-06-26	2026-06-26 02:15:01.186	2026-06-26 02:15:01.218	succeeded	1	\N	2026-06-26 02:15:01.186	2026-06-26 02:15:01.218
701997c6-2111-4a0b-b989-ef98bce47c86	selection.retention_outcomes	\N	2026-06-26	2026-06-26 02:30:01.193	2026-06-26 02:30:01.213	succeeded	1	\N	2026-06-26 02:30:01.193	2026-06-26 02:30:01.213
314dabdd-a9ff-433d-99f3-86c54608bf12	hh.sourcing	\N	2026-06-26	2026-06-26 03:15:01.142	2026-06-26 03:15:01.164	succeeded	1	\N	2026-06-26 03:15:01.142	2026-06-26 03:15:01.164
8ce09b77-7fd1-4460-8cf9-ca72080330c9	analytics.snapshot	\N	2026-06-27	2026-06-27 01:00:01.411	2026-06-27 01:00:01.481	succeeded	1	\N	2026-06-27 01:00:01.411	2026-06-27 01:00:01.481
65cb511d-2213-44d3-8bb5-5499ba04d004	probation.reminder	\N	2026-06-27	2026-06-27 01:15:01.473	2026-06-27 01:15:01.506	succeeded	1	\N	2026-06-27 01:15:01.473	2026-06-27 01:15:01.506
88df73e8-cf52-47c1-ab04-a894b46e0a1a	1on1.reminder	\N	2026-06-27	2026-06-27 01:30:01.488	2026-06-27 01:30:01.528	succeeded	1	\N	2026-06-27 01:30:01.488	2026-06-27 01:30:01.528
244e69e2-b58a-4f33-a886-949a702d8ac2	review.reminder	\N	2026-06-27	2026-06-27 01:45:01.455	2026-06-27 01:45:01.482	succeeded	1	\N	2026-06-27 01:45:01.455	2026-06-27 01:45:01.482
96e8c525-f491-455c-9eff-c6f3b3e3ba4b	signals.compute	\N	2026-06-27	2026-06-27 02:15:01.493	2026-06-27 02:15:01.525	succeeded	1	\N	2026-06-27 02:15:01.493	2026-06-27 02:15:01.525
3ad21b55-2e6d-4547-96e0-3ffe01493bb5	selection.retention_outcomes	\N	2026-06-27	2026-06-27 02:30:01.505	2026-06-27 02:30:01.525	succeeded	1	\N	2026-06-27 02:30:01.505	2026-06-27 02:30:01.525
ee02cf24-1e0f-4ac7-97ef-fb6fa2d63c27	hh.sourcing	\N	2026-06-27	2026-06-27 03:15:01.563	2026-06-27 03:15:01.592	succeeded	1	\N	2026-06-27 03:15:01.563	2026-06-27 03:15:01.592
86d2f88e-6020-47c1-a507-797d33058aff	analytics.snapshot	\N	2026-06-28	2026-06-28 01:00:00.81	2026-06-28 01:00:00.878	succeeded	1	\N	2026-06-28 01:00:00.81	2026-06-28 01:00:00.878
288870d0-1772-4b50-8553-1e31627e09cb	probation.reminder	\N	2026-06-28	2026-06-28 01:15:00.768	2026-06-28 01:15:00.799	succeeded	1	\N	2026-06-28 01:15:00.768	2026-06-28 01:15:00.799
bf1907f5-6e89-4e01-9a6a-24dc2833bba2	1on1.reminder	\N	2026-06-28	2026-06-28 01:30:00.798	2026-06-28 01:30:00.827	succeeded	1	\N	2026-06-28 01:30:00.798	2026-06-28 01:30:00.827
d54497eb-d9aa-47f8-8e56-b9d880c22957	review.reminder	\N	2026-06-28	2026-06-28 01:45:00.774	2026-06-28 01:45:00.799	succeeded	1	\N	2026-06-28 01:45:00.774	2026-06-28 01:45:00.799
124ec5df-1c3d-46ee-99af-7bf1e54c2ba7	signals.compute	\N	2026-06-28	2026-06-28 02:15:00.71	2026-06-28 02:15:00.731	succeeded	1	\N	2026-06-28 02:15:00.71	2026-06-28 02:15:00.731
e217180c-b3b6-4c66-b246-f767a0daa010	selection.retention_outcomes	\N	2026-06-28	2026-06-28 02:30:00.818	2026-06-28 02:30:00.838	succeeded	1	\N	2026-06-28 02:30:00.818	2026-06-28 02:30:00.838
7d97421d-9ca9-4024-b652-ea6619359994	hh.sourcing	\N	2026-06-28	2026-06-28 03:15:00.782	2026-06-28 03:15:00.801	succeeded	1	\N	2026-06-28 03:15:00.782	2026-06-28 03:15:00.801
f36e6f39-8efe-4144-a1f9-d1fb1ef127a3	analytics.snapshot	\N	2026-06-29	2026-06-29 01:00:01.007	2026-06-29 01:00:01.073	succeeded	1	\N	2026-06-29 01:00:01.007	2026-06-29 01:00:01.073
4f375a4f-9526-4fb1-b17d-4f439d766d50	probation.reminder	\N	2026-06-29	2026-06-29 01:15:00.979	2026-06-29 01:15:01	succeeded	1	\N	2026-06-29 01:15:00.979	2026-06-29 01:15:01
4b626831-ad23-4d6e-ba19-9ab787af1813	1on1.reminder	\N	2026-06-29	2026-06-29 01:30:00.993	2026-06-29 01:30:01.019	succeeded	1	\N	2026-06-29 01:30:00.993	2026-06-29 01:30:01.019
ddc778c9-b35c-4fc6-aa12-f113f0fadbbf	review.reminder	\N	2026-06-29	2026-06-29 01:45:01.036	2026-06-29 01:45:01.065	succeeded	1	\N	2026-06-29 01:45:01.036	2026-06-29 01:45:01.065
f3536813-68f2-40b0-b62d-c4c52618aadf	signals.compute	\N	2026-06-29	2026-06-29 02:15:01.061	2026-06-29 02:15:01.087	succeeded	1	\N	2026-06-29 02:15:01.061	2026-06-29 02:15:01.087
971c5828-af21-4651-a9af-e3db40cd2db6	selection.retention_outcomes	\N	2026-06-29	2026-06-29 02:30:01.098	2026-06-29 02:30:01.117	succeeded	1	\N	2026-06-29 02:30:01.098	2026-06-29 02:30:01.117
a9a716dc-fa92-42d1-8aac-5f380aad3195	selection.retention_calibration	\N	2026-06-29	2026-06-29 02:45:01.013	2026-06-29 02:45:01.054	succeeded	1	\N	2026-06-29 02:45:01.013	2026-06-29 02:45:01.054
1238f4c4-ea9d-4c38-b1eb-7d011ab35c33	hh.sourcing	\N	2026-06-29	2026-06-29 03:15:01.082	2026-06-29 03:15:01.105	succeeded	1	\N	2026-06-29 03:15:01.082	2026-06-29 03:15:01.105
9fc52a9d-bb0a-472f-95ce-838c4d1c61ca	analytics.snapshot	\N	2026-06-30	2026-06-30 01:00:01.357	2026-06-30 01:00:01.445	succeeded	1	\N	2026-06-30 01:00:01.357	2026-06-30 01:00:01.445
cab5db04-0ec7-4213-bfb2-78429fe8d24b	probation.reminder	\N	2026-06-30	2026-06-30 01:15:01.31	2026-06-30 01:15:01.344	succeeded	1	\N	2026-06-30 01:15:01.31	2026-06-30 01:15:01.344
ac6015a9-73d5-44ba-905c-93e75009a8f6	1on1.reminder	\N	2026-06-30	2026-06-30 01:30:01.373	2026-06-30 01:30:01.407	succeeded	1	\N	2026-06-30 01:30:01.373	2026-06-30 01:30:01.407
877b9e96-d963-48ce-aa2d-32e9fe2009cb	review.reminder	\N	2026-06-30	2026-06-30 01:45:01.323	2026-06-30 01:45:01.348	succeeded	1	\N	2026-06-30 01:45:01.323	2026-06-30 01:45:01.348
6d6951e5-4479-4022-8919-25244522e844	signals.compute	\N	2026-06-30	2026-06-30 02:15:01.385	2026-06-30 02:15:01.413	succeeded	1	\N	2026-06-30 02:15:01.385	2026-06-30 02:15:01.413
f7ffad81-902d-499f-b33d-9d1e5fdf92c0	selection.retention_outcomes	\N	2026-06-30	2026-06-30 02:30:01.345	2026-06-30 02:30:01.373	succeeded	1	\N	2026-06-30 02:30:01.345	2026-06-30 02:30:01.373
8a93ed12-d1bd-425c-8fe1-7206261f7177	hh.sourcing	\N	2026-06-30	2026-06-30 03:15:01.372	2026-06-30 03:15:01.397	succeeded	1	\N	2026-06-30 03:15:01.372	2026-06-30 03:15:01.397
0099cb8c-6c37-420d-8c30-88407aafc280	analytics.snapshot	\N	2026-07-01	2026-07-01 01:00:01.628	2026-07-01 01:00:01.697	succeeded	1	\N	2026-07-01 01:00:01.628	2026-07-01 01:00:01.697
5129fd85-1669-422c-a97a-bde0ecdffb10	1on1.reminder	\N	2026-07-01	2026-07-01 01:30:01.86	2026-07-01 01:30:01.914	succeeded	1	\N	2026-07-01 01:30:01.86	2026-07-01 01:30:01.914
e32515a1-4ba6-439a-a110-5d6c2b9f0d58	review.reminder	\N	2026-07-01	2026-07-01 01:45:00.587	2026-07-01 01:45:00.608	succeeded	1	\N	2026-07-01 01:45:00.587	2026-07-01 01:45:00.608
34383c27-5bd2-4a3c-8e10-7d3821fe7481	data.retention	\N	2026-07	2026-07-01 02:00:00.602	2026-07-01 02:00:00.636	succeeded	1	\N	2026-07-01 02:00:00.602	2026-07-01 02:00:00.636
a809a337-fe98-4723-9a06-2bc3f77afb96	signals.compute	\N	2026-07-01	2026-07-01 02:15:00.59	2026-07-01 02:15:00.619	succeeded	1	\N	2026-07-01 02:15:00.59	2026-07-01 02:15:00.619
644c4fde-dc81-4823-b1f1-82f3b1575223	selection.retention_outcomes	\N	2026-07-01	2026-07-01 02:30:00.611	2026-07-01 02:30:00.626	succeeded	1	\N	2026-07-01 02:30:00.611	2026-07-01 02:30:00.626
601c4980-5c77-4087-8600-fba9b5115113	okr.quarter_start	\N	2026-07-01	2026-07-01 03:00:00.728	2026-07-01 03:00:00.757	succeeded	1	\N	2026-07-01 03:00:00.728	2026-07-01 03:00:00.757
6ab67499-54a3-4d73-9cf6-82350424bcaa	hh.sourcing	\N	2026-07-01	2026-07-01 03:15:00.58	2026-07-01 03:15:00.598	succeeded	1	\N	2026-07-01 03:15:00.58	2026-07-01 03:15:00.598
4ee7b2d7-f272-49f7-9dbf-8c989065c618	analytics.snapshot	\N	2026-07-02	2026-07-02 01:00:00.917	2026-07-02 01:00:00.979	succeeded	1	\N	2026-07-02 01:00:00.917	2026-07-02 01:00:00.979
5c8b421c-3079-424e-afba-e338c6a01d53	probation.reminder	\N	2026-07-02	2026-07-02 01:15:00.828	2026-07-02 01:15:00.851	succeeded	1	\N	2026-07-02 01:15:00.828	2026-07-02 01:15:00.851
9ad3905c-a25a-4a29-9ed0-e4394ee43558	1on1.reminder	\N	2026-07-02	2026-07-02 01:30:00.871	2026-07-02 01:30:00.904	succeeded	1	\N	2026-07-02 01:30:00.871	2026-07-02 01:30:00.904
88d53f8b-cc35-4818-aa1a-ff09847a6ae3	review.reminder	\N	2026-07-02	2026-07-02 01:45:00.902	2026-07-02 01:45:00.926	succeeded	1	\N	2026-07-02 01:45:00.902	2026-07-02 01:45:00.926
0acf5b85-89c6-48e2-b3e9-a9b545db6839	signals.compute	\N	2026-07-02	2026-07-02 02:15:00.968	2026-07-02 02:15:00.998	succeeded	1	\N	2026-07-02 02:15:00.968	2026-07-02 02:15:00.998
a2ddd133-4f4d-467d-bca7-06749e618cb9	selection.retention_outcomes	\N	2026-07-02	2026-07-02 02:30:00.985	2026-07-02 02:30:01.007	succeeded	1	\N	2026-07-02 02:30:00.985	2026-07-02 02:30:01.007
bd546381-7897-4b37-a63d-b9d5cd784f60	hh.sourcing	\N	2026-07-02	2026-07-02 03:15:00.893	2026-07-02 03:15:00.913	succeeded	1	\N	2026-07-02 03:15:00.893	2026-07-02 03:15:00.913
7cb65f02-6b16-42e9-ac32-c4e729ff51b4	analytics.snapshot	\N	2026-07-03	2026-07-03 01:00:01.222	2026-07-03 01:00:01.303	succeeded	1	\N	2026-07-03 01:00:01.222	2026-07-03 01:00:01.303
2f087330-a128-40ea-b5d5-8e69daac44d1	probation.reminder	\N	2026-07-03	2026-07-03 01:15:01.089	2026-07-03 01:15:01.112	succeeded	1	\N	2026-07-03 01:15:01.089	2026-07-03 01:15:01.112
da2c75f1-ca03-4336-92ab-6a0a66a4bab9	1on1.reminder	\N	2026-07-03	2026-07-03 01:30:01.117	2026-07-03 01:30:01.15	succeeded	1	\N	2026-07-03 01:30:01.117	2026-07-03 01:30:01.15
f85b22fc-82e7-4567-a472-ac0d9fa9c893	review.reminder	\N	2026-07-03	2026-07-03 01:45:01.129	2026-07-03 01:45:01.153	succeeded	1	\N	2026-07-03 01:45:01.129	2026-07-03 01:45:01.153
74851c6d-a6c9-4df7-b551-ac98bd0cf8d8	signals.compute	\N	2026-07-03	2026-07-03 02:15:01.126	2026-07-03 02:15:01.154	succeeded	1	\N	2026-07-03 02:15:01.126	2026-07-03 02:15:01.154
b8dc7ef8-7d58-487b-832c-42a276b70285	selection.retention_outcomes	\N	2026-07-03	2026-07-03 02:30:01.204	2026-07-03 02:30:01.223	succeeded	1	\N	2026-07-03 02:30:01.204	2026-07-03 02:30:01.223
9646a1e7-aa80-41dd-b52c-28601d287eb3	hh.sourcing	\N	2026-07-03	2026-07-03 03:15:01.159	2026-07-03 03:15:01.178	succeeded	1	\N	2026-07-03 03:15:01.159	2026-07-03 03:15:01.178
ad2b1d46-51a1-40f2-8c84-5e1d2a383ca3	analytics.snapshot	\N	2026-07-04	2026-07-04 01:00:01.405	2026-07-04 01:00:01.475	succeeded	1	\N	2026-07-04 01:00:01.405	2026-07-04 01:00:01.475
b5b465de-41c7-47cd-b476-72da54234316	probation.reminder	\N	2026-07-04	2026-07-04 01:15:01.422	2026-07-04 01:15:01.447	succeeded	1	\N	2026-07-04 01:15:01.422	2026-07-04 01:15:01.447
dd635a00-23e8-498a-83e1-bc35ea978a89	1on1.reminder	\N	2026-07-04	2026-07-04 01:30:01.397	2026-07-04 01:30:01.43	succeeded	1	\N	2026-07-04 01:30:01.397	2026-07-04 01:30:01.43
40b6dd43-9be8-4cc2-b68d-5bfcaec28463	review.reminder	\N	2026-07-04	2026-07-04 01:45:01.475	2026-07-04 01:45:01.5	succeeded	1	\N	2026-07-04 01:45:01.475	2026-07-04 01:45:01.5
94a4816e-9cf1-43b5-b266-cbe937347799	signals.compute	\N	2026-07-04	2026-07-04 02:15:01.416	2026-07-04 02:15:01.439	succeeded	1	\N	2026-07-04 02:15:01.416	2026-07-04 02:15:01.439
ec16b6ec-f35c-4782-abb3-a851de5422e0	selection.retention_outcomes	\N	2026-07-04	2026-07-04 02:30:01.425	2026-07-04 02:30:01.45	succeeded	1	\N	2026-07-04 02:30:01.425	2026-07-04 02:30:01.45
5f334277-4b9d-4d6f-985d-54581b373642	hh.sourcing	\N	2026-07-04	2026-07-04 03:15:01.495	2026-07-04 03:15:01.518	succeeded	1	\N	2026-07-04 03:15:01.495	2026-07-04 03:15:01.518
8f51ab7b-bade-4405-8d63-7c72f198bd00	analytics.snapshot	\N	2026-07-05	2026-07-05 01:00:00.634	2026-07-05 01:00:00.708	succeeded	1	\N	2026-07-05 01:00:00.634	2026-07-05 01:00:00.708
412a123a-93ec-49de-866e-a56772dec667	probation.reminder	\N	2026-07-05	2026-07-05 01:15:00.661	2026-07-05 01:15:00.681	succeeded	1	\N	2026-07-05 01:15:00.661	2026-07-05 01:15:00.681
d43981d0-c757-4ba8-a77a-8686f69505d9	1on1.reminder	\N	2026-07-05	2026-07-05 01:30:00.764	2026-07-05 01:30:00.795	succeeded	1	\N	2026-07-05 01:30:00.764	2026-07-05 01:30:00.795
0683c6f3-651f-402a-8cdf-c150c1d429ce	review.reminder	\N	2026-07-05	2026-07-05 01:45:00.665	2026-07-05 01:45:00.689	succeeded	1	\N	2026-07-05 01:45:00.665	2026-07-05 01:45:00.689
36d1a9a2-d6a9-47b6-9f14-068dd19995b1	signals.compute	\N	2026-07-05	2026-07-05 02:15:00.656	2026-07-05 02:15:00.684	succeeded	1	\N	2026-07-05 02:15:00.656	2026-07-05 02:15:00.684
7c2cf0f2-c441-49ef-ac15-0f5b2e8ee9a3	selection.retention_outcomes	\N	2026-07-05	2026-07-05 02:30:00.695	2026-07-05 02:30:00.716	succeeded	1	\N	2026-07-05 02:30:00.695	2026-07-05 02:30:00.716
923ec007-a468-4e9c-9d4f-37a5ec058b03	hh.sourcing	\N	2026-07-05	2026-07-05 03:15:00.696	2026-07-05 03:15:00.713	succeeded	1	\N	2026-07-05 03:15:00.696	2026-07-05 03:15:00.713
\.


--
-- Data for Name: data_retention_policies; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.data_retention_policies (id, tenant_id, entity_type, retain_days, anonymize, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: device_tokens; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.device_tokens (id, tenant_id, user_id, platform, token, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_lifecycle_events; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.employee_lifecycle_events (id, tenant_id, employee_id, type, from_status, to_status, effective_at, actor_user_id, payload, note, created_at) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.employees (id, tenant_id, user_id, application_id, org_unit_id, full_name, email, phone, job_title, employment_type, status, hire_date, probation_ends_at, probation_outcome, terminated_at, termination_ground, termination_note, created_at, updated_at, candidate_id, requisition_id, grade, currency, agreed_base_salary, agreed_start_date, role_family) FROM stdin;
\.


--
-- Data for Name: employment_documents; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.employment_documents (id, tenant_id, employee_id, type, status, title, file_url, metadata, issued_at, signed_at, expires_at, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exit_interviews; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.exit_interviews (id, tenant_id, employee_id, conducted_by_user_id, conducted_at, reason_category, notes, would_rehire, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: external_vacancy_posts; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.external_vacancy_posts (id, tenant_id, vacancy_id, board, external_id, status, last_error, last_synced_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: hh_connections; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.hh_connections (id, tenant_id, access_token, refresh_token, token_expires_at, connected_employer_id, created_at, updated_at) FROM stdin;
019e8d06-7d3b-78d5-9c28-df95e927dafc	019e72e8-7296-7d04-86de-6766827d80f8	v1.TtMtJYBR5b5_OxvU.3dHUgl9CWSYbHPxyDuocYQ.RHo_ncMgMkhDTFEGprQk4sDrKOnULwQCXXm_kUiOl1-oZ2f6jAr5zO1KBME6IaXxNY81_-ZZSazC1_q2am0tGA	v1.AhvZSeRXHBZOgMd5.FK0-Ym6JH21l04JWterUGA.RJUL_3G-0kli0VpBTaTefdbnb3QimRzmRmA4ByGYexTFAhdHsJOEwWH_6rTcqoCnvSkDoB3wLzWXVtE_cB3iVA	2026-07-19 14:30:36.719	11044582	2026-06-03 10:27:53.273	2026-07-05 14:30:37.724
\.


--
-- Data for Name: hh_sync_cursors; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.hh_sync_cursors (id, tenant_id, vacancy_id, last_synced_at, last_negotiation_id, created_at, updated_at) FROM stdin;
019f32cc-cd97-7ad8-967e-93d208df415e	019e72e8-7296-7d04-86de-6766827d80f8	019e8d16-224f-77a8-b24d-4de278134fd3	2026-07-05 14:16:20	5409206234	2026-07-05 15:01:50.611	2026-07-05 15:01:50.611
\.


--
-- Data for Name: hiring_requisitions; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.hiring_requisitions (id, tenant_id, org_unit_id, created_by_user_id, title, grade, salary_min, salary_max, currency, justification, status, deadline_at, created_at, updated_at) FROM stdin;
019e8d15-f68a-7485-b1d2-a43c965dfc1f	019e72e8-7296-7d04-86de-6766827d80f8	019e8d14-53b6-7e8d-8b82-0ecc4c788206	019e72e8-735d-7c54-b229-08222aa2c6ca	Логист	М1	80000	300000	RUB	Расширение 	in_recruitment	2026-06-30 00:00:00	2026-06-03 10:44:47.367	2026-06-03 10:45:00.425
\.


--
-- Data for Name: hr_snapshots; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.hr_snapshots (id, tenant_id, snapshot_date, headcount, headcount_by_status, headcount_by_org_unit, open_requisitions, hired_mtd, terminated_mtd, avg_time_to_hire_days, probation_pass_rate_qtd, created_at) FROM stdin;
019e7354-f462-721d-8afd-18928702995c	019e72e8-7296-7d04-86de-6766827d80f8	2026-05-29	0	{}	{}	0	0	0	\N	\N	2026-05-29 10:43:27.966
019e8d10-6c3d-7c14-92dd-d301bc195ac4	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-03	0	{}	{}	0	0	0	\N	\N	2026-06-03 10:38:44.281
019e92fa-9bc4-741b-9f00-e1e765f74ef3	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-04	0	{}	{}	1	0	0	\N	\N	2026-06-04 14:12:37.951
019e959b-8b68-73d0-aabd-4ceabaa5bd3d	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-05	0	{}	{}	1	0	0	\N	\N	2026-06-05 02:27:39.493
019e9a71-abb4-7593-9f9e-82f2d30aae9d	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-06	0	{}	{}	1	0	0	\N	\N	2026-06-06 01:00:01.322
019e9f98-071b-7e4a-9e27-44a45d8f39eb	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-07	0	{}	{}	1	0	0	\N	\N	2026-06-07 01:00:01.169
019ea4be-6667-7fad-8837-0777b4e3d984	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-08	0	{}	{}	1	0	0	\N	\N	2026-06-08 01:00:02
019ea9e4-bdf3-7f40-8797-42e964fb63de	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-09	0	{}	{}	1	0	0	\N	\N	2026-06-09 01:00:00.877
019eaf0b-1bf3-72d8-825e-e36c6cb35476	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-10	0	{}	{}	1	0	0	\N	\N	2026-06-10 01:00:01.387
019eb431-7864-7394-8587-aa326bdd01c2	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-11	0	{}	{}	1	0	0	\N	\N	2026-06-11 01:00:01.499
019eb957-d258-7539-b878-0d0193f20d0c	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-12	0	{}	{}	1	0	0	\N	\N	2026-06-12 01:00:00.976
019ebe7e-2f1f-7d78-a3b3-2e90d615ec78	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-13	0	{}	{}	1	0	0	\N	\N	2026-06-13 01:00:01.175
019ec3a4-8c40-7ce9-841d-91ec6a84b080	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-14	0	{}	{}	1	0	0	\N	\N	2026-06-14 01:00:01.465
019ec8ca-e5c2-7aa6-abed-3ad7acd0dff1	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-15	0	{}	{}	1	0	0	\N	\N	2026-06-15 01:00:00.828
019ecdf1-4386-7dbd-a359-9265fc3bc8a3	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-16	0	{}	{}	1	0	0	\N	\N	2026-06-16 01:00:01.275
019ed317-a09f-752b-bc66-648dd7dc62fb	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-17	0	{}	{}	1	0	0	\N	\N	2026-06-17 01:00:01.557
019ed83d-f96f-7554-b97d-dfc5896ba212	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-18	0	{}	{}	1	0	0	\N	\N	2026-06-18 01:00:00.746
019edd64-56bc-766f-9f8e-a7f9190e8e31	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-19	0	{}	{}	1	0	0	\N	\N	2026-06-19 01:00:01.077
019ee28a-b3fd-79f8-a31e-2f7d96034b1a	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-20	0	{}	{}	1	0	0	\N	\N	2026-06-20 01:00:01.397
019ee7b1-1151-7325-9577-a5ccbf0cde06	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-21	0	{}	{}	1	0	0	\N	\N	2026-06-21 01:00:01.737
019eecd7-6a22-75a1-ab80-b3d2a3c25c2e	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-22	0	{}	{}	1	0	0	\N	\N	2026-06-22 01:00:00.922
019ef1fd-c7cf-7e00-9c3e-8922cf78be58	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-23	0	{}	{}	1	0	0	\N	\N	2026-06-23 01:00:01.354
019ef724-24d4-777d-8701-9c05c1ff00e4	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-24	0	{}	{}	1	0	0	\N	\N	2026-06-24 01:00:01.614
019efc4a-7e0c-7565-8f08-34901430979f	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-25	0	{}	{}	1	0	0	\N	\N	2026-06-25 01:00:00.902
019f0170-db4c-742a-8f5c-2b4265fc7cf7	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-26	0	{}	{}	1	0	0	\N	\N	2026-06-26 01:00:01.223
019f0697-3843-7e49-9765-7857755d3819	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-27	0	{}	{}	1	0	0	\N	\N	2026-06-27 01:00:01.471
019f0bbd-91e9-7d30-bd1f-1966f7b0dcbc	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-28	0	{}	{}	1	0	0	\N	\N	2026-06-28 01:00:00.867
019f10e3-eeac-7299-b6c9-50a63b66d75c	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-29	0	{}	{}	1	0	0	\N	\N	2026-06-29 01:00:01.062
019f160a-4c1c-732b-a340-bd5d08a4362c	019e72e8-7296-7d04-86de-6766827d80f8	2026-06-30	0	{}	{}	1	0	0	\N	\N	2026-06-30 01:00:01.427
019f1b30-a91a-763e-aa5f-af34349ccd8f	019e72e8-7296-7d04-86de-6766827d80f8	2026-07-01	0	{}	{}	1	0	0	\N	\N	2026-07-01 01:00:01.684
019f2057-0249-7b21-86a3-1593d4f5a337	019e72e8-7296-7d04-86de-6766827d80f8	2026-07-02	0	{}	{}	1	0	0	\N	\N	2026-07-02 01:00:00.964
019f257d-5f91-72b4-8136-6d902b813b27	019e72e8-7296-7d04-86de-6766827d80f8	2026-07-03	0	{}	{}	1	0	0	\N	\N	2026-07-03 01:00:01.289
019f2aa3-bc3c-77b0-a7b5-b5ea6722c81e	019e72e8-7296-7d04-86de-6766827d80f8	2026-07-04	0	{}	{}	1	0	0	\N	\N	2026-07-04 01:00:01.462
019f2fca-153f-7185-85df-2f76315363e2	019e72e8-7296-7d04-86de-6766827d80f8	2026-07-05	0	{}	{}	1	0	0	\N	\N	2026-07-05 01:00:00.697
\.


--
-- Data for Name: idp_items; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.idp_items (id, tenant_id, idp_id, title, description, status, due_date, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: idps; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.idps (id, tenant_id, employee_id, quarter, summary, status, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: interviews; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.interviews (id, tenant_id, application_id, scheduled_at, recording_url, consent_recorded, status, transcript, protocol, offer_draft, created_by_user_id, created_at, updated_at) FROM stdin;
019f357c-c9b6-755d-8c3b-7aec84e5a71c	019e72e8-7296-7d04-86de-6766827d80f8	019f32cc-c8ee-744e-a7a6-812dbd88314f	\N	\N	t	created	\N	\N	\N	019f324a-0df9-7a4a-835a-f6f742e2d659	2026-07-06 03:33:18.387	2026-07-06 03:33:34.744
\.


--
-- Data for Name: key_results; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.key_results (id, tenant_id, okr_id, title, unit, start_value, target_value, current_value, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_articles; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.knowledge_articles (id, tenant_id, title, body, tags, visibility, created_by_user_id, updated_by_user_id, deleted_at, created_at, updated_at, search_vector) FROM stdin;
\.


--
-- Data for Name: learning_assignments; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.learning_assignments (id, tenant_id, employee_id, course_id, path_id, status, progress_percent, score, due_date, started_at, completed_at, assigned_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: learning_courses; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.learning_courses (id, tenant_id, title, description, content_type, content_url, duration_minutes, is_mandatory, org_unit_id, created_by_user_id, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: learning_path_items; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.learning_path_items (id, tenant_id, path_id, course_id, item_order, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: learning_paths; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.learning_paths (id, tenant_id, title, description, role_family, auto_assign, created_by_user_id, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: message_templates; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.message_templates (id, tenant_id, name, channel, subject, body, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.messages (id, tenant_id, conversation_id, channel, direction, body, sender_user_id, external_id, status, sent_at, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.notifications (id, tenant_id, recipient_user_id, channel, template, payload, read_at, created_at) FROM stdin;
019f32cc-c457-764e-ad19-1620428c25da	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Влада Московкина applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c3eb-7fa9-a694-bd52a1884a27", "applicationId": "019f32cc-c40d-773f-9c71-e1a661d3e493", "conversationId": "019f32cc-c436-77d0-9bde-ecd4835c01f3"}	\N	2026-07-05 15:01:48.24
019f32cc-c47f-7c8f-9452-30e343ccc803	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Влада Московкина applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c3eb-7fa9-a694-bd52a1884a27", "applicationId": "019f32cc-c40d-773f-9c71-e1a661d3e493", "conversationId": "019f32cc-c436-77d0-9bde-ecd4835c01f3"}	\N	2026-07-05 15:01:48.24
019f32cc-c5b8-7d73-bd1e-65587d2f7c52	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Андрей Крылов applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c53f-71a9-bdd8-26b660dc737a", "applicationId": "019f32cc-c586-7566-8b94-75ed1e04e42d", "conversationId": "019f32cc-c5b1-7fc8-bf2c-a9111a85bf1a"}	\N	2026-07-05 15:01:48.599
019f32cc-c5bc-776b-b239-f8f13ac0f2f5	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Андрей Крылов applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c53f-71a9-bdd8-26b660dc737a", "applicationId": "019f32cc-c586-7566-8b94-75ed1e04e42d", "conversationId": "019f32cc-c5b1-7fc8-bf2c-a9111a85bf1a"}	\N	2026-07-05 15:01:48.599
019f32cc-c69f-75d2-8f78-5305cd1729ff	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Андрей Денискин applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c679-7ea2-9534-0c29e5f362b4", "applicationId": "019f32cc-c686-721f-b2ed-8e74ef2a140d", "conversationId": "019f32cc-c697-7483-8858-fc898e7f1214"}	\N	2026-07-05 15:01:48.83
019f32cc-c6a0-7561-9284-cd7d9042ecc8	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Андрей Денискин applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c679-7ea2-9534-0c29e5f362b4", "applicationId": "019f32cc-c686-721f-b2ed-8e74ef2a140d", "conversationId": "019f32cc-c697-7483-8858-fc898e7f1214"}	\N	2026-07-05 15:01:48.83
019f32cc-c76e-70c3-8620-eabc58e02ee7	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Георгий Гергешания applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c751-72d0-93db-2f7c59349d4f", "applicationId": "019f32cc-c75b-7fc6-a540-cb753cc79f62", "conversationId": "019f32cc-c76b-7722-ba70-8c88dee7c6c5"}	\N	2026-07-05 15:01:49.037
019f32cc-c770-7ee7-977e-ec3d80e3f787	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Георгий Гергешания applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c751-72d0-93db-2f7c59349d4f", "applicationId": "019f32cc-c75b-7fc6-a540-cb753cc79f62", "conversationId": "019f32cc-c76b-7722-ba70-8c88dee7c6c5"}	\N	2026-07-05 15:01:49.037
019f32cc-c835-7194-85c0-9f0aa358e670	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Филипп Разаренов applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c81d-76ef-b56f-5af440fa602d", "applicationId": "019f32cc-c825-7778-b131-e12c9dc892e7", "conversationId": "019f32cc-c830-78b1-9b66-c036cab2e355"}	\N	2026-07-05 15:01:49.235
019f32cc-c835-799f-bffd-873f00f1a8a9	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Филипп Разаренов applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c81d-76ef-b56f-5af440fa602d", "applicationId": "019f32cc-c825-7778-b131-e12c9dc892e7", "conversationId": "019f32cc-c830-78b1-9b66-c036cab2e355"}	\N	2026-07-05 15:01:49.235
019f32cc-c8fc-79ab-a8e9-cf3c607085c5	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Сeргeй Мирoшничeнкo applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c8e8-79b5-b6cd-5a1fa6c7a877", "applicationId": "019f32cc-c8ee-744e-a7a6-812dbd88314f", "conversationId": "019f32cc-c8f5-7473-8632-170a15f797e5"}	\N	2026-07-05 15:01:49.435
019f32cc-c8fd-7fc9-9ce2-50c647d0c693	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Сeргeй Мирoшничeнкo applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c8e8-79b5-b6cd-5a1fa6c7a877", "applicationId": "019f32cc-c8ee-744e-a7a6-812dbd88314f", "conversationId": "019f32cc-c8f5-7473-8632-170a15f797e5"}	\N	2026-07-05 15:01:49.435
019f32cc-c9dc-790a-8d3d-9f96060f1c93	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Алексей Фещенко applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c9b8-773a-a7f3-20ca9ff772de", "applicationId": "019f32cc-c9cd-7c50-a956-3cb98e64e5f3", "conversationId": "019f32cc-c9d5-7dac-8742-0ce74f81cc58"}	\N	2026-07-05 15:01:49.657
019f32cc-c9dc-71d3-a010-2d919f279cff	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Алексей Фещенко applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-c9b8-773a-a7f3-20ca9ff772de", "applicationId": "019f32cc-c9cd-7c50-a956-3cb98e64e5f3", "conversationId": "019f32cc-c9d5-7dac-8742-0ce74f81cc58"}	\N	2026-07-05 15:01:49.657
019f32cc-cad6-7b4e-b66a-dd94dc7a178b	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Мария Панченко applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-cabd-7522-a98b-4be3f9e61347", "applicationId": "019f32cc-cac4-7e67-821a-52e13dcf340b", "conversationId": "019f32cc-cad3-7d51-90d0-9f593b69bfe2"}	\N	2026-07-05 15:01:49.909
019f32cc-cad7-744c-ba03-d6a7e61522bd	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Мария Панченко applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-cabd-7522-a98b-4be3f9e61347", "applicationId": "019f32cc-cac4-7e67-821a-52e13dcf340b", "conversationId": "019f32cc-cad3-7d51-90d0-9f593b69bfe2"}	\N	2026-07-05 15:01:49.909
019f32cc-cbd3-702c-94b3-1e528b9c97f2	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Екатерина Чупинина applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-cb99-7fae-b716-ce019cf12390", "applicationId": "019f32cc-cbab-7c65-8c5c-f4d0c15227a9", "conversationId": "019f32cc-cbce-7dbe-9739-7d7e02a4a9fc"}	\N	2026-07-05 15:01:50.16
019f32cc-cbd4-7291-8538-d0b37aa2f912	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Екатерина Чупинина applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-cb99-7fae-b716-ce019cf12390", "applicationId": "019f32cc-cbab-7c65-8c5c-f4d0c15227a9", "conversationId": "019f32cc-cbce-7dbe-9739-7d7e02a4a9fc"}	\N	2026-07-05 15:01:50.16
019f32cc-cc99-741b-894d-7369bf33f806	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Эге Якут applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-cc79-7352-bd17-40ba3fd57aab", "applicationId": "019f32cc-cc89-7ee4-abf7-f1e46231cd08", "conversationId": "019f32cc-cc92-75e6-a5ab-02adb01ecda2"}	\N	2026-07-05 15:01:50.359
019f32cc-cd8a-7f98-a8da-3eb7bc8f3d44	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Елена Эстер applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-cd6c-71ec-b291-f1b68b25ddd9", "applicationId": "019f32cc-cd74-77e2-9224-6f30bf3eb0cd", "conversationId": "019f32cc-cd84-70f2-ba1b-0f457dc50c6a"}	\N	2026-07-05 15:01:50.599
019f32cc-cc98-7cf1-974c-c45536df2712	019e72e8-7296-7d04-86de-6766827d80f8	019e72e8-735d-7c54-b229-08222aa2c6ca	in_app	application.new_inbound	{"body": "Эге Якут applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-cc79-7352-bd17-40ba3fd57aab", "applicationId": "019f32cc-cc89-7ee4-abf7-f1e46231cd08", "conversationId": "019f32cc-cc92-75e6-a5ab-02adb01ecda2"}	\N	2026-07-05 15:01:50.359
019f32cc-cd88-765e-860f-25ffab532616	019e72e8-7296-7d04-86de-6766827d80f8	019f324a-0df9-7a4a-835a-f6f742e2d659	in_app	application.new_inbound	{"body": "Елена Эстер applied for Логист via HH.ru.", "title": "New application", "source": "hh_ru", "vacancyId": "019e8d16-224f-77a8-b24d-4de278134fd3", "candidateId": "019f32cc-cd6c-71ec-b291-f1b68b25ddd9", "applicationId": "019f32cc-cd74-77e2-9224-6f30bf3eb0cd", "conversationId": "019f32cc-cd84-70f2-ba1b-0f457dc50c6a"}	\N	2026-07-05 15:01:50.599
\.


--
-- Data for Name: offboarding_checklists; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.offboarding_checklists (id, tenant_id, employee_id, title, description, due_date, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: offboarding_tasks; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.offboarding_tasks (id, tenant_id, checklist_id, task_order, title, description, assignee_role, status, assignee_user_id, due_date, completed_at, completed_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.offers (id, tenant_id, application_id, interview_id, salary, currency, start_date, grade, conditions, status, docuseal_submission_id, docuseal_document_url, docuseal_signing_url, sent_at, expires_at, accepted_at, declined_at, declined_reason, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: okrs; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.okrs (id, tenant_id, employee_id, parent_okr_id, quarter, objective, description, status, progress_percent, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: onboarding_checklists; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.onboarding_checklists (id, tenant_id, employee_id, title, description, due_date, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: onboarding_tasks; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.onboarding_tasks (id, tenant_id, checklist_id, task_order, title, description, status, assignee_user_id, due_date, completed_at, completed_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: one_on_ones; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.one_on_ones (id, tenant_id, employee_id, manager_user_id, scheduled_at, duration_minutes, status, agenda, notes, action_items, reminder_sent_at, completed_at, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: org_units; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.org_units (id, tenant_id, name, parent_id, created_at, updated_at) FROM stdin;
019e8d14-53b6-7e8d-8b82-0ecc4c788206	019e72e8-7296-7d04-86de-6766827d80f8	Тихоокеанская звезда	\N	2026-06-03 10:43:00.149	2026-06-03 10:43:00.149
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.password_reset_tokens (id, user_id, token_hash, expires_at, used_at, user_agent, ip_address, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.plans (id, name, max_employees, max_users, price_rub_monthly, features, created_at, updated_at) FROM stdin;
019e72e7-a6e1-7e47-afec-5bb7620d19b2	starter	25	5	0	{"description": "Free trial — up to 25 employees"}	2026-05-29 08:44:04.689	2026-05-29 08:44:04.689
019e72e7-a6e4-7d02-ba48-eac5aebbf831	growth	100	20	19900	{"description": "Growth plan — up to 100 employees"}	2026-05-29 08:44:04.689	2026-05-29 08:44:04.689
019e72e7-a6e4-7380-a31f-f1cea33178c7	business	500	100	49900	{"description": "Business plan — up to 500 employees"}	2026-05-29 08:44:04.689	2026-05-29 08:44:04.689
\.


--
-- Data for Name: pre_start_portal_entries; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.pre_start_portal_entries (id, tenant_id, employee_id, status, opened_at, linked_at, closed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: queue_jobs; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.queue_jobs (id, queue_name, payload, status, attempts, max_retries, available_at, started_at, finished_at, last_error, created_at, updated_at) FROM stdin;
7fb19eca-cfa6-4644-85aa-31aeb2238398	hh.negotiations.sync	{"tenantId": "019e72e8-7296-7d04-86de-6766827d80f8", "actorUserId": "019e72e8-735d-7c54-b229-08222aa2c6ca"}	done	0	5	2026-06-05 06:42:48.52	2026-06-05 06:42:48.525	2026-06-05 06:42:48.544	\N	2026-06-05 06:42:48.52	2026-06-05 06:42:48.544
cac0bcac-f773-4fbe-be1f-d4d2f2d01f06	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-09"}	done	0	5	2026-06-09 01:15:00.724	2026-06-09 01:15:00.73	2026-06-09 01:15:00.769	\N	2026-06-09 01:15:00.724	2026-06-09 01:15:00.769
fdcfe144-3ce1-4873-94e1-3875f2b1a46e	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-06"}	done	0	5	2026-06-06 01:00:01.185	2026-06-06 01:00:01.199	2026-06-06 01:00:01.355	\N	2026-06-06 01:00:01.185	2026-06-06 01:00:01.355
a910cb77-a594-4705-8ed9-67559bfc79d8	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-09"}	done	0	5	2026-06-09 01:30:00.836	2026-06-09 01:30:00.843	2026-06-09 01:30:00.892	\N	2026-06-09 01:30:00.836	2026-06-09 01:30:00.892
73300d5a-4911-4779-8f3a-83ac82db72a8	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-06"}	done	0	5	2026-06-06 01:15:01.305	2026-06-06 01:15:01.312	2026-06-06 01:15:01.353	\N	2026-06-06 01:15:01.305	2026-06-06 01:15:01.353
d70c1bdc-a6e6-43f7-ab6b-5b8d47bf327b	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-06"}	done	0	5	2026-06-06 01:30:01.09	2026-06-06 01:30:01.1	2026-06-06 01:30:01.156	\N	2026-06-06 01:30:01.09	2026-06-06 01:30:01.156
faef295f-a158-4e57-bf6b-0a64182c704b	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-09"}	done	0	5	2026-06-09 01:45:00.752	2026-06-09 01:45:00.759	2026-06-09 01:45:00.791	\N	2026-06-09 01:45:00.752	2026-06-09 01:45:00.791
96767ed9-ac1c-41ce-b7e7-1980a8dd2b5f	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-06"}	done	0	5	2026-06-06 01:45:01.18	2026-06-06 01:45:01.188	2026-06-06 01:45:01.231	\N	2026-06-06 01:45:01.18	2026-06-06 01:45:01.231
4fef751d-c0df-4ea3-bbd4-e5cba8df3d51	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-09 02:00:00.751	2026-06-09 02:00:00.76	2026-06-09 02:00:00.77	\N	2026-06-09 02:00:00.751	2026-06-09 02:00:00.77
b3c25f93-d5f0-43bb-9054-8890faef689d	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-06 02:00:01.106	2026-06-06 02:00:01.114	2026-06-06 02:00:01.175	\N	2026-06-06 02:00:01.106	2026-06-06 02:00:01.175
a226a9f1-70b7-4ffe-944a-73f85409a57d	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-06"}	done	0	5	2026-06-06 02:15:01.085	2026-06-06 02:15:01.092	2026-06-06 02:15:01.134	\N	2026-06-06 02:15:01.085	2026-06-06 02:15:01.134
1383759a-3a43-4f66-8196-4f408e05ad58	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-09"}	done	0	5	2026-06-09 02:15:00.911	2026-06-09 02:15:00.924	2026-06-09 02:15:00.959	\N	2026-06-09 02:15:00.911	2026-06-09 02:15:00.959
b9d5f1b0-e543-4017-8745-4bd42a59b241	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-06"}	done	0	5	2026-06-06 02:30:01.101	2026-06-06 02:30:01.108	2026-06-06 02:30:01.143	\N	2026-06-06 02:30:01.101	2026-06-06 02:30:01.143
d498a803-bf8a-4d56-9843-ecb4aaf2d2eb	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-09"}	done	0	5	2026-06-09 02:30:00.742	2026-06-09 02:30:00.75	2026-06-09 02:30:00.788	\N	2026-06-09 02:30:00.742	2026-06-09 02:30:00.788
faf1d77d-e209-41c3-a1a7-2676d90113ac	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-06"}	done	0	5	2026-06-06 03:15:01.089	2026-06-06 03:15:01.105	2026-06-06 03:15:01.139	\N	2026-06-06 03:15:01.089	2026-06-06 03:15:01.139
e0bc955c-b1dc-4da5-ba10-189c0cb7b7de	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-07"}	done	0	5	2026-06-07 01:00:01.075	2026-06-07 01:00:01.093	2026-06-07 01:00:01.188	\N	2026-06-07 01:00:01.075	2026-06-07 01:00:01.188
aa2e30ec-aba9-4dce-b819-b345e666aa1a	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-09"}	done	0	5	2026-06-09 03:15:00.756	2026-06-09 03:15:00.772	2026-06-09 03:15:00.808	\N	2026-06-09 03:15:00.756	2026-06-09 03:15:00.808
e4e70faf-8a62-4431-988c-c346997c5670	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-07"}	done	0	5	2026-06-07 01:15:01.046	2026-06-07 01:15:01.058	2026-06-07 01:15:01.101	\N	2026-06-07 01:15:01.046	2026-06-07 01:15:01.101
e7b41bc6-217f-4ca1-9cca-3d3588eb1edb	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-10"}	done	0	5	2026-06-10 01:00:01.301	2026-06-10 01:00:01.309	2026-06-10 01:00:01.406	\N	2026-06-10 01:00:01.301	2026-06-10 01:00:01.406
7675722f-51e1-497f-b11f-6591041ac64b	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-07"}	done	0	5	2026-06-07 01:30:00.921	2026-06-07 01:30:00.95	2026-06-07 01:30:00.995	\N	2026-06-07 01:30:00.921	2026-06-07 01:30:00.995
0adc4bb5-c2bd-45c0-9386-994c19b82fd9	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-07"}	done	0	5	2026-06-07 01:45:00.924	2026-06-07 01:45:00.93	2026-06-07 01:45:00.976	\N	2026-06-07 01:45:00.924	2026-06-07 01:45:00.976
9c8de3c6-4535-407d-855b-6dc65ba0d266	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-10"}	done	0	5	2026-06-10 01:15:01.069	2026-06-10 01:15:01.082	2026-06-10 01:15:01.123	\N	2026-06-10 01:15:01.069	2026-06-10 01:15:01.123
7b3a65f7-29f4-4ddc-86f3-e08cca4852a9	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-07 02:00:01.021	2026-06-07 02:00:01.029	2026-06-07 02:00:01.04	\N	2026-06-07 02:00:01.021	2026-06-07 02:00:01.04
8376c939-0baf-4fbd-801e-68aeeff2065e	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-10"}	done	0	5	2026-06-10 01:30:01.111	2026-06-10 01:30:01.119	2026-06-10 01:30:01.173	\N	2026-06-10 01:30:01.111	2026-06-10 01:30:01.173
9b370660-dfc2-410f-bc2a-5b18976b4b3a	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-07"}	done	0	5	2026-06-07 02:15:00.933	2026-06-07 02:15:00.939	2026-06-07 02:15:00.98	\N	2026-06-07 02:15:00.933	2026-06-07 02:15:00.98
7331cc62-4847-41f5-927f-a8961a22e6d3	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-07"}	done	0	5	2026-06-07 02:30:00.924	2026-06-07 02:30:00.934	2026-06-07 02:30:00.968	\N	2026-06-07 02:30:00.924	2026-06-07 02:30:00.968
4aa3b51c-b000-45a6-a768-9febc7763e08	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-10"}	done	0	5	2026-06-10 01:45:01.137	2026-06-10 01:45:01.144	2026-06-10 01:45:01.185	\N	2026-06-10 01:45:01.137	2026-06-10 01:45:01.185
cd12a5d5-0112-40db-814b-9f3ee7826a40	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-07"}	done	0	5	2026-06-07 03:15:00.974	2026-06-07 03:15:00.984	2026-06-07 03:15:01.041	\N	2026-06-07 03:15:00.974	2026-06-07 03:15:01.041
4ca5f0b5-2bee-4f1f-a090-7258be16ab57	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-10 02:00:01.32	2026-06-10 02:00:01.33	2026-06-10 02:00:01.343	\N	2026-06-10 02:00:01.32	2026-06-10 02:00:01.343
5885cf57-078a-48ac-802f-61ec52f4912a	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-08"}	done	0	5	2026-06-08 01:00:01.833	2026-06-08 01:00:01.849	2026-06-08 01:00:02.045	\N	2026-06-08 01:00:01.833	2026-06-08 01:00:02.045
b0c729cc-9404-41f8-a202-b1f14a33d811	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-08"}	done	0	5	2026-06-08 01:15:01.475	2026-06-08 01:15:01.485	2026-06-08 01:15:01.533	\N	2026-06-08 01:15:01.475	2026-06-08 01:15:01.533
a4f3e1fd-1514-4dae-9191-bb34c768d39c	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-10"}	done	0	5	2026-06-10 02:15:01.116	2026-06-10 02:15:01.122	2026-06-10 02:15:01.175	\N	2026-06-10 02:15:01.116	2026-06-10 02:15:01.175
e0e6bdcb-ada8-4de7-b82b-ad877242a87c	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-08"}	done	0	5	2026-06-08 01:30:01.63	2026-06-08 01:30:01.64	2026-06-08 01:30:01.707	\N	2026-06-08 01:30:01.63	2026-06-08 01:30:01.707
9142b245-12fc-4eff-9e67-05213c4488b8	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-10"}	done	0	5	2026-06-10 02:30:01.137	2026-06-10 02:30:01.147	2026-06-10 02:30:01.185	\N	2026-06-10 02:30:01.137	2026-06-10 02:30:01.185
7f20f405-fa10-49ad-a7e7-c21187b89d1a	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-08"}	done	0	5	2026-06-08 01:45:01.505	2026-06-08 01:45:01.515	2026-06-08 01:45:01.572	\N	2026-06-08 01:45:01.505	2026-06-08 01:45:01.572
12fa05a7-5a8c-41f9-a508-0b8597d8586a	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-08 02:00:01.634	2026-06-08 02:00:01.646	2026-06-08 02:00:01.663	\N	2026-06-08 02:00:01.634	2026-06-08 02:00:01.663
8b775918-069d-4cb0-91ee-8c015590ad4d	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-08"}	done	0	5	2026-06-08 02:15:01.491	2026-06-08 02:15:01.499	2026-06-08 02:15:01.562	\N	2026-06-08 02:15:01.491	2026-06-08 02:15:01.562
44a25fac-6696-4a44-aeb1-068b8e6551db	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-08"}	done	0	5	2026-06-08 02:30:01.498	2026-06-08 02:30:01.506	2026-06-08 02:30:01.542	\N	2026-06-08 02:30:01.498	2026-06-08 02:30:01.542
2ac85092-51eb-46ff-a4a6-a75fe2ce5bac	cron.run	{"taskName": "selection.retention_calibration", "scheduledWindow": "2026-06-08"}	done	0	5	2026-06-08 02:45:01.547	2026-06-08 02:45:01.558	2026-06-08 02:45:01.665	\N	2026-06-08 02:45:01.547	2026-06-08 02:45:01.665
ef3fcb6a-9f9b-4d26-a0a9-acad7aef4373	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-08"}	done	0	5	2026-06-08 03:15:01.526	2026-06-08 03:15:01.541	2026-06-08 03:15:01.598	\N	2026-06-08 03:15:01.526	2026-06-08 03:15:01.598
0450ef0c-bc61-4436-b575-c2984505f341	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-09"}	done	0	5	2026-06-09 01:00:00.8	2026-06-09 01:00:00.808	2026-06-09 01:00:00.89	\N	2026-06-09 01:00:00.8	2026-06-09 01:00:00.89
a4e31cdb-6b63-4897-96a5-d2084770e4cd	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-10"}	done	0	5	2026-06-10 03:15:01.144	2026-06-10 03:15:01.179	2026-06-10 03:15:01.231	\N	2026-06-10 03:15:01.144	2026-06-10 03:15:01.231
b12f0620-e280-4aee-b267-f87ad85453e1	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-13"}	done	0	5	2026-06-13 01:00:01.081	2026-06-13 01:00:01.092	2026-06-13 01:00:01.192	\N	2026-06-13 01:00:01.081	2026-06-13 01:00:01.192
9bf6b770-c383-4d78-8513-65285418a998	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-11"}	done	0	5	2026-06-11 01:00:01.401	2026-06-11 01:00:01.41	2026-06-11 01:00:01.526	\N	2026-06-11 01:00:01.401	2026-06-11 01:00:01.526
a6426127-4f92-42c8-985c-c265afd541cb	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-13"}	done	0	5	2026-06-13 01:15:01.008	2026-06-13 01:15:01.015	2026-06-13 01:15:01.056	\N	2026-06-13 01:15:01.008	2026-06-13 01:15:01.056
a92b84ac-0267-416c-b744-5bf28a826cb2	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-11"}	done	0	5	2026-06-11 01:15:01.361	2026-06-11 01:15:01.367	2026-06-11 01:15:01.413	\N	2026-06-11 01:15:01.361	2026-06-11 01:15:01.413
4a8ef472-5da9-47e1-b692-9e5ddcb68079	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-11"}	done	0	5	2026-06-11 01:30:01.501	2026-06-11 01:30:01.512	2026-06-11 01:30:01.579	\N	2026-06-11 01:30:01.501	2026-06-11 01:30:01.579
466a0364-bcf7-495e-9c4a-be9f50f26b4e	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-13"}	done	0	5	2026-06-13 01:30:01.109	2026-06-13 01:30:01.117	2026-06-13 01:30:01.172	\N	2026-06-13 01:30:01.109	2026-06-13 01:30:01.172
1b0008dd-ffe7-4a37-bc5d-e24b59ddeb62	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-11"}	done	0	5	2026-06-11 01:45:01.353	2026-06-11 01:45:01.377	2026-06-11 01:45:01.424	\N	2026-06-11 01:45:01.353	2026-06-11 01:45:01.424
9c0abe6e-7b12-41b8-b408-f61582d0a2ca	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-13"}	done	0	5	2026-06-13 01:45:00.996	2026-06-13 01:45:01.026	2026-06-13 01:45:01.071	\N	2026-06-13 01:45:00.996	2026-06-13 01:45:01.071
8fa98171-05bf-4ea3-b235-6c489c699a62	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-11 02:00:01.427	2026-06-11 02:00:01.435	2026-06-11 02:00:01.446	\N	2026-06-11 02:00:01.427	2026-06-11 02:00:01.446
aa4e47ec-f33b-4b9c-a094-ad2320bd0b28	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-11"}	done	0	5	2026-06-11 02:15:01.418	2026-06-11 02:15:01.429	2026-06-11 02:15:01.477	\N	2026-06-11 02:15:01.418	2026-06-11 02:15:01.477
ba81f67d-4eb4-470d-9402-1b5d21033fb8	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-13 02:00:01.053	2026-06-13 02:00:01.063	2026-06-13 02:00:01.073	\N	2026-06-13 02:00:01.053	2026-06-13 02:00:01.073
fc75acf3-6b26-4b65-9d2e-c52397cc82fe	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-11"}	done	0	5	2026-06-11 02:30:01.397	2026-06-11 02:30:01.404	2026-06-11 02:30:01.438	\N	2026-06-11 02:30:01.397	2026-06-11 02:30:01.438
d86df3c9-8412-4e6e-865f-6c9eb7342525	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-13"}	done	0	5	2026-06-13 02:15:01.095	2026-06-13 02:15:01.122	2026-06-13 02:15:01.161	\N	2026-06-13 02:15:01.095	2026-06-13 02:15:01.161
dfc52277-8f82-4167-9777-7d6c4a629bb0	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-11"}	done	0	5	2026-06-11 03:15:01.461	2026-06-11 03:15:01.468	2026-06-11 03:15:01.505	\N	2026-06-11 03:15:01.461	2026-06-11 03:15:01.505
917c3860-ffee-457d-b2d1-acdc39c70e3f	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-12"}	done	0	5	2026-06-12 01:00:00.885	2026-06-12 01:00:00.895	2026-06-12 01:00:00.995	\N	2026-06-12 01:00:00.885	2026-06-12 01:00:00.995
8609efbe-f6f2-4162-b929-327377d6d7c7	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-13"}	done	0	5	2026-06-13 02:30:01.104	2026-06-13 02:30:01.112	2026-06-13 02:30:01.154	\N	2026-06-13 02:30:01.104	2026-06-13 02:30:01.154
03d00779-76c1-49a1-bd3d-2c25abb2e74b	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-12"}	done	0	5	2026-06-12 01:15:00.748	2026-06-12 01:15:00.754	2026-06-12 01:15:00.794	\N	2026-06-12 01:15:00.748	2026-06-12 01:15:00.794
f00878f6-fade-4ba7-b3ca-cb518c9d605d	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-13"}	done	0	5	2026-06-13 03:15:01.056	2026-06-13 03:15:01.064	2026-06-13 03:15:01.101	\N	2026-06-13 03:15:01.056	2026-06-13 03:15:01.101
f3794776-976b-4b51-af1f-e3b866c50492	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-12"}	done	0	5	2026-06-12 01:30:00.761	2026-06-12 01:30:00.768	2026-06-12 01:30:00.818	\N	2026-06-12 01:30:00.761	2026-06-12 01:30:00.818
6aaef790-a1d7-417a-b892-7e584dab78be	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-12"}	done	0	5	2026-06-12 01:45:00.699	2026-06-12 01:45:00.704	2026-06-12 01:45:00.737	\N	2026-06-12 01:45:00.699	2026-06-12 01:45:00.737
7a231fa7-078e-4f36-b960-c679bc24ae17	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-14"}	done	0	5	2026-06-14 01:00:01.374	2026-06-14 01:00:01.386	2026-06-14 01:00:01.485	\N	2026-06-14 01:00:01.374	2026-06-14 01:00:01.485
e2e7e892-a7be-419a-a9f7-8321add2d3fe	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-12 02:00:00.859	2026-06-12 02:00:00.864	2026-06-12 02:00:00.874	\N	2026-06-12 02:00:00.859	2026-06-12 02:00:00.874
b883b7b6-24e4-4c39-8257-cb16288283b4	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-14"}	done	0	5	2026-06-14 01:15:01.401	2026-06-14 01:15:01.409	2026-06-14 01:15:01.458	\N	2026-06-14 01:15:01.401	2026-06-14 01:15:01.458
9ac8e50f-cd19-437e-a23b-2e3c558f7c70	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-12"}	done	0	5	2026-06-12 02:15:00.87	2026-06-12 02:15:00.882	2026-06-12 02:15:00.924	\N	2026-06-12 02:15:00.87	2026-06-12 02:15:00.924
31c90176-2121-40e6-b4a0-0040e22bcc7f	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-12"}	done	0	5	2026-06-12 02:30:00.768	2026-06-12 02:30:00.774	2026-06-12 02:30:00.81	\N	2026-06-12 02:30:00.768	2026-06-12 02:30:00.81
0c0c846f-47fe-4048-9046-6bcd01d92098	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-14"}	done	0	5	2026-06-14 01:30:01.344	2026-06-14 01:30:01.353	2026-06-14 01:30:01.411	\N	2026-06-14 01:30:01.344	2026-06-14 01:30:01.411
37171e00-0dcb-4a3b-bfea-4b27a3be74d1	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-12"}	done	0	5	2026-06-12 03:15:00.72	2026-06-12 03:15:00.744	2026-06-12 03:15:00.774	\N	2026-06-12 03:15:00.72	2026-06-12 03:15:00.774
35922326-4d84-4836-834b-6517f73683cf	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-14"}	done	0	5	2026-06-14 01:45:01.646	2026-06-14 01:45:01.656	2026-06-14 01:45:01.704	\N	2026-06-14 01:45:01.646	2026-06-14 01:45:01.704
fdd370bc-311e-484d-b047-3c15793cbdde	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-14 02:00:01.64	2026-06-14 02:00:01.653	2026-06-14 02:00:01.666	\N	2026-06-14 02:00:01.64	2026-06-14 02:00:01.666
595d5434-f96d-4f2a-aa39-f543cc0f5152	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-14"}	done	0	5	2026-06-14 02:15:01.423	2026-06-14 02:15:01.43	2026-06-14 02:15:01.477	\N	2026-06-14 02:15:01.423	2026-06-14 02:15:01.477
3e965888-7d6d-4dd8-933f-8797f1e94cc3	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-14"}	done	0	5	2026-06-14 02:30:01.327	2026-06-14 02:30:01.348	2026-06-14 02:30:01.388	\N	2026-06-14 02:30:01.327	2026-06-14 02:30:01.388
36c68f8e-0e55-494b-8f6c-f5b68ae5d253	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-14"}	done	0	5	2026-06-14 03:15:01.398	2026-06-14 03:15:01.407	2026-06-14 03:15:01.449	\N	2026-06-14 03:15:01.398	2026-06-14 03:15:01.449
cf595f5c-348e-474e-b000-9f66207abbcf	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-15"}	done	0	5	2026-06-15 01:00:00.726	2026-06-15 01:00:00.752	2026-06-15 01:00:00.845	\N	2026-06-15 01:00:00.726	2026-06-15 01:00:00.845
a1269d7a-ce2b-4340-88c8-18914ebaac50	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-15"}	done	0	5	2026-06-15 01:15:00.646	2026-06-15 01:15:00.658	2026-06-15 01:15:00.698	\N	2026-06-15 01:15:00.646	2026-06-15 01:15:00.698
bc57662b-995d-42b0-b0b9-1bcd38672cf2	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-15"}	done	0	5	2026-06-15 01:30:00.742	2026-06-15 01:30:00.75	2026-06-15 01:30:00.803	\N	2026-06-15 01:30:00.742	2026-06-15 01:30:00.803
0b1a242e-e229-4df6-a093-6cbb9f98b025	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-15"}	done	0	5	2026-06-15 01:45:00.667	2026-06-15 01:45:00.674	2026-06-15 01:45:00.717	\N	2026-06-15 01:45:00.667	2026-06-15 01:45:00.717
a9ea931d-5d1f-4e33-9ac2-859c02a55945	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-15 02:00:00.717	2026-06-15 02:00:00.725	2026-06-15 02:00:00.741	\N	2026-06-15 02:00:00.717	2026-06-15 02:00:00.741
13c0a1c3-5c99-4c75-84a4-f2d973a65eae	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-15"}	done	0	5	2026-06-15 02:15:00.753	2026-06-15 02:15:00.76	2026-06-15 02:15:00.794	\N	2026-06-15 02:15:00.753	2026-06-15 02:15:00.794
bdb3cd62-8fb8-4d74-b5fb-f2acea91956a	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-15"}	done	0	5	2026-06-15 02:30:00.683	2026-06-15 02:30:00.688	2026-06-15 02:30:00.728	\N	2026-06-15 02:30:00.683	2026-06-15 02:30:00.728
7f6e1e19-1ba5-40e9-a45b-9a14be661c23	cron.run	{"taskName": "selection.retention_calibration", "scheduledWindow": "2026-06-15"}	done	0	5	2026-06-15 02:45:00.714	2026-06-15 02:45:00.722	2026-06-15 02:45:00.789	\N	2026-06-15 02:45:00.714	2026-06-15 02:45:00.789
e6628b8b-d536-4370-a1bd-d5ccb1fb6f32	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-17"}	done	0	5	2026-06-17 01:00:01.442	2026-06-17 01:00:01.453	2026-06-17 01:00:01.579	\N	2026-06-17 01:00:01.442	2026-06-17 01:00:01.579
157bdd37-15e2-4865-912b-a74a3f0e3ea8	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-15"}	done	0	5	2026-06-15 03:15:00.712	2026-06-15 03:15:00.718	2026-06-15 03:15:00.754	\N	2026-06-15 03:15:00.712	2026-06-15 03:15:00.754
a7b74ffc-0c80-40d5-833b-e4bba0e1eec3	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-21"}	done	0	5	2026-06-21 02:15:00.62	2026-06-21 02:15:00.628	2026-06-21 02:15:00.676	\N	2026-06-21 02:15:00.62	2026-06-21 02:15:00.676
86010297-b9c8-41fe-8d33-fcb6b0792a75	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-16"}	done	0	5	2026-06-16 01:00:01.177	2026-06-16 01:00:01.188	2026-06-16 01:00:01.297	\N	2026-06-16 01:00:01.177	2026-06-16 01:00:01.297
0fc9e241-6a80-457b-a5fa-1750618785c6	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-17"}	done	0	5	2026-06-17 01:15:01.292	2026-06-17 01:15:01.309	2026-06-17 01:15:01.362	\N	2026-06-17 01:15:01.292	2026-06-17 01:15:01.362
8281db94-033e-4a9c-b687-923b36bc2d2b	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-16"}	done	0	5	2026-06-16 01:15:01.028	2026-06-16 01:15:01.037	2026-06-16 01:15:01.082	\N	2026-06-16 01:15:01.028	2026-06-16 01:15:01.082
f460b944-40da-4de4-8c0e-0e8d7a792204	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-17"}	done	0	5	2026-06-17 01:30:01.375	2026-06-17 01:30:01.381	2026-06-17 01:30:01.445	\N	2026-06-17 01:30:01.375	2026-06-17 01:30:01.445
184c9e89-f15a-4f96-9947-ad3fabc8c910	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-16"}	done	0	5	2026-06-16 01:30:01.002	2026-06-16 01:30:01.014	2026-06-16 01:30:01.093	\N	2026-06-16 01:30:01.002	2026-06-16 01:30:01.093
8186ef3e-e3a0-4a79-8526-5d84fa7145e8	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-16"}	done	0	5	2026-06-16 01:45:01.108	2026-06-16 01:45:01.119	2026-06-16 01:45:01.199	\N	2026-06-16 01:45:01.108	2026-06-16 01:45:01.199
ddca5684-11e3-4940-b84c-461308587bb4	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-17"}	done	0	5	2026-06-17 01:45:01.299	2026-06-17 01:45:01.305	2026-06-17 01:45:01.353	\N	2026-06-17 01:45:01.299	2026-06-17 01:45:01.353
09069338-4588-4992-8d62-e141e4af592c	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-16 02:00:01.254	2026-06-16 02:00:01.273	2026-06-16 02:00:01.307	\N	2026-06-16 02:00:01.254	2026-06-16 02:00:01.307
6690cc9e-019a-4876-8749-2567dd5fa49c	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-17 02:00:01.28	2026-06-17 02:00:01.292	2026-06-17 02:00:01.316	\N	2026-06-17 02:00:01.28	2026-06-17 02:00:01.316
5a5fd7a7-0602-4212-9384-281a174dd981	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-16"}	done	0	5	2026-06-16 02:15:01.231	2026-06-16 02:15:01.25	2026-06-16 02:15:01.35	\N	2026-06-16 02:15:01.231	2026-06-16 02:15:01.35
2d1682b3-91ea-40eb-a7fd-bec0c9fe8b4f	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-16"}	done	0	5	2026-06-16 02:30:01.134	2026-06-16 02:30:01.147	2026-06-16 02:30:01.195	\N	2026-06-16 02:30:01.134	2026-06-16 02:30:01.195
bda6daba-4982-4fb1-9a20-45ac489e9df4	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-17"}	done	0	5	2026-06-17 02:15:01.351	2026-06-17 02:15:01.359	2026-06-17 02:15:01.409	\N	2026-06-17 02:15:01.351	2026-06-17 02:15:01.409
abf2a3cd-ade4-403c-a5c4-a21a3abca616	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-16"}	done	0	5	2026-06-16 03:15:01.049	2026-06-16 03:15:01.058	2026-06-16 03:15:01.094	\N	2026-06-16 03:15:01.049	2026-06-16 03:15:01.094
3d7fea7b-8a40-4584-9a90-0d74acb2e432	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-17"}	done	0	5	2026-06-17 02:30:01.372	2026-06-17 02:30:01.383	2026-06-17 02:30:01.419	\N	2026-06-17 02:30:01.372	2026-06-17 02:30:01.419
ec111f12-f0fe-47c4-b53c-d2fe9ca5b916	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-17"}	done	0	5	2026-06-17 03:15:01.341	2026-06-17 03:15:01.349	2026-06-17 03:15:01.39	\N	2026-06-17 03:15:01.341	2026-06-17 03:15:01.39
bae02909-bbc0-43a8-8ac9-8e3eb877d34a	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-18"}	done	0	5	2026-06-18 01:00:00.659	2026-06-18 01:00:00.676	2026-06-18 01:00:00.764	\N	2026-06-18 01:00:00.659	2026-06-18 01:00:00.764
5ff25e7e-7a25-42ed-bfa3-317c19abe157	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-18"}	done	0	5	2026-06-18 01:15:00.645	2026-06-18 01:15:00.652	2026-06-18 01:15:00.695	\N	2026-06-18 01:15:00.645	2026-06-18 01:15:00.695
a90edc0e-5ea0-4a57-a2c4-bb4c3a953338	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-18"}	done	0	5	2026-06-18 01:30:00.619	2026-06-18 01:30:00.647	2026-06-18 01:30:00.695	\N	2026-06-18 01:30:00.619	2026-06-18 01:30:00.695
d11f69b7-4792-4a02-9b73-43632f1abd6d	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-18"}	done	0	5	2026-06-18 01:45:00.626	2026-06-18 01:45:00.632	2026-06-18 01:45:00.677	\N	2026-06-18 01:45:00.626	2026-06-18 01:45:00.677
5add3f83-899e-4f89-95bc-af0cf9a567d6	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-18 02:00:00.584	2026-06-18 02:00:00.591	2026-06-18 02:00:00.6	\N	2026-06-18 02:00:00.584	2026-06-18 02:00:00.6
af82dca1-4b39-4a0f-a3fa-49b5edd75caf	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-18"}	done	0	5	2026-06-18 02:15:00.608	2026-06-18 02:15:00.615	2026-06-18 02:15:00.65	\N	2026-06-18 02:15:00.608	2026-06-18 02:15:00.65
1cc46211-11cc-4b7d-9c07-abc407193ff5	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-18"}	done	0	5	2026-06-18 02:30:00.674	2026-06-18 02:30:00.683	2026-06-18 02:30:00.721	\N	2026-06-18 02:30:00.674	2026-06-18 02:30:00.721
59254c3b-fc2c-4964-8dc9-81b2c535b55a	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-18"}	done	0	5	2026-06-18 03:15:00.727	2026-06-18 03:15:00.735	2026-06-18 03:15:00.764	\N	2026-06-18 03:15:00.727	2026-06-18 03:15:00.764
41df739e-4568-4255-9fc1-bfef8ce72d1a	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-19"}	done	0	5	2026-06-19 01:00:00.981	2026-06-19 01:00:00.996	2026-06-19 01:00:01.094	\N	2026-06-19 01:00:00.981	2026-06-19 01:00:01.094
4c990172-d049-4619-beb0-300f96840478	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-19"}	done	0	5	2026-06-19 01:15:00.874	2026-06-19 01:15:00.88	2026-06-19 01:15:00.918	\N	2026-06-19 01:15:00.874	2026-06-19 01:15:00.918
04cc47c1-ca46-435e-811b-8c2a7aaa777b	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-19"}	done	0	5	2026-06-19 01:30:00.901	2026-06-19 01:30:00.907	2026-06-19 01:30:00.95	\N	2026-06-19 01:30:00.901	2026-06-19 01:30:00.95
a8a0bfb3-0719-453b-a1e8-26bcaa3b0a2b	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-19"}	done	0	5	2026-06-19 01:45:00.914	2026-06-19 01:45:00.944	2026-06-19 01:45:00.979	\N	2026-06-19 01:45:00.914	2026-06-19 01:45:00.979
6cdd4760-aa16-4274-9624-3f7439bdd4d5	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-19 02:00:00.991	2026-06-19 02:00:00.999	2026-06-19 02:00:01.009	\N	2026-06-19 02:00:00.991	2026-06-19 02:00:01.009
099bbae0-66e0-4450-8832-34cf0d25fee4	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-19"}	done	0	5	2026-06-19 02:15:00.929	2026-06-19 02:15:00.935	2026-06-19 02:15:00.974	\N	2026-06-19 02:15:00.929	2026-06-19 02:15:00.974
7f1d3858-16cb-42e3-a055-bdbfb8bb4c66	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-19"}	done	0	5	2026-06-19 02:30:00.936	2026-06-19 02:30:00.944	2026-06-19 02:30:00.976	\N	2026-06-19 02:30:00.936	2026-06-19 02:30:00.976
64441701-3b8c-4b26-8ea5-a68005183d84	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-19"}	done	0	5	2026-06-19 03:15:00.914	2026-06-19 03:15:00.919	2026-06-19 03:15:00.945	\N	2026-06-19 03:15:00.914	2026-06-19 03:15:00.945
2d107b51-9a8f-4c9e-8db9-628269e793c6	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-20"}	done	0	5	2026-06-20 01:00:01.29	2026-06-20 01:00:01.297	2026-06-20 01:00:01.418	\N	2026-06-20 01:00:01.29	2026-06-20 01:00:01.418
2fb537b2-87e9-4d42-97d4-142528e52654	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-20"}	done	0	5	2026-06-20 01:15:01.308	2026-06-20 01:15:01.335	2026-06-20 01:15:01.379	\N	2026-06-20 01:15:01.308	2026-06-20 01:15:01.379
324cdf55-23e1-439d-b0e0-1a36693c96b6	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-20"}	done	0	5	2026-06-20 01:30:01.435	2026-06-20 01:30:01.45	2026-06-20 01:30:01.53	\N	2026-06-20 01:30:01.435	2026-06-20 01:30:01.53
6f76eb92-0cf9-4568-a7fb-5b32e97422a1	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-20"}	done	0	5	2026-06-20 01:45:01.426	2026-06-20 01:45:01.436	2026-06-20 01:45:01.476	\N	2026-06-20 01:45:01.426	2026-06-20 01:45:01.476
49d83655-840a-4250-a180-448a8eb4179b	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-20 02:00:01.241	2026-06-20 02:00:01.25	2026-06-20 02:00:01.26	\N	2026-06-20 02:00:01.241	2026-06-20 02:00:01.26
f001bd7e-59c5-494a-991d-534ecb05d83c	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-20"}	done	0	5	2026-06-20 02:15:01.262	2026-06-20 02:15:01.267	2026-06-20 02:15:01.307	\N	2026-06-20 02:15:01.262	2026-06-20 02:15:01.307
7543b6e7-33e0-4703-a36a-be89ab2a7712	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-20"}	done	0	5	2026-06-20 02:30:01.262	2026-06-20 02:30:01.27	2026-06-20 02:30:01.315	\N	2026-06-20 02:30:01.262	2026-06-20 02:30:01.315
a4ddda38-00dd-4c47-b960-5815fe0b54cd	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-20"}	done	0	5	2026-06-20 03:15:01.397	2026-06-20 03:15:01.428	2026-06-20 03:15:01.463	\N	2026-06-20 03:15:01.397	2026-06-20 03:15:01.463
ab283fc5-01ad-49f3-b42c-43a23da0e01a	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-26"}	done	0	5	2026-06-26 02:15:01.16	2026-06-26 02:15:01.169	2026-06-26 02:15:01.223	\N	2026-06-26 02:15:01.16	2026-06-26 02:15:01.223
e6431372-8548-426e-a62e-3da41fe3d164	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-21"}	done	0	5	2026-06-21 01:00:01.648	2026-06-21 01:00:01.658	2026-06-21 01:00:01.759	\N	2026-06-21 01:00:01.648	2026-06-21 01:00:01.759
b9e15ddb-95ed-485d-8f80-071461912753	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-21"}	done	0	5	2026-06-21 02:30:00.54	2026-06-21 02:30:00.568	2026-06-21 02:30:00.597	\N	2026-06-21 02:30:00.54	2026-06-21 02:30:00.597
46e44dac-7ddd-45d1-a8a5-fca712ddf1de	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-21"}	done	0	5	2026-06-21 01:15:00.532	2026-06-21 01:15:00.555	2026-06-21 01:15:00.588	\N	2026-06-21 01:15:00.532	2026-06-21 01:15:00.588
79de1943-c982-4a65-a443-7d6be2e7ebcf	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-21"}	done	0	5	2026-06-21 01:30:00.578	2026-06-21 01:30:00.584	2026-06-21 01:30:00.632	\N	2026-06-21 01:30:00.578	2026-06-21 01:30:00.632
5103b828-08d8-4c7e-9d1f-c1c50b1361cc	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-21"}	done	0	5	2026-06-21 03:15:00.604	2026-06-21 03:15:00.645	2026-06-21 03:15:00.676	\N	2026-06-21 03:15:00.604	2026-06-21 03:15:00.676
3e159bc4-0c5e-4e00-b70a-c906d4fa3464	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-21"}	done	0	5	2026-06-21 01:45:00.552	2026-06-21 01:45:00.559	2026-06-21 01:45:00.592	\N	2026-06-21 01:45:00.552	2026-06-21 01:45:00.592
a043d883-1e01-40b8-83ae-a804421dfc2c	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-22"}	done	0	5	2026-06-22 01:00:00.824	2026-06-22 01:00:00.838	2026-06-22 01:00:00.941	\N	2026-06-22 01:00:00.824	2026-06-22 01:00:00.941
14e004e1-4405-470d-9ed2-a7d20d4e5c9a	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-21 02:00:00.658	2026-06-21 02:00:00.667	2026-06-21 02:00:00.677	\N	2026-06-21 02:00:00.658	2026-06-21 02:00:00.677
6869e353-ad41-4697-888b-9af329a359d6	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-22"}	done	0	5	2026-06-22 01:15:00.838	2026-06-22 01:15:00.852	2026-06-22 01:15:00.886	\N	2026-06-22 01:15:00.838	2026-06-22 01:15:00.886
88d67481-f218-4d33-b942-94307b9b206f	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-22"}	done	0	5	2026-06-22 01:30:00.876	2026-06-22 01:30:00.885	2026-06-22 01:30:00.941	\N	2026-06-22 01:30:00.876	2026-06-22 01:30:00.941
ab8ccbdf-febd-44f1-a143-641b95580ad0	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-22"}	done	0	5	2026-06-22 01:45:00.867	2026-06-22 01:45:00.872	2026-06-22 01:45:00.906	\N	2026-06-22 01:45:00.867	2026-06-22 01:45:00.906
dc350e3d-515c-406d-b948-325523357cf7	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-22 02:00:00.898	2026-06-22 02:00:00.929	2026-06-22 02:00:00.94	\N	2026-06-22 02:00:00.898	2026-06-22 02:00:00.94
8fb0ac37-87d0-47dc-bfff-2262e8f6fe01	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-22"}	done	0	5	2026-06-22 02:15:00.88	2026-06-22 02:15:00.886	2026-06-22 02:15:00.929	\N	2026-06-22 02:15:00.88	2026-06-22 02:15:00.929
78dc70ef-cb16-4850-a969-d1f2394ab013	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-22"}	done	0	5	2026-06-22 02:30:00.89	2026-06-22 02:30:00.896	2026-06-22 02:30:00.935	\N	2026-06-22 02:30:00.89	2026-06-22 02:30:00.935
7217a856-81a9-4dce-aa78-0d71642fbc12	cron.run	{"taskName": "selection.retention_calibration", "scheduledWindow": "2026-06-22"}	done	0	5	2026-06-22 02:45:00.913	2026-06-22 02:45:00.923	2026-06-22 02:45:01.002	\N	2026-06-22 02:45:00.913	2026-06-22 02:45:01.002
ea9c7e74-627b-4547-b1b5-897597b7226e	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-22"}	done	0	5	2026-06-22 03:15:00.866	2026-06-22 03:15:00.872	2026-06-22 03:15:00.898	\N	2026-06-22 03:15:00.866	2026-06-22 03:15:00.898
5b8992fc-08a6-4be6-bc96-3736439a5288	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-23"}	done	0	5	2026-06-23 01:00:01.262	2026-06-23 01:00:01.272	2026-06-23 01:00:01.369	\N	2026-06-23 01:00:01.262	2026-06-23 01:00:01.369
e2f8c3ef-c287-42c5-9691-b05a4b8f0c31	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-23"}	done	0	5	2026-06-23 01:15:01.176	2026-06-23 01:15:01.183	2026-06-23 01:15:01.222	\N	2026-06-23 01:15:01.176	2026-06-23 01:15:01.222
ab6c2b9a-d9b1-49e8-9b41-d016183c741d	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-23"}	done	0	5	2026-06-23 01:30:01.289	2026-06-23 01:30:01.296	2026-06-23 01:30:01.356	\N	2026-06-23 01:30:01.289	2026-06-23 01:30:01.356
2259b9eb-3512-4b8a-90f6-91a6d3a4b5e7	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-23"}	done	0	5	2026-06-23 01:45:01.184	2026-06-23 01:45:01.189	2026-06-23 01:45:01.23	\N	2026-06-23 01:45:01.184	2026-06-23 01:45:01.23
b5b94a7c-2d89-4c1d-8a72-11455186b920	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-23 02:00:01.248	2026-06-23 02:00:01.257	2026-06-23 02:00:01.271	\N	2026-06-23 02:00:01.248	2026-06-23 02:00:01.271
bfa44c1f-51f7-4f45-962f-c45374b1b812	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-23"}	done	0	5	2026-06-23 02:15:01.329	2026-06-23 02:15:01.337	2026-06-23 02:15:01.386	\N	2026-06-23 02:15:01.329	2026-06-23 02:15:01.386
42ae37a7-8443-49eb-959e-16d40a2afbf9	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-23"}	done	0	5	2026-06-23 02:30:01.186	2026-06-23 02:30:01.192	2026-06-23 02:30:01.225	\N	2026-06-23 02:30:01.186	2026-06-23 02:30:01.225
875b5095-9c1a-4f99-a3ad-1e40ad0a3176	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-23"}	done	0	5	2026-06-23 03:15:01.172	2026-06-23 03:15:01.183	2026-06-23 03:15:01.232	\N	2026-06-23 03:15:01.172	2026-06-23 03:15:01.232
6de566b2-e44f-4634-aaa2-4679e96b0089	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-24"}	done	0	5	2026-06-24 01:00:01.524	2026-06-24 01:00:01.533	2026-06-24 01:00:01.631	\N	2026-06-24 01:00:01.524	2026-06-24 01:00:01.631
f4ba9f3b-d991-4322-9a7a-350a28b360c4	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-24"}	done	0	5	2026-06-24 01:15:01.545	2026-06-24 01:15:01.555	2026-06-24 01:15:01.608	\N	2026-06-24 01:15:01.545	2026-06-24 01:15:01.608
a2a5135a-1da2-4ead-b935-eb04cb541d9f	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-24"}	done	0	5	2026-06-24 01:30:01.555	2026-06-24 01:30:01.567	2026-06-24 01:30:01.624	\N	2026-06-24 01:30:01.555	2026-06-24 01:30:01.624
3b3d0260-2e3d-4a0e-a2c2-2d3f63380616	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-24"}	done	0	5	2026-06-24 01:45:01.587	2026-06-24 01:45:01.596	2026-06-24 01:45:01.635	\N	2026-06-24 01:45:01.587	2026-06-24 01:45:01.635
71ee0ef7-03c4-4621-b3b2-b3f38c49a1b3	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-24 02:00:01.642	2026-06-24 02:00:01.652	2026-06-24 02:00:01.663	\N	2026-06-24 02:00:01.642	2026-06-24 02:00:01.663
e4539ba2-adfa-4182-8178-ac55c459a8fd	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-24"}	done	0	5	2026-06-24 02:15:01.532	2026-06-24 02:15:01.541	2026-06-24 02:15:01.588	\N	2026-06-24 02:15:01.532	2026-06-24 02:15:01.588
3fc8fa59-edd8-49fd-8bc5-9f9ea4eee481	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-24"}	done	0	5	2026-06-24 02:30:01.631	2026-06-24 02:30:01.641	2026-06-24 02:30:01.692	\N	2026-06-24 02:30:01.631	2026-06-24 02:30:01.692
06e6433d-a95d-458e-b970-ae0d1beb7cd0	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-24"}	done	0	5	2026-06-24 03:15:01.586	2026-06-24 03:15:01.603	2026-06-24 03:15:01.647	\N	2026-06-24 03:15:01.586	2026-06-24 03:15:01.647
8cbfb15e-e5b8-4ba9-8008-d18cb21040f3	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-25"}	done	0	5	2026-06-25 01:00:00.829	2026-06-25 01:00:00.838	2026-06-25 01:00:00.915	\N	2026-06-25 01:00:00.829	2026-06-25 01:00:00.915
e4660d1b-d605-44e4-9719-5fcd9003f48f	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-25"}	done	0	5	2026-06-25 01:15:00.754	2026-06-25 01:15:00.763	2026-06-25 01:15:00.816	\N	2026-06-25 01:15:00.754	2026-06-25 01:15:00.816
3766a5cf-02bb-499f-88de-f7c11d7fb96d	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-25"}	done	0	5	2026-06-25 01:30:00.816	2026-06-25 01:30:00.823	2026-06-25 01:30:00.867	\N	2026-06-25 01:30:00.816	2026-06-25 01:30:00.867
31592efe-60c8-4016-83e7-239a36d8fcbc	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-25"}	done	0	5	2026-06-25 01:45:00.869	2026-06-25 01:45:00.874	2026-06-25 01:45:00.904	\N	2026-06-25 01:45:00.869	2026-06-25 01:45:00.904
cf4b4302-5c91-465c-965a-44615a147c10	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-25 02:00:00.807	2026-06-25 02:00:00.819	2026-06-25 02:00:00.84	\N	2026-06-25 02:00:00.807	2026-06-25 02:00:00.84
76ffe6ce-23e5-4e5d-b1c8-33a877587b45	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-25"}	done	0	5	2026-06-25 02:15:00.834	2026-06-25 02:15:00.841	2026-06-25 02:15:00.888	\N	2026-06-25 02:15:00.834	2026-06-25 02:15:00.888
0499ffb5-bee0-45a0-8a1c-effc663f019a	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-25"}	done	0	5	2026-06-25 02:30:00.851	2026-06-25 02:30:00.86	2026-06-25 02:30:00.898	\N	2026-06-25 02:30:00.851	2026-06-25 02:30:00.898
ca6de2e3-19f7-43c3-bc9f-7a410e889389	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-25"}	done	0	5	2026-06-25 03:15:00.866	2026-06-25 03:15:00.885	2026-06-25 03:15:00.927	\N	2026-06-25 03:15:00.866	2026-06-25 03:15:00.927
4b1860a5-c106-413f-8d07-56d296f37de9	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-26"}	done	0	5	2026-06-26 01:00:01.149	2026-06-26 01:00:01.155	2026-06-26 01:00:01.239	\N	2026-06-26 01:00:01.149	2026-06-26 01:00:01.239
8a0d7520-2675-42b1-ad52-2437bfe8e09b	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-07-01"}	done	0	5	2026-07-01 01:30:01.807	2026-07-01 01:30:01.825	2026-07-01 01:30:01.916	\N	2026-07-01 01:30:01.807	2026-07-01 01:30:01.916
8ec64d0c-a6d3-47a4-87c5-7e0fcf84767a	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-26"}	done	0	5	2026-06-26 01:15:01.126	2026-06-26 01:15:01.132	2026-06-26 01:15:01.176	\N	2026-06-26 01:15:01.126	2026-06-26 01:15:01.176
8ac1fd4c-baba-4ce2-b8df-61b2f40593d6	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-07-01"}	done	0	5	2026-07-01 01:45:00.566	2026-07-01 01:45:00.573	2026-07-01 01:45:00.609	\N	2026-07-01 01:45:00.566	2026-07-01 01:45:00.609
9ee28629-6264-4d5b-8a7f-6bc6b873b71b	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-26"}	done	0	5	2026-06-26 02:30:01.173	2026-06-26 02:30:01.181	2026-06-26 02:30:01.215	\N	2026-06-26 02:30:01.173	2026-06-26 02:30:01.215
040f7f8d-453f-481a-bd83-53d85a7fb16d	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-26"}	done	0	5	2026-06-26 01:30:01.165	2026-06-26 01:30:01.173	2026-06-26 01:30:01.22	\N	2026-06-26 01:30:01.165	2026-06-26 01:30:01.22
b2b260aa-7de6-4ff4-ad34-eabcbea0e470	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-26"}	done	0	5	2026-06-26 01:45:01.122	2026-06-26 01:45:01.13	2026-06-26 01:45:01.208	\N	2026-06-26 01:45:01.122	2026-06-26 01:45:01.208
a6eea532-b1f7-41f3-85a4-cd0e105a014d	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-26"}	done	0	5	2026-06-26 03:15:01.121	2026-06-26 03:15:01.128	2026-06-26 03:15:01.166	\N	2026-06-26 03:15:01.121	2026-06-26 03:15:01.166
93167f30-7dfe-4de1-8ecf-951d69649647	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-26 02:00:01.095	2026-06-26 02:00:01.101	2026-06-26 02:00:01.11	\N	2026-06-26 02:00:01.095	2026-06-26 02:00:01.11
76c7c543-0854-41d4-a539-af0367d4b9e6	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-27"}	done	0	5	2026-06-27 01:00:01.389	2026-06-27 01:00:01.396	2026-06-27 01:00:01.485	\N	2026-06-27 01:00:01.389	2026-06-27 01:00:01.485
bef0bfd2-5481-48d3-8a40-ed89642b5b4c	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-27"}	done	0	5	2026-06-27 01:15:01.447	2026-06-27 01:15:01.454	2026-06-27 01:15:01.509	\N	2026-06-27 01:15:01.447	2026-06-27 01:15:01.509
e0c11533-a6f9-473a-a162-0ffc175674ca	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-27"}	done	0	5	2026-06-27 01:30:01.467	2026-06-27 01:30:01.474	2026-06-27 01:30:01.532	\N	2026-06-27 01:30:01.467	2026-06-27 01:30:01.532
312debba-0283-4b84-b36c-63b2aef1b363	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-27"}	done	0	5	2026-06-27 01:45:01.439	2026-06-27 01:45:01.445	2026-06-27 01:45:01.484	\N	2026-06-27 01:45:01.439	2026-06-27 01:45:01.484
33427951-f507-4298-8fef-fe4f42ad299c	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-27 02:00:01.536	2026-06-27 02:00:01.546	2026-06-27 02:00:01.556	\N	2026-06-27 02:00:01.536	2026-06-27 02:00:01.556
c606e6d5-4851-45cd-80a1-661c04cdbbe5	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-27"}	done	0	5	2026-06-27 02:15:01.472	2026-06-27 02:15:01.478	2026-06-27 02:15:01.527	\N	2026-06-27 02:15:01.472	2026-06-27 02:15:01.527
66e6227a-f5b3-4095-8e81-51d9f99c3b7c	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-27"}	done	0	5	2026-06-27 02:30:01.461	2026-06-27 02:30:01.492	2026-06-27 02:30:01.527	\N	2026-06-27 02:30:01.461	2026-06-27 02:30:01.527
4cdb32c5-bb09-47d7-9398-65f577b25e47	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-27"}	done	0	5	2026-06-27 03:15:01.542	2026-06-27 03:15:01.549	2026-06-27 03:15:01.596	\N	2026-06-27 03:15:01.542	2026-06-27 03:15:01.596
f53b87b0-7bbc-4f48-9f05-fad4faa407d9	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-28"}	done	0	5	2026-06-28 01:00:00.782	2026-06-28 01:00:00.791	2026-06-28 01:00:00.881	\N	2026-06-28 01:00:00.782	2026-06-28 01:00:00.881
3dcd7513-2549-44ac-a3d2-3a323f104cb8	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-28"}	done	0	5	2026-06-28 01:15:00.741	2026-06-28 01:15:00.752	2026-06-28 01:15:00.801	\N	2026-06-28 01:15:00.741	2026-06-28 01:15:00.801
1a1b4b91-eceb-4e2d-953b-01f9fffb5e93	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-28"}	done	0	5	2026-06-28 01:30:00.758	2026-06-28 01:30:00.788	2026-06-28 01:30:00.829	\N	2026-06-28 01:30:00.758	2026-06-28 01:30:00.829
7a0b073b-2594-4163-bf58-30308fe5b330	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-28"}	done	0	5	2026-06-28 01:45:00.755	2026-06-28 01:45:00.762	2026-06-28 01:45:00.801	\N	2026-06-28 01:45:00.755	2026-06-28 01:45:00.801
2a7b05c8-0011-4de5-a5ca-7b6376d06d8e	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-28 02:00:00.708	2026-06-28 02:00:00.716	2026-06-28 02:00:00.738	\N	2026-06-28 02:00:00.708	2026-06-28 02:00:00.738
2436963a-2866-40a0-8601-f3b2ff8412f4	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-28"}	done	0	5	2026-06-28 02:15:00.672	2026-06-28 02:15:00.689	2026-06-28 02:15:00.734	\N	2026-06-28 02:15:00.672	2026-06-28 02:15:00.734
5bb1cee4-1757-435c-8d80-968a07fffc99	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-28"}	done	0	5	2026-06-28 02:30:00.774	2026-06-28 02:30:00.808	2026-06-28 02:30:00.841	\N	2026-06-28 02:30:00.774	2026-06-28 02:30:00.841
f28c2ac1-992f-4943-b548-79dce118e8f8	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-28"}	done	0	5	2026-06-28 03:15:00.748	2026-06-28 03:15:00.77	2026-06-28 03:15:00.803	\N	2026-06-28 03:15:00.748	2026-06-28 03:15:00.803
73964b24-a355-4ac8-b1c0-c37613256a5d	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-29"}	done	0	5	2026-06-29 01:00:00.984	2026-06-29 01:00:00.991	2026-06-29 01:00:01.077	\N	2026-06-29 01:00:00.984	2026-06-29 01:00:01.077
2ea1dfbf-b7d4-4e1a-8817-aca3a548364d	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-29"}	done	0	5	2026-06-29 01:15:00.958	2026-06-29 01:15:00.964	2026-06-29 01:15:01.002	\N	2026-06-29 01:15:00.958	2026-06-29 01:15:01.002
eaa6de11-0f3c-4eb8-b0f1-7442ca92529d	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-29"}	done	0	5	2026-06-29 01:30:00.954	2026-06-29 01:30:00.981	2026-06-29 01:30:01.021	\N	2026-06-29 01:30:00.954	2026-06-29 01:30:01.021
caa70af6-d2d4-4a6f-85ad-db4bb0d7cd21	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-29"}	done	0	5	2026-06-29 01:45:01.012	2026-06-29 01:45:01.021	2026-06-29 01:45:01.068	\N	2026-06-29 01:45:01.012	2026-06-29 01:45:01.068
8305ff18-03e9-4437-ae1a-331a49cf4fff	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-29 02:00:01	2026-06-29 02:00:01.007	2026-06-29 02:00:01.015	\N	2026-06-29 02:00:01	2026-06-29 02:00:01.015
eb0f8ec3-ae84-4943-bf4e-496039c6c82e	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-29"}	done	0	5	2026-06-29 02:15:01.039	2026-06-29 02:15:01.046	2026-06-29 02:15:01.089	\N	2026-06-29 02:15:01.039	2026-06-29 02:15:01.089
00bd8751-ac4f-4b09-beeb-5a9e10d9bdb6	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-29"}	done	0	5	2026-06-29 02:30:01.08	2026-06-29 02:30:01.086	2026-06-29 02:30:01.119	\N	2026-06-29 02:30:01.08	2026-06-29 02:30:01.119
15c2d24d-04fb-4db8-aac0-df3207fb32cb	cron.run	{"taskName": "selection.retention_calibration", "scheduledWindow": "2026-06-29"}	done	0	5	2026-06-29 02:45:00.996	2026-06-29 02:45:01.001	2026-06-29 02:45:01.06	\N	2026-06-29 02:45:00.996	2026-06-29 02:45:01.06
9dbb86b6-41ca-4f23-8d57-503c1a47785a	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-29"}	done	0	5	2026-06-29 03:15:01.045	2026-06-29 03:15:01.069	2026-06-29 03:15:01.112	\N	2026-06-29 03:15:01.045	2026-06-29 03:15:01.112
ad4d3d3b-fc52-41d6-8c60-246c871bbb90	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-06-30"}	done	0	5	2026-06-30 01:00:01.326	2026-06-30 01:00:01.335	2026-06-30 01:00:01.448	\N	2026-06-30 01:00:01.326	2026-06-30 01:00:01.448
1e32ccbe-0673-4da9-8b9a-b0de2fc4fbe6	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-06-30"}	done	0	5	2026-06-30 01:15:01.286	2026-06-30 01:15:01.293	2026-06-30 01:15:01.348	\N	2026-06-30 01:15:01.286	2026-06-30 01:15:01.348
150571cb-f837-4602-af25-c1aebcc1b1ec	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-06-30"}	done	0	5	2026-06-30 01:30:01.353	2026-06-30 01:30:01.361	2026-06-30 01:30:01.409	\N	2026-06-30 01:30:01.353	2026-06-30 01:30:01.409
2efaff25-4a60-4286-a580-894f75791e7a	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-06-30"}	done	0	5	2026-06-30 01:45:01.289	2026-06-30 01:45:01.306	2026-06-30 01:45:01.35	\N	2026-06-30 01:45:01.289	2026-06-30 01:45:01.35
daa8ff66-b9d9-4b12-9f7a-31f3e2d970c6	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-06"}	done	0	5	2026-06-30 02:00:01.283	2026-06-30 02:00:01.296	2026-06-30 02:00:01.308	\N	2026-06-30 02:00:01.283	2026-06-30 02:00:01.308
a2f545d5-cfcd-4e64-9cfb-c913859f321e	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-06-30"}	done	0	5	2026-06-30 02:15:01.364	2026-06-30 02:15:01.371	2026-06-30 02:15:01.415	\N	2026-06-30 02:15:01.364	2026-06-30 02:15:01.415
b1a24b84-e278-45d5-9776-007d5533d25f	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-06-30"}	done	0	5	2026-06-30 02:30:01.307	2026-06-30 02:30:01.322	2026-06-30 02:30:01.375	\N	2026-06-30 02:30:01.307	2026-06-30 02:30:01.375
8c3d1463-7e72-4378-bc9b-5750135372ce	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-06-30"}	done	0	5	2026-06-30 03:15:01.346	2026-06-30 03:15:01.352	2026-06-30 03:15:01.402	\N	2026-06-30 03:15:01.346	2026-06-30 03:15:01.402
0e103b2e-66fc-41ed-b641-54130fcff252	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-07-01"}	done	0	5	2026-07-01 01:00:01.601	2026-07-01 01:00:01.613	2026-07-01 01:00:01.7	\N	2026-07-01 01:00:01.601	2026-07-01 01:00:01.7
cf369ef0-858b-495b-a5a5-b2833779d56c	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-07-03"}	done	0	5	2026-07-03 03:15:01.117	2026-07-03 03:15:01.146	2026-07-03 03:15:01.181	\N	2026-07-03 03:15:01.117	2026-07-03 03:15:01.181
b62eff7e-4964-44e8-b960-b57c2da5c961	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-07-03"}	done	0	5	2026-07-03 01:15:01.071	2026-07-03 01:15:01.078	2026-07-03 01:15:01.116	\N	2026-07-03 01:15:01.071	2026-07-03 01:15:01.116
c9e71ee9-a91b-4541-a2e4-4075ce6e1a3a	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-07-03"}	done	0	5	2026-07-03 01:30:01.1	2026-07-03 01:30:01.106	2026-07-03 01:30:01.152	\N	2026-07-03 01:30:01.1	2026-07-03 01:30:01.152
4236b9e2-1c4a-4696-adb6-b1506cb7599f	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-07-03"}	done	0	5	2026-07-03 01:00:01.193	2026-07-03 01:00:01.204	2026-07-03 01:00:01.305	\N	2026-07-03 01:00:01.193	2026-07-03 01:00:01.305
398729bc-17d0-42ce-8a4b-9d10a2e00101	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-07-03"}	done	0	5	2026-07-03 01:45:01.108	2026-07-03 01:45:01.114	2026-07-03 01:45:01.155	\N	2026-07-03 01:45:01.108	2026-07-03 01:45:01.155
80aaacff-d8d3-4446-8cb4-7d66373fb24d	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-07"}	done	0	5	2026-07-03 02:00:01.183	2026-07-03 02:00:01.19	2026-07-03 02:00:01.202	\N	2026-07-03 02:00:01.183	2026-07-03 02:00:01.202
cbf05c69-3361-4590-89ce-e5c98910e26d	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-07-03"}	done	0	5	2026-07-03 02:15:01.099	2026-07-03 02:15:01.109	2026-07-03 02:15:01.157	\N	2026-07-03 02:15:01.099	2026-07-03 02:15:01.157
c9122ce1-0038-4036-b084-3111fee4c9ae	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-07-03"}	done	0	5	2026-07-03 02:30:01.179	2026-07-03 02:30:01.188	2026-07-03 02:30:01.225	\N	2026-07-03 02:30:01.179	2026-07-03 02:30:01.225
e12b79d3-b15d-4f77-b180-13b3be1a0655	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-07-01"}	pending	0	5	2026-07-05 14:10:53.318	\N	\N	\N	2026-07-01 01:15:01.543	2026-07-05 14:10:52.318
0c47b22e-60f3-421c-804d-982c1dd034e2	cron.run	{"taskName": "okr.quarter_start", "scheduledWindow": "2026-07-01"}	done	0	5	2026-07-01 03:00:00.699	2026-07-01 03:00:00.708	2026-07-01 03:00:00.762	\N	2026-07-01 03:00:00.699	2026-07-01 03:00:00.762
2d277d91-df42-44d6-8610-7801230b5657	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-07-01"}	done	0	5	2026-07-01 03:15:00.56	2026-07-01 03:15:00.567	2026-07-01 03:15:00.601	\N	2026-07-01 03:15:00.56	2026-07-01 03:15:00.601
e4fcb30f-c3c3-44ec-8c7d-04f5fe2e2ff1	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-07"}	done	0	5	2026-07-01 02:00:00.583	2026-07-01 02:00:00.589	2026-07-01 02:00:00.638	\N	2026-07-01 02:00:00.583	2026-07-01 02:00:00.638
e4c9fc00-dacb-45f3-aafe-795d137a63ae	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-07-01"}	done	0	5	2026-07-01 02:15:00.572	2026-07-01 02:15:00.577	2026-07-01 02:15:00.622	\N	2026-07-01 02:15:00.572	2026-07-01 02:15:00.622
e999db47-578e-4a86-b76a-767908e930fa	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-07-01"}	done	0	5	2026-07-01 02:30:00.594	2026-07-01 02:30:00.6	2026-07-01 02:30:00.629	\N	2026-07-01 02:30:00.594	2026-07-01 02:30:00.629
6f2149d5-2353-4f82-b5aa-5a44d695a284	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-07-04"}	done	0	5	2026-07-04 03:15:01.449	2026-07-04 03:15:01.481	2026-07-04 03:15:01.522	\N	2026-07-04 03:15:01.449	2026-07-04 03:15:01.522
0fbefc24-1b03-4388-a56c-ad9f4024d89c	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-07-02"}	done	0	5	2026-07-02 03:15:00.874	2026-07-02 03:15:00.879	2026-07-02 03:15:00.914	\N	2026-07-02 03:15:00.874	2026-07-02 03:15:00.914
b3560512-9cad-4089-834c-a95739e78304	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-07-02"}	done	0	5	2026-07-02 02:15:00.945	2026-07-02 02:15:00.954	2026-07-02 02:15:01	\N	2026-07-02 02:15:00.945	2026-07-02 02:15:01
0484ad31-b020-49db-a0bf-5df5257d9419	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-07-02"}	done	0	5	2026-07-02 02:30:00.966	2026-07-02 02:30:00.971	2026-07-02 02:30:01.01	\N	2026-07-02 02:30:00.966	2026-07-02 02:30:01.01
bd3d8201-3743-4daf-a86b-8af8d435a592	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-07-02"}	done	0	5	2026-07-02 01:00:00.876	2026-07-02 01:00:00.89	2026-07-02 01:00:00.981	\N	2026-07-02 01:00:00.876	2026-07-02 01:00:00.981
00767957-dcef-48ce-b77d-d27b245ae518	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-07-02"}	done	0	5	2026-07-02 01:15:00.809	2026-07-02 01:15:00.815	2026-07-02 01:15:00.853	\N	2026-07-02 01:15:00.809	2026-07-02 01:15:00.853
afe54f00-07a3-46fe-b8cf-6aa53acbf9e8	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-07-02"}	done	0	5	2026-07-02 01:30:00.848	2026-07-02 01:30:00.856	2026-07-02 01:30:00.906	\N	2026-07-02 01:30:00.848	2026-07-02 01:30:00.906
e724454e-90ec-445f-8562-8e5f6d3bdb21	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-07-02"}	done	0	5	2026-07-02 01:45:00.864	2026-07-02 01:45:00.891	2026-07-02 01:45:00.928	\N	2026-07-02 01:45:00.864	2026-07-02 01:45:00.928
69d87e01-adbd-41a2-91ef-d11b73616bdc	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-07"}	done	0	5	2026-07-02 02:00:00.933	2026-07-02 02:00:00.951	2026-07-02 02:00:00.964	\N	2026-07-02 02:00:00.933	2026-07-02 02:00:00.964
4ca1ad03-919f-402c-a896-c3584375352e	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-07-05"}	done	0	5	2026-07-05 02:15:00.633	2026-07-05 02:15:00.644	2026-07-05 02:15:00.686	\N	2026-07-05 02:15:00.633	2026-07-05 02:15:00.686
2fa09997-db27-440d-bd06-d32e4297b8a2	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-07-05"}	done	0	5	2026-07-05 02:30:00.671	2026-07-05 02:30:00.686	2026-07-05 02:30:00.718	\N	2026-07-05 02:30:00.671	2026-07-05 02:30:00.718
2fedd4c2-4575-4589-a94a-5192411cdf3a	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-07-05"}	done	0	5	2026-07-05 01:00:00.595	2026-07-05 01:00:00.622	2026-07-05 01:00:00.712	\N	2026-07-05 01:00:00.595	2026-07-05 01:00:00.712
93831ce7-9299-43da-9511-5bb8878942ae	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-07-05"}	done	0	5	2026-07-05 01:15:00.641	2026-07-05 01:15:00.648	2026-07-05 01:15:00.683	\N	2026-07-05 01:15:00.641	2026-07-05 01:15:00.683
7795622e-ec6c-41b9-8d95-79570f18dde0	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-07-05"}	done	0	5	2026-07-05 01:30:00.739	2026-07-05 01:30:00.748	2026-07-05 01:30:00.799	\N	2026-07-05 01:30:00.739	2026-07-05 01:30:00.799
b122a4a1-7012-4f9d-ac6d-f7167a7a9a27	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-07-05"}	done	0	5	2026-07-05 01:45:00.647	2026-07-05 01:45:00.653	2026-07-05 01:45:00.691	\N	2026-07-05 01:45:00.647	2026-07-05 01:45:00.691
e5dd0782-aa16-486e-85f3-e6223af752ae	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-07"}	done	0	5	2026-07-05 02:00:00.609	2026-07-05 02:00:00.631	2026-07-05 02:00:00.639	\N	2026-07-05 02:00:00.609	2026-07-05 02:00:00.639
16fc725e-f43d-4b72-9baa-449e1bd9e4f0	cron.run	{"taskName": "signals.compute", "scheduledWindow": "2026-07-04"}	done	0	5	2026-07-04 02:15:01.378	2026-07-04 02:15:01.388	2026-07-04 02:15:01.445	\N	2026-07-04 02:15:01.378	2026-07-04 02:15:01.445
566a76d7-bea0-4aff-99e9-7f0af49585a6	cron.run	{"taskName": "selection.retention_outcomes", "scheduledWindow": "2026-07-04"}	done	0	5	2026-07-04 02:30:01.405	2026-07-04 02:30:01.412	2026-07-04 02:30:01.453	\N	2026-07-04 02:30:01.405	2026-07-04 02:30:01.453
16e8c49f-40c6-4b79-9445-24e9ffc4edc6	cron.run	{"taskName": "analytics.snapshot", "scheduledWindow": "2026-07-04"}	done	0	5	2026-07-04 01:00:01.382	2026-07-04 01:00:01.391	2026-07-04 01:00:01.478	\N	2026-07-04 01:00:01.382	2026-07-04 01:00:01.478
db7d6f9c-0359-42d6-b715-67e1f169cacd	cron.run	{"taskName": "probation.reminder", "scheduledWindow": "2026-07-04"}	done	0	5	2026-07-04 01:15:01.394	2026-07-04 01:15:01.408	2026-07-04 01:15:01.45	\N	2026-07-04 01:15:01.394	2026-07-04 01:15:01.45
fa627c0f-d767-4b6e-82e6-2854f04da355	cron.run	{"taskName": "1on1.reminder", "scheduledWindow": "2026-07-04"}	done	0	5	2026-07-04 01:30:01.374	2026-07-04 01:30:01.383	2026-07-04 01:30:01.433	\N	2026-07-04 01:30:01.374	2026-07-04 01:30:01.433
0c640be1-f593-4d31-8219-dde9b136422a	cron.run	{"taskName": "review.reminder", "scheduledWindow": "2026-07-04"}	done	0	5	2026-07-04 01:45:01.456	2026-07-04 01:45:01.463	2026-07-04 01:45:01.502	\N	2026-07-04 01:45:01.456	2026-07-04 01:45:01.502
df61c4e4-f3ba-4e40-84e6-7fa998da7075	cron.run	{"taskName": "data.retention", "scheduledWindow": "2026-07"}	done	0	5	2026-07-04 02:00:01.651	2026-07-04 02:00:01.662	2026-07-04 02:00:01.675	\N	2026-07-04 02:00:01.651	2026-07-04 02:00:01.675
a469201c-0853-41e5-b2aa-5017cf83e4ef	cron.run	{"taskName": "hh.sourcing", "scheduledWindow": "2026-07-05"}	done	0	5	2026-07-05 03:15:00.679	2026-07-05 03:15:00.684	2026-07-05 03:15:00.716	\N	2026-07-05 03:15:00.679	2026-07-05 03:15:00.716
\.


--
-- Data for Name: resumes; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.resumes (id, tenant_id, candidate_id, file_url, parsed_payload, uploaded_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: review_cycles; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.review_cycles (id, tenant_id, title, quarter, status, questions, opened_at, closes_at, closed_at, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: review_requests; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.review_requests (id, tenant_id, cycle_id, subject_employee_id, reviewer_user_id, relationship, status, response, decline_reason, submitted_at, declined_at, reminder_sent_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: selection_retention_outcomes; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.selection_retention_outcomes (id, tenant_id, session_id, hire_date, observed_days, survived_30, survived_60, survived_90, termination_ground, outcome_status, computed_at) FROM stdin;
\.


--
-- Data for Name: selection_scoring_weights; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.selection_scoring_weights (id, tenant_id, model_version, weights, sample_size, computed_at, active) FROM stdin;
\.


--
-- Data for Name: selection_sessions; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.selection_sessions (id, tenant_id, application_id, template_id, token, status, started_at, completed_at, expires_at, created_at, assessment_profile, specializations, flags) FROM stdin;
\.


--
-- Data for Name: selection_stage_results; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.selection_stage_results (id, session_id, stage_number, answers, scores, flags, ai_evaluation, submitted_at) FROM stdin;
\.


--
-- Data for Name: selection_templates; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.selection_templates (id, tenant_id, vacancy_id, role, stages, created_at) FROM stdin;
\.


--
-- Data for Name: selection_verdicts; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.selection_verdicts (id, session_id, verdict, total_weighted_score, stage_scores, cross_check_flags, lie_scale_result, verdict_reason, hr_notes, created_at, retention_prediction) FROM stdin;
\.


--
-- Data for Name: specialization_module_results; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.specialization_module_results (id, session_id, package_id, level, raw_score, max_score, weighted_score, flags, submitted_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.subscriptions (id, tenant_id, plan_id, status, current_period_end, stripe_subscription_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: telegram_links; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.telegram_links (id, tenant_id, candidate_id, employee_id, chat_id, is_active, linked_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenant_settings; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.tenant_settings (tenant_id, logo_url, primary_color, timezone, locale, feature_flags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.tenants (id, name, created_at, updated_at, slug, subdomain) FROM stdin;
019e72e8-7296-7d04-86de-6766827d80f8	Pacific Star	2026-05-29 08:44:56.849	2026-05-29 08:44:56.849	\N	\N
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.user_roles (user_id, role, tenant_id, created_at) FROM stdin;
019e72e8-735d-7c54-b229-08222aa2c6ca	owner	019e72e8-7296-7d04-86de-6766827d80f8	2026-05-29 08:44:57.083
019f324a-0df9-7a4a-835a-f6f742e2d659	owner	019e72e8-7296-7d04-86de-6766827d80f8	2026-07-05 14:28:35.765
019e8bd6-0aea-7b42-9ed7-28afab973de7	recruiter	019e72e8-7296-7d04-86de-6766827d80f8	2026-07-06 03:05:10.317
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.users (id, email, password_hash, display_name, created_at, updated_at, disabled_at) FROM stdin;
019e72e8-735d-7c54-b229-08222aa2c6ca	bossssmann@gmail.com	$argon2id$v=19$m=65536,t=2,p=1$TvjDzhnn3K93dHCmRxWTdZPcnYN3iml9X5wdaDvm2nk$zYi0YRRiU5/rV27BQEnGdt0Z6Xb4YmPuow8sNCgdANw	Администратор	2026-05-29 08:44:57.05	2026-05-29 08:44:57.05	\N
019e8bd6-0aea-7b42-9ed7-28afab973de7	sales@pacificstar.ru	$argon2id$v=19$m=65536,t=2,p=1$ZCUubBVqQa39j9Y2NLTZzLIavi5+dSNsUenP5X1ASSE$vaFwfNoBszXCtFLf5fbDJvZLLDnEknKwEzhMPOwEe6c	Ирина	2026-06-03 04:55:21.061	2026-06-03 04:55:21.061	\N
019f324a-0df9-7a4a-835a-f6f742e2d659	bossmann@inbox.ru	$argon2id$v=19$m=65536,t=2,p=1$DCif+NJbLEwO882mJlQF5B6yuvYXPeZW1Nbc8GzHJlo$seG9JyM23t2pZ4uShoH5GajFJh8Fc9nxRd8wZkYkxUE	Роман Хмелев	2026-07-05 12:39:01.878	2026-07-05 12:39:01.878	\N
\.


--
-- Data for Name: vacancies; Type: TABLE DATA; Schema: public; Owner: hr_user
--

COPY public.vacancies (id, tenant_id, requisition_id, org_unit_id, title, description, is_published, created_at, updated_at, hh_vacancy_id, slug, hh_sourcing_criteria, role) FROM stdin;
019e8d16-224f-77a8-b24d-4de278134fd3	019e72e8-7296-7d04-86de-6766827d80f8	019e8d15-f68a-7485-b1d2-a43c965dfc1f	019e8d14-53b6-7e8d-8b82-0ecc4c788206	Логист	Расширение 	t	2026-06-03 10:44:58.574	2026-07-05 14:54:59.254	134599233	логист	\N	\N
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: alumni_profiles alumni_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.alumni_profiles
    ADD CONSTRAINT alumni_profiles_pkey PRIMARY KEY (id);


--
-- Name: analytics_signals analytics_signals_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.analytics_signals
    ADD CONSTRAINT analytics_signals_pkey PRIMARY KEY (id);


--
-- Name: application_stage_events application_stage_events_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.application_stage_events
    ADD CONSTRAINT application_stage_events_pkey PRIMARY KEY (id);


--
-- Name: applications applications_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_pkey PRIMARY KEY (id);


--
-- Name: assessment_answers assessment_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.assessment_answers
    ADD CONSTRAINT assessment_answers_pkey PRIMARY KEY (id);


--
-- Name: assessment_questions assessment_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.assessment_questions
    ADD CONSTRAINT assessment_questions_pkey PRIMARY KEY (id);


--
-- Name: assessment_sessions assessment_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.assessment_sessions
    ADD CONSTRAINT assessment_sessions_pkey PRIMARY KEY (id);


--
-- Name: assessment_templates assessment_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.assessment_templates
    ADD CONSTRAINT assessment_templates_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: candidates candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.candidates
    ADD CONSTRAINT candidates_pkey PRIMARY KEY (id);


--
-- Name: comp_bands comp_bands_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.comp_bands
    ADD CONSTRAINT comp_bands_pkey PRIMARY KEY (id);


--
-- Name: comp_plan_items comp_plan_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.comp_plan_items
    ADD CONSTRAINT comp_plan_items_pkey PRIMARY KEY (id);


--
-- Name: comp_plans comp_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.comp_plans
    ADD CONSTRAINT comp_plans_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: cron_job_runs cron_job_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.cron_job_runs
    ADD CONSTRAINT cron_job_runs_pkey PRIMARY KEY (id);


--
-- Name: data_retention_policies data_retention_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.data_retention_policies
    ADD CONSTRAINT data_retention_policies_pkey PRIMARY KEY (id);


--
-- Name: device_tokens device_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.device_tokens
    ADD CONSTRAINT device_tokens_pkey PRIMARY KEY (id);


--
-- Name: employee_lifecycle_events employee_lifecycle_events_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.employee_lifecycle_events
    ADD CONSTRAINT employee_lifecycle_events_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: employment_documents employment_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.employment_documents
    ADD CONSTRAINT employment_documents_pkey PRIMARY KEY (id);


--
-- Name: exit_interviews exit_interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.exit_interviews
    ADD CONSTRAINT exit_interviews_pkey PRIMARY KEY (id);


--
-- Name: external_vacancy_posts external_vacancy_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.external_vacancy_posts
    ADD CONSTRAINT external_vacancy_posts_pkey PRIMARY KEY (id);


--
-- Name: hh_connections hh_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.hh_connections
    ADD CONSTRAINT hh_connections_pkey PRIMARY KEY (id);


--
-- Name: hh_sync_cursors hh_sync_cursors_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.hh_sync_cursors
    ADD CONSTRAINT hh_sync_cursors_pkey PRIMARY KEY (id);


--
-- Name: hiring_requisitions hiring_requisitions_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.hiring_requisitions
    ADD CONSTRAINT hiring_requisitions_pkey PRIMARY KEY (id);


--
-- Name: hr_snapshots hr_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.hr_snapshots
    ADD CONSTRAINT hr_snapshots_pkey PRIMARY KEY (id);


--
-- Name: idp_items idp_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.idp_items
    ADD CONSTRAINT idp_items_pkey PRIMARY KEY (id);


--
-- Name: idps idps_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.idps
    ADD CONSTRAINT idps_pkey PRIMARY KEY (id);


--
-- Name: interviews interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_pkey PRIMARY KEY (id);


--
-- Name: key_results key_results_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.key_results
    ADD CONSTRAINT key_results_pkey PRIMARY KEY (id);


--
-- Name: knowledge_articles knowledge_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.knowledge_articles
    ADD CONSTRAINT knowledge_articles_pkey PRIMARY KEY (id);


--
-- Name: learning_assignments learning_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.learning_assignments
    ADD CONSTRAINT learning_assignments_pkey PRIMARY KEY (id);


--
-- Name: learning_courses learning_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.learning_courses
    ADD CONSTRAINT learning_courses_pkey PRIMARY KEY (id);


--
-- Name: learning_path_items learning_path_items_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.learning_path_items
    ADD CONSTRAINT learning_path_items_pkey PRIMARY KEY (id);


--
-- Name: learning_paths learning_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.learning_paths
    ADD CONSTRAINT learning_paths_pkey PRIMARY KEY (id);


--
-- Name: message_templates message_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: offboarding_checklists offboarding_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.offboarding_checklists
    ADD CONSTRAINT offboarding_checklists_pkey PRIMARY KEY (id);


--
-- Name: offboarding_tasks offboarding_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.offboarding_tasks
    ADD CONSTRAINT offboarding_tasks_pkey PRIMARY KEY (id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: okrs okrs_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.okrs
    ADD CONSTRAINT okrs_pkey PRIMARY KEY (id);


--
-- Name: onboarding_checklists onboarding_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.onboarding_checklists
    ADD CONSTRAINT onboarding_checklists_pkey PRIMARY KEY (id);


--
-- Name: onboarding_tasks onboarding_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.onboarding_tasks
    ADD CONSTRAINT onboarding_tasks_pkey PRIMARY KEY (id);


--
-- Name: one_on_ones one_on_ones_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.one_on_ones
    ADD CONSTRAINT one_on_ones_pkey PRIMARY KEY (id);


--
-- Name: org_units org_units_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.org_units
    ADD CONSTRAINT org_units_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: pre_start_portal_entries pre_start_portal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.pre_start_portal_entries
    ADD CONSTRAINT pre_start_portal_entries_pkey PRIMARY KEY (id);


--
-- Name: queue_jobs queue_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.queue_jobs
    ADD CONSTRAINT queue_jobs_pkey PRIMARY KEY (id);


--
-- Name: resumes resumes_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.resumes
    ADD CONSTRAINT resumes_pkey PRIMARY KEY (id);


--
-- Name: review_cycles review_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.review_cycles
    ADD CONSTRAINT review_cycles_pkey PRIMARY KEY (id);


--
-- Name: review_requests review_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.review_requests
    ADD CONSTRAINT review_requests_pkey PRIMARY KEY (id);


--
-- Name: selection_retention_outcomes selection_retention_outcomes_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_retention_outcomes
    ADD CONSTRAINT selection_retention_outcomes_pkey PRIMARY KEY (id);


--
-- Name: selection_retention_outcomes selection_retention_outcomes_session_id_key; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_retention_outcomes
    ADD CONSTRAINT selection_retention_outcomes_session_id_key UNIQUE (session_id);


--
-- Name: selection_scoring_weights selection_scoring_weights_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_scoring_weights
    ADD CONSTRAINT selection_scoring_weights_pkey PRIMARY KEY (id);


--
-- Name: selection_scoring_weights selection_scoring_weights_tenant_model_uk; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_scoring_weights
    ADD CONSTRAINT selection_scoring_weights_tenant_model_uk UNIQUE (tenant_id, model_version);


--
-- Name: selection_sessions selection_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_sessions
    ADD CONSTRAINT selection_sessions_pkey PRIMARY KEY (id);


--
-- Name: selection_stage_results selection_stage_results_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_stage_results
    ADD CONSTRAINT selection_stage_results_pkey PRIMARY KEY (id);


--
-- Name: selection_templates selection_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_templates
    ADD CONSTRAINT selection_templates_pkey PRIMARY KEY (id);


--
-- Name: selection_verdicts selection_verdicts_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_verdicts
    ADD CONSTRAINT selection_verdicts_pkey PRIMARY KEY (id);


--
-- Name: specialization_module_results specialization_module_results_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.specialization_module_results
    ADD CONSTRAINT specialization_module_results_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: telegram_links telegram_links_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.telegram_links
    ADD CONSTRAINT telegram_links_pkey PRIMARY KEY (id);


--
-- Name: tenant_settings tenant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_pkey PRIMARY KEY (tenant_id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role, tenant_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vacancies vacancies_pkey; Type: CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.vacancies
    ADD CONSTRAINT vacancies_pkey PRIMARY KEY (id);


--
-- Name: alumni_profiles_employee_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX alumni_profiles_employee_id_key ON public.alumni_profiles USING btree (employee_id);


--
-- Name: alumni_profiles_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX alumni_profiles_status_idx ON public.alumni_profiles USING btree (status);


--
-- Name: alumni_profiles_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX alumni_profiles_tenant_id_idx ON public.alumni_profiles USING btree (tenant_id);


--
-- Name: analytics_signals_employee_type_uk; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX analytics_signals_employee_type_uk ON public.analytics_signals USING btree (employee_id, type);


--
-- Name: analytics_signals_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX analytics_signals_status_idx ON public.analytics_signals USING btree (status);


--
-- Name: analytics_signals_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX analytics_signals_tenant_id_idx ON public.analytics_signals USING btree (tenant_id);


--
-- Name: analytics_signals_type_score_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX analytics_signals_type_score_idx ON public.analytics_signals USING btree (type, score);


--
-- Name: application_stage_events_actor_user_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX application_stage_events_actor_user_id_idx ON public.application_stage_events USING btree (actor_user_id);


--
-- Name: application_stage_events_application_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX application_stage_events_application_id_idx ON public.application_stage_events USING btree (application_id);


--
-- Name: application_stage_events_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX application_stage_events_tenant_id_idx ON public.application_stage_events USING btree (tenant_id);


--
-- Name: applications_assigned_to_user_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX applications_assigned_to_user_id_idx ON public.applications USING btree (assigned_to_user_id);


--
-- Name: applications_candidate_vacancy_unique; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX applications_candidate_vacancy_unique ON public.applications USING btree (candidate_id, vacancy_id);


--
-- Name: applications_stage_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX applications_stage_idx ON public.applications USING btree (stage);


--
-- Name: applications_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX applications_tenant_id_idx ON public.applications USING btree (tenant_id);


--
-- Name: applications_vacancy_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX applications_vacancy_id_idx ON public.applications USING btree (vacancy_id);


--
-- Name: assessment_answers_question_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX assessment_answers_question_id_idx ON public.assessment_answers USING btree (question_id);


--
-- Name: assessment_answers_session_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX assessment_answers_session_id_idx ON public.assessment_answers USING btree (session_id);


--
-- Name: assessment_answers_session_question_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX assessment_answers_session_question_key ON public.assessment_answers USING btree (session_id, question_id);


--
-- Name: assessment_questions_template_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX assessment_questions_template_id_idx ON public.assessment_questions USING btree (template_id);


--
-- Name: assessment_questions_template_order_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX assessment_questions_template_order_key ON public.assessment_questions USING btree (template_id, question_order);


--
-- Name: assessment_sessions_application_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX assessment_sessions_application_id_idx ON public.assessment_sessions USING btree (application_id);


--
-- Name: assessment_sessions_invite_token_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX assessment_sessions_invite_token_key ON public.assessment_sessions USING btree (invite_token);


--
-- Name: assessment_sessions_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX assessment_sessions_tenant_id_idx ON public.assessment_sessions USING btree (tenant_id);


--
-- Name: assessment_templates_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX assessment_templates_tenant_id_idx ON public.assessment_templates USING btree (tenant_id);


--
-- Name: assessment_templates_vacancy_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX assessment_templates_vacancy_id_idx ON public.assessment_templates USING btree (vacancy_id);


--
-- Name: audit_events_actor_created_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX audit_events_actor_created_idx ON public.audit_events USING btree (actor_user_id, created_at);


--
-- Name: audit_events_entity_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX audit_events_entity_idx ON public.audit_events USING btree (entity_type, entity_id);


--
-- Name: audit_events_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX audit_events_tenant_id_idx ON public.audit_events USING btree (tenant_id);


--
-- Name: auth_sessions_expires_at_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX auth_sessions_expires_at_idx ON public.auth_sessions USING btree (expires_at);


--
-- Name: auth_sessions_refresh_token_hash_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX auth_sessions_refresh_token_hash_key ON public.auth_sessions USING btree (refresh_token_hash);


--
-- Name: auth_sessions_user_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX auth_sessions_user_id_idx ON public.auth_sessions USING btree (user_id);


--
-- Name: candidates_tenant_email_unique; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX candidates_tenant_email_unique ON public.candidates USING btree (tenant_id, email) WHERE (email IS NOT NULL);


--
-- Name: candidates_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX candidates_tenant_id_idx ON public.candidates USING btree (tenant_id);


--
-- Name: candidates_tenant_phone_unique; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX candidates_tenant_phone_unique ON public.candidates USING btree (tenant_id, phone) WHERE (phone IS NOT NULL);


--
-- Name: comp_bands_tenant_grade_currency_unique; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX comp_bands_tenant_grade_currency_unique ON public.comp_bands USING btree (tenant_id, grade, currency);


--
-- Name: comp_bands_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX comp_bands_tenant_id_idx ON public.comp_bands USING btree (tenant_id);


--
-- Name: comp_plan_items_employee_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX comp_plan_items_employee_id_idx ON public.comp_plan_items USING btree (employee_id);


--
-- Name: comp_plan_items_plan_employee_unique; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX comp_plan_items_plan_employee_unique ON public.comp_plan_items USING btree (plan_id, employee_id);


--
-- Name: comp_plan_items_plan_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX comp_plan_items_plan_id_idx ON public.comp_plan_items USING btree (plan_id);


--
-- Name: comp_plan_items_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX comp_plan_items_tenant_id_idx ON public.comp_plan_items USING btree (tenant_id);


--
-- Name: comp_plans_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX comp_plans_status_idx ON public.comp_plans USING btree (status);


--
-- Name: comp_plans_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX comp_plans_tenant_id_idx ON public.comp_plans USING btree (tenant_id);


--
-- Name: conversations_application_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX conversations_application_id_idx ON public.conversations USING btree (application_id);


--
-- Name: conversations_candidate_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX conversations_candidate_id_idx ON public.conversations USING btree (candidate_id);


--
-- Name: conversations_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX conversations_tenant_id_idx ON public.conversations USING btree (tenant_id);


--
-- Name: cron_job_runs_job_window_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX cron_job_runs_job_window_idx ON public.cron_job_runs USING btree (job_name, scheduled_window, attempt);


--
-- Name: cron_job_runs_tenant_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX cron_job_runs_tenant_idx ON public.cron_job_runs USING btree (tenant_id, job_name, scheduled_window);


--
-- Name: data_retention_policies_tenant_entity_uk; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX data_retention_policies_tenant_entity_uk ON public.data_retention_policies USING btree (tenant_id, entity_type);


--
-- Name: data_retention_policies_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX data_retention_policies_tenant_id_idx ON public.data_retention_policies USING btree (tenant_id);


--
-- Name: device_tokens_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX device_tokens_tenant_id_idx ON public.device_tokens USING btree (tenant_id);


--
-- Name: device_tokens_user_active_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX device_tokens_user_active_idx ON public.device_tokens USING btree (user_id, is_active);


--
-- Name: device_tokens_user_id_token_uk; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX device_tokens_user_id_token_uk ON public.device_tokens USING btree (user_id, token);


--
-- Name: employee_lifecycle_events_employee_effective_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employee_lifecycle_events_employee_effective_idx ON public.employee_lifecycle_events USING btree (employee_id, effective_at);


--
-- Name: employee_lifecycle_events_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employee_lifecycle_events_tenant_id_idx ON public.employee_lifecycle_events USING btree (tenant_id);


--
-- Name: employee_lifecycle_events_type_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employee_lifecycle_events_type_idx ON public.employee_lifecycle_events USING btree (type);


--
-- Name: employees_application_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX employees_application_id_key ON public.employees USING btree (application_id) WHERE (application_id IS NOT NULL);


--
-- Name: employees_candidate_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employees_candidate_id_idx ON public.employees USING btree (candidate_id);


--
-- Name: employees_org_unit_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employees_org_unit_id_idx ON public.employees USING btree (org_unit_id);


--
-- Name: employees_requisition_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employees_requisition_id_idx ON public.employees USING btree (requisition_id);


--
-- Name: employees_role_family_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employees_role_family_idx ON public.employees USING btree (role_family);


--
-- Name: employees_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employees_status_idx ON public.employees USING btree (status);


--
-- Name: employees_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employees_tenant_id_idx ON public.employees USING btree (tenant_id);


--
-- Name: employees_user_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employees_user_id_idx ON public.employees USING btree (user_id);


--
-- Name: employees_user_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX employees_user_id_key ON public.employees USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: employment_documents_employee_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employment_documents_employee_id_idx ON public.employment_documents USING btree (employee_id);


--
-- Name: employment_documents_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employment_documents_status_idx ON public.employment_documents USING btree (status);


--
-- Name: employment_documents_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employment_documents_tenant_id_idx ON public.employment_documents USING btree (tenant_id);


--
-- Name: employment_documents_type_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX employment_documents_type_idx ON public.employment_documents USING btree (type);


--
-- Name: exit_interviews_employee_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX exit_interviews_employee_id_key ON public.exit_interviews USING btree (employee_id);


--
-- Name: exit_interviews_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX exit_interviews_tenant_id_idx ON public.exit_interviews USING btree (tenant_id);


--
-- Name: external_vacancy_posts_board_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX external_vacancy_posts_board_status_idx ON public.external_vacancy_posts USING btree (board, status);


--
-- Name: external_vacancy_posts_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX external_vacancy_posts_tenant_id_idx ON public.external_vacancy_posts USING btree (tenant_id);


--
-- Name: external_vacancy_posts_vacancy_board_uk; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX external_vacancy_posts_vacancy_board_uk ON public.external_vacancy_posts USING btree (vacancy_id, board);


--
-- Name: hh_connections_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX hh_connections_tenant_id_idx ON public.hh_connections USING btree (tenant_id);


--
-- Name: hh_connections_tenant_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX hh_connections_tenant_id_key ON public.hh_connections USING btree (tenant_id);


--
-- Name: hh_sync_cursors_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX hh_sync_cursors_tenant_id_idx ON public.hh_sync_cursors USING btree (tenant_id);


--
-- Name: hh_sync_cursors_vacancy_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX hh_sync_cursors_vacancy_id_idx ON public.hh_sync_cursors USING btree (vacancy_id);


--
-- Name: hh_sync_cursors_vacancy_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX hh_sync_cursors_vacancy_id_key ON public.hh_sync_cursors USING btree (vacancy_id);


--
-- Name: hiring_requisitions_created_by_user_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX hiring_requisitions_created_by_user_id_idx ON public.hiring_requisitions USING btree (created_by_user_id);


--
-- Name: hiring_requisitions_org_unit_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX hiring_requisitions_org_unit_id_idx ON public.hiring_requisitions USING btree (org_unit_id);


--
-- Name: hiring_requisitions_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX hiring_requisitions_status_idx ON public.hiring_requisitions USING btree (status);


--
-- Name: hiring_requisitions_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX hiring_requisitions_tenant_id_idx ON public.hiring_requisitions USING btree (tenant_id);


--
-- Name: hr_snapshots_date_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX hr_snapshots_date_idx ON public.hr_snapshots USING btree (snapshot_date);


--
-- Name: hr_snapshots_tenant_date_unique; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX hr_snapshots_tenant_date_unique ON public.hr_snapshots USING btree (tenant_id, snapshot_date);


--
-- Name: hr_snapshots_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX hr_snapshots_tenant_id_idx ON public.hr_snapshots USING btree (tenant_id);


--
-- Name: idp_items_idp_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX idp_items_idp_id_idx ON public.idp_items USING btree (idp_id);


--
-- Name: idp_items_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX idp_items_tenant_id_idx ON public.idp_items USING btree (tenant_id);


--
-- Name: idps_employee_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX idps_employee_id_idx ON public.idps USING btree (employee_id);


--
-- Name: idps_employee_quarter_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX idps_employee_quarter_key ON public.idps USING btree (employee_id, quarter);


--
-- Name: idps_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX idps_tenant_id_idx ON public.idps USING btree (tenant_id);


--
-- Name: interviews_application_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX interviews_application_id_idx ON public.interviews USING btree (application_id);


--
-- Name: interviews_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX interviews_tenant_id_idx ON public.interviews USING btree (tenant_id);


--
-- Name: key_results_okr_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX key_results_okr_id_idx ON public.key_results USING btree (okr_id);


--
-- Name: key_results_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX key_results_tenant_id_idx ON public.key_results USING btree (tenant_id);


--
-- Name: knowledge_articles_deleted_at_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX knowledge_articles_deleted_at_idx ON public.knowledge_articles USING btree (deleted_at);


--
-- Name: knowledge_articles_search_vector_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX knowledge_articles_search_vector_idx ON public.knowledge_articles USING gin (search_vector);


--
-- Name: knowledge_articles_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX knowledge_articles_tenant_id_idx ON public.knowledge_articles USING btree (tenant_id);


--
-- Name: learning_assignments_employee_course_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX learning_assignments_employee_course_key ON public.learning_assignments USING btree (employee_id, course_id) WHERE (course_id IS NOT NULL);


--
-- Name: learning_assignments_employee_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_assignments_employee_id_idx ON public.learning_assignments USING btree (employee_id);


--
-- Name: learning_assignments_employee_path_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX learning_assignments_employee_path_key ON public.learning_assignments USING btree (employee_id, path_id) WHERE (path_id IS NOT NULL);


--
-- Name: learning_assignments_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_assignments_status_idx ON public.learning_assignments USING btree (status);


--
-- Name: learning_assignments_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_assignments_tenant_id_idx ON public.learning_assignments USING btree (tenant_id);


--
-- Name: learning_courses_deleted_at_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_courses_deleted_at_idx ON public.learning_courses USING btree (deleted_at);


--
-- Name: learning_courses_org_unit_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_courses_org_unit_id_idx ON public.learning_courses USING btree (org_unit_id);


--
-- Name: learning_courses_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_courses_tenant_id_idx ON public.learning_courses USING btree (tenant_id);


--
-- Name: learning_path_items_path_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_path_items_path_id_idx ON public.learning_path_items USING btree (path_id);


--
-- Name: learning_path_items_path_order_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX learning_path_items_path_order_key ON public.learning_path_items USING btree (path_id, item_order);


--
-- Name: learning_path_items_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_path_items_tenant_id_idx ON public.learning_path_items USING btree (tenant_id);


--
-- Name: learning_paths_deleted_at_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_paths_deleted_at_idx ON public.learning_paths USING btree (deleted_at);


--
-- Name: learning_paths_role_family_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_paths_role_family_idx ON public.learning_paths USING btree (role_family);


--
-- Name: learning_paths_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX learning_paths_tenant_id_idx ON public.learning_paths USING btree (tenant_id);


--
-- Name: message_templates_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX message_templates_tenant_id_idx ON public.message_templates USING btree (tenant_id);


--
-- Name: messages_channel_external_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX messages_channel_external_id_idx ON public.messages USING btree (channel, external_id);


--
-- Name: messages_channel_external_id_unique; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX messages_channel_external_id_unique ON public.messages USING btree (channel, external_id) WHERE (external_id IS NOT NULL);


--
-- Name: messages_conversation_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX messages_conversation_id_idx ON public.messages USING btree (conversation_id);


--
-- Name: messages_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX messages_tenant_id_idx ON public.messages USING btree (tenant_id);


--
-- Name: notifications_recipient_read_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX notifications_recipient_read_idx ON public.notifications USING btree (recipient_user_id, read_at);


--
-- Name: notifications_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX notifications_tenant_id_idx ON public.notifications USING btree (tenant_id);


--
-- Name: offboarding_checklists_employee_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX offboarding_checklists_employee_id_idx ON public.offboarding_checklists USING btree (employee_id);


--
-- Name: offboarding_checklists_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX offboarding_checklists_tenant_id_idx ON public.offboarding_checklists USING btree (tenant_id);


--
-- Name: offboarding_tasks_checklist_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX offboarding_tasks_checklist_id_idx ON public.offboarding_tasks USING btree (checklist_id);


--
-- Name: offboarding_tasks_checklist_order_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX offboarding_tasks_checklist_order_key ON public.offboarding_tasks USING btree (checklist_id, task_order);


--
-- Name: offboarding_tasks_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX offboarding_tasks_status_idx ON public.offboarding_tasks USING btree (status);


--
-- Name: offboarding_tasks_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX offboarding_tasks_tenant_id_idx ON public.offboarding_tasks USING btree (tenant_id);


--
-- Name: offers_application_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX offers_application_id_idx ON public.offers USING btree (application_id);


--
-- Name: offers_status_expires_at_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX offers_status_expires_at_idx ON public.offers USING btree (status, expires_at);


--
-- Name: offers_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX offers_tenant_id_idx ON public.offers USING btree (tenant_id);


--
-- Name: okrs_employee_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX okrs_employee_id_idx ON public.okrs USING btree (employee_id);


--
-- Name: okrs_parent_okr_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX okrs_parent_okr_id_idx ON public.okrs USING btree (parent_okr_id);


--
-- Name: okrs_quarter_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX okrs_quarter_idx ON public.okrs USING btree (quarter);


--
-- Name: okrs_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX okrs_tenant_id_idx ON public.okrs USING btree (tenant_id);


--
-- Name: onboarding_checklists_employee_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX onboarding_checklists_employee_id_idx ON public.onboarding_checklists USING btree (employee_id);


--
-- Name: onboarding_checklists_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX onboarding_checklists_tenant_id_idx ON public.onboarding_checklists USING btree (tenant_id);


--
-- Name: onboarding_tasks_checklist_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX onboarding_tasks_checklist_id_idx ON public.onboarding_tasks USING btree (checklist_id);


--
-- Name: onboarding_tasks_checklist_order_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX onboarding_tasks_checklist_order_key ON public.onboarding_tasks USING btree (checklist_id, task_order);


--
-- Name: onboarding_tasks_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX onboarding_tasks_status_idx ON public.onboarding_tasks USING btree (status);


--
-- Name: onboarding_tasks_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX onboarding_tasks_tenant_id_idx ON public.onboarding_tasks USING btree (tenant_id);


--
-- Name: one_on_ones_employee_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX one_on_ones_employee_id_idx ON public.one_on_ones USING btree (employee_id);


--
-- Name: one_on_ones_manager_user_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX one_on_ones_manager_user_id_idx ON public.one_on_ones USING btree (manager_user_id);


--
-- Name: one_on_ones_scheduled_at_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX one_on_ones_scheduled_at_idx ON public.one_on_ones USING btree (scheduled_at);


--
-- Name: one_on_ones_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX one_on_ones_status_idx ON public.one_on_ones USING btree (status);


--
-- Name: one_on_ones_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX one_on_ones_tenant_id_idx ON public.one_on_ones USING btree (tenant_id);


--
-- Name: org_units_parent_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX org_units_parent_id_idx ON public.org_units USING btree (parent_id);


--
-- Name: org_units_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX org_units_tenant_id_idx ON public.org_units USING btree (tenant_id);


--
-- Name: password_reset_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX password_reset_tokens_expires_at_idx ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: password_reset_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX password_reset_tokens_token_hash_key ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: password_reset_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX password_reset_tokens_user_id_idx ON public.password_reset_tokens USING btree (user_id);


--
-- Name: plans_name_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX plans_name_key ON public.plans USING btree (name);


--
-- Name: pre_start_portal_entries_employee_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX pre_start_portal_entries_employee_id_key ON public.pre_start_portal_entries USING btree (employee_id);


--
-- Name: pre_start_portal_entries_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX pre_start_portal_entries_status_idx ON public.pre_start_portal_entries USING btree (status);


--
-- Name: pre_start_portal_entries_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX pre_start_portal_entries_tenant_id_idx ON public.pre_start_portal_entries USING btree (tenant_id);


--
-- Name: queue_jobs_pending_available_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX queue_jobs_pending_available_idx ON public.queue_jobs USING btree (status, available_at, created_at);


--
-- Name: queue_jobs_queue_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX queue_jobs_queue_status_idx ON public.queue_jobs USING btree (queue_name, status, available_at);


--
-- Name: resumes_candidate_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX resumes_candidate_id_idx ON public.resumes USING btree (candidate_id);


--
-- Name: resumes_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX resumes_tenant_id_idx ON public.resumes USING btree (tenant_id);


--
-- Name: review_cycles_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX review_cycles_status_idx ON public.review_cycles USING btree (status);


--
-- Name: review_cycles_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX review_cycles_tenant_id_idx ON public.review_cycles USING btree (tenant_id);


--
-- Name: review_requests_cycle_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX review_requests_cycle_id_idx ON public.review_requests USING btree (cycle_id);


--
-- Name: review_requests_cycle_subject_reviewer_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX review_requests_cycle_subject_reviewer_key ON public.review_requests USING btree (cycle_id, subject_employee_id, reviewer_user_id);


--
-- Name: review_requests_reviewer_user_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX review_requests_reviewer_user_id_idx ON public.review_requests USING btree (reviewer_user_id);


--
-- Name: review_requests_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX review_requests_status_idx ON public.review_requests USING btree (status);


--
-- Name: review_requests_subject_employee_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX review_requests_subject_employee_id_idx ON public.review_requests USING btree (subject_employee_id);


--
-- Name: review_requests_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX review_requests_tenant_id_idx ON public.review_requests USING btree (tenant_id);


--
-- Name: selection_retention_outcomes_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX selection_retention_outcomes_tenant_id_idx ON public.selection_retention_outcomes USING btree (tenant_id);


--
-- Name: selection_retention_outcomes_tenant_status_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX selection_retention_outcomes_tenant_status_idx ON public.selection_retention_outcomes USING btree (tenant_id, outcome_status);


--
-- Name: selection_scoring_weights_tenant_active_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX selection_scoring_weights_tenant_active_idx ON public.selection_scoring_weights USING btree (tenant_id, active);


--
-- Name: selection_sessions_application_id_active_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX selection_sessions_application_id_active_key ON public.selection_sessions USING btree (application_id) WHERE ((application_id IS NOT NULL) AND (status <> ALL (ARRAY['completed'::text, 'rejected'::text, 'expired'::text])));


--
-- Name: selection_sessions_application_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX selection_sessions_application_id_idx ON public.selection_sessions USING btree (application_id);


--
-- Name: selection_sessions_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX selection_sessions_tenant_id_idx ON public.selection_sessions USING btree (tenant_id);


--
-- Name: selection_sessions_token_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX selection_sessions_token_key ON public.selection_sessions USING btree (token);


--
-- Name: selection_stage_results_session_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX selection_stage_results_session_id_idx ON public.selection_stage_results USING btree (session_id);


--
-- Name: selection_templates_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX selection_templates_tenant_id_idx ON public.selection_templates USING btree (tenant_id);


--
-- Name: selection_templates_vacancy_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX selection_templates_vacancy_id_idx ON public.selection_templates USING btree (vacancy_id);


--
-- Name: selection_verdicts_session_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX selection_verdicts_session_id_key ON public.selection_verdicts USING btree (session_id);


--
-- Name: subscriptions_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX subscriptions_tenant_id_idx ON public.subscriptions USING btree (tenant_id);


--
-- Name: subscriptions_tenant_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX subscriptions_tenant_id_key ON public.subscriptions USING btree (tenant_id);


--
-- Name: telegram_links_candidate_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX telegram_links_candidate_id_idx ON public.telegram_links USING btree (candidate_id);


--
-- Name: telegram_links_chat_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX telegram_links_chat_id_key ON public.telegram_links USING btree (chat_id);


--
-- Name: telegram_links_employee_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX telegram_links_employee_id_idx ON public.telegram_links USING btree (employee_id);


--
-- Name: telegram_links_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX telegram_links_tenant_id_idx ON public.telegram_links USING btree (tenant_id);


--
-- Name: tenants_slug_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX tenants_slug_key ON public.tenants USING btree (slug);


--
-- Name: tenants_subdomain_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX tenants_subdomain_key ON public.tenants USING btree (subdomain);


--
-- Name: user_roles_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX user_roles_tenant_id_idx ON public.user_roles USING btree (tenant_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: vacancies_hh_vacancy_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX vacancies_hh_vacancy_id_key ON public.vacancies USING btree (hh_vacancy_id);


--
-- Name: vacancies_org_unit_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX vacancies_org_unit_id_idx ON public.vacancies USING btree (org_unit_id);


--
-- Name: vacancies_requisition_id_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX vacancies_requisition_id_key ON public.vacancies USING btree (requisition_id);


--
-- Name: vacancies_tenant_id_idx; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE INDEX vacancies_tenant_id_idx ON public.vacancies USING btree (tenant_id);


--
-- Name: vacancies_tenant_id_slug_key; Type: INDEX; Schema: public; Owner: hr_user
--

CREATE UNIQUE INDEX vacancies_tenant_id_slug_key ON public.vacancies USING btree (tenant_id, slug) WHERE (slug IS NOT NULL);


--
-- Name: alumni_profiles alumni_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER alumni_profiles_updated_at BEFORE UPDATE ON public.alumni_profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: analytics_signals analytics_signals_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER analytics_signals_updated_at BEFORE UPDATE ON public.analytics_signals FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: comp_bands comp_bands_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER comp_bands_updated_at BEFORE UPDATE ON public.comp_bands FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: comp_plan_items comp_plan_items_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER comp_plan_items_updated_at BEFORE UPDATE ON public.comp_plan_items FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: comp_plans comp_plans_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER comp_plans_updated_at BEFORE UPDATE ON public.comp_plans FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: employees employees_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER employees_updated_at BEFORE UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: employment_documents employment_documents_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER employment_documents_updated_at BEFORE UPDATE ON public.employment_documents FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: exit_interviews exit_interviews_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER exit_interviews_updated_at BEFORE UPDATE ON public.exit_interviews FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: idp_items idp_items_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER idp_items_updated_at BEFORE UPDATE ON public.idp_items FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: idps idps_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER idps_updated_at BEFORE UPDATE ON public.idps FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: interviews interviews_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER interviews_updated_at BEFORE UPDATE ON public.interviews FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: key_results key_results_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER key_results_updated_at BEFORE UPDATE ON public.key_results FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: knowledge_articles knowledge_articles_search_vector_refresh; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER knowledge_articles_search_vector_refresh BEFORE INSERT OR UPDATE OF title, body ON public.knowledge_articles FOR EACH ROW EXECUTE FUNCTION public.knowledge_articles_search_vector_refresh();


--
-- Name: knowledge_articles knowledge_articles_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER knowledge_articles_updated_at BEFORE UPDATE ON public.knowledge_articles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: learning_assignments learning_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER learning_assignments_updated_at BEFORE UPDATE ON public.learning_assignments FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: learning_courses learning_courses_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER learning_courses_updated_at BEFORE UPDATE ON public.learning_courses FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: learning_path_items learning_path_items_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER learning_path_items_updated_at BEFORE UPDATE ON public.learning_path_items FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: learning_paths learning_paths_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER learning_paths_updated_at BEFORE UPDATE ON public.learning_paths FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: offboarding_checklists offboarding_checklists_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER offboarding_checklists_updated_at BEFORE UPDATE ON public.offboarding_checklists FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: offboarding_tasks offboarding_tasks_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER offboarding_tasks_updated_at BEFORE UPDATE ON public.offboarding_tasks FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: offers offers_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER offers_updated_at BEFORE UPDATE ON public.offers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: okrs okrs_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER okrs_updated_at BEFORE UPDATE ON public.okrs FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: onboarding_checklists onboarding_checklists_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER onboarding_checklists_updated_at BEFORE UPDATE ON public.onboarding_checklists FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: onboarding_tasks onboarding_tasks_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER onboarding_tasks_updated_at BEFORE UPDATE ON public.onboarding_tasks FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: one_on_ones one_on_ones_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER one_on_ones_updated_at BEFORE UPDATE ON public.one_on_ones FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: pre_start_portal_entries pre_start_portal_entries_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER pre_start_portal_entries_updated_at BEFORE UPDATE ON public.pre_start_portal_entries FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: review_cycles review_cycles_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER review_cycles_updated_at BEFORE UPDATE ON public.review_cycles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: review_requests review_requests_updated_at; Type: TRIGGER; Schema: public; Owner: hr_user
--

CREATE TRIGGER review_requests_updated_at BEFORE UPDATE ON public.review_requests FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: alumni_profiles alumni_profiles_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.alumni_profiles
    ADD CONSTRAINT alumni_profiles_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: alumni_profiles alumni_profiles_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.alumni_profiles
    ADD CONSTRAINT alumni_profiles_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: application_stage_events application_stage_events_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.application_stage_events
    ADD CONSTRAINT application_stage_events_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: applications applications_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: applications applications_vacancy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.applications
    ADD CONSTRAINT applications_vacancy_id_fkey FOREIGN KEY (vacancy_id) REFERENCES public.vacancies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: assessment_answers assessment_answers_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.assessment_answers
    ADD CONSTRAINT assessment_answers_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.assessment_questions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assessment_answers assessment_answers_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.assessment_answers
    ADD CONSTRAINT assessment_answers_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.assessment_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assessment_questions assessment_questions_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.assessment_questions
    ADD CONSTRAINT assessment_questions_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.assessment_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assessment_sessions assessment_sessions_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.assessment_sessions
    ADD CONSTRAINT assessment_sessions_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assessment_sessions assessment_sessions_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.assessment_sessions
    ADD CONSTRAINT assessment_sessions_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.assessment_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assessment_templates assessment_templates_vacancy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.assessment_templates
    ADD CONSTRAINT assessment_templates_vacancy_id_fkey FOREIGN KEY (vacancy_id) REFERENCES public.vacancies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: auth_sessions auth_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comp_plan_items comp_plan_items_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.comp_plan_items
    ADD CONSTRAINT comp_plan_items_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.comp_plans(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: conversations conversations_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: data_retention_policies data_retention_policies_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.data_retention_policies
    ADD CONSTRAINT data_retention_policies_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: employee_lifecycle_events employee_lifecycle_events_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.employee_lifecycle_events
    ADD CONSTRAINT employee_lifecycle_events_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: employees employees_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees employees_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees employees_org_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_org_unit_id_fkey FOREIGN KEY (org_unit_id) REFERENCES public.org_units(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees employees_requisition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_requisition_id_fkey FOREIGN KEY (requisition_id) REFERENCES public.hiring_requisitions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employees employees_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: employment_documents employment_documents_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.employment_documents
    ADD CONSTRAINT employment_documents_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: exit_interviews exit_interviews_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.exit_interviews
    ADD CONSTRAINT exit_interviews_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hh_sync_cursors hh_sync_cursors_vacancy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.hh_sync_cursors
    ADD CONSTRAINT hh_sync_cursors_vacancy_id_fkey FOREIGN KEY (vacancy_id) REFERENCES public.vacancies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hiring_requisitions hiring_requisitions_org_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.hiring_requisitions
    ADD CONSTRAINT hiring_requisitions_org_unit_id_fkey FOREIGN KEY (org_unit_id) REFERENCES public.org_units(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: idp_items idp_items_idp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.idp_items
    ADD CONSTRAINT idp_items_idp_id_fkey FOREIGN KEY (idp_id) REFERENCES public.idps(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: idps idps_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.idps
    ADD CONSTRAINT idps_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: interviews interviews_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: key_results key_results_okr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.key_results
    ADD CONSTRAINT key_results_okr_id_fkey FOREIGN KEY (okr_id) REFERENCES public.okrs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: learning_assignments learning_assignments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.learning_assignments
    ADD CONSTRAINT learning_assignments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.learning_courses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: learning_assignments learning_assignments_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.learning_assignments
    ADD CONSTRAINT learning_assignments_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: learning_assignments learning_assignments_path_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.learning_assignments
    ADD CONSTRAINT learning_assignments_path_id_fkey FOREIGN KEY (path_id) REFERENCES public.learning_paths(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: learning_courses learning_courses_org_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.learning_courses
    ADD CONSTRAINT learning_courses_org_unit_id_fkey FOREIGN KEY (org_unit_id) REFERENCES public.org_units(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: learning_path_items learning_path_items_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.learning_path_items
    ADD CONSTRAINT learning_path_items_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.learning_courses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: learning_path_items learning_path_items_path_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.learning_path_items
    ADD CONSTRAINT learning_path_items_path_id_fkey FOREIGN KEY (path_id) REFERENCES public.learning_paths(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: offboarding_checklists offboarding_checklists_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.offboarding_checklists
    ADD CONSTRAINT offboarding_checklists_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: offboarding_tasks offboarding_tasks_checklist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.offboarding_tasks
    ADD CONSTRAINT offboarding_tasks_checklist_id_fkey FOREIGN KEY (checklist_id) REFERENCES public.offboarding_checklists(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: offers offers_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_application_id_fkey FOREIGN KEY (application_id) REFERENCES public.applications(id) ON DELETE CASCADE;


--
-- Name: offers offers_interview_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_interview_id_fkey FOREIGN KEY (interview_id) REFERENCES public.interviews(id) ON DELETE SET NULL;


--
-- Name: okrs okrs_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.okrs
    ADD CONSTRAINT okrs_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: okrs okrs_parent_okr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.okrs
    ADD CONSTRAINT okrs_parent_okr_id_fkey FOREIGN KEY (parent_okr_id) REFERENCES public.okrs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: onboarding_checklists onboarding_checklists_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.onboarding_checklists
    ADD CONSTRAINT onboarding_checklists_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: onboarding_tasks onboarding_tasks_checklist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.onboarding_tasks
    ADD CONSTRAINT onboarding_tasks_checklist_id_fkey FOREIGN KEY (checklist_id) REFERENCES public.onboarding_checklists(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: one_on_ones one_on_ones_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.one_on_ones
    ADD CONSTRAINT one_on_ones_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: org_units org_units_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.org_units
    ADD CONSTRAINT org_units_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.org_units(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pre_start_portal_entries pre_start_portal_entries_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.pre_start_portal_entries
    ADD CONSTRAINT pre_start_portal_entries_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: resumes resumes_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.resumes
    ADD CONSTRAINT resumes_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES public.candidates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review_requests review_requests_cycle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.review_requests
    ADD CONSTRAINT review_requests_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES public.review_cycles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review_requests review_requests_subject_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.review_requests
    ADD CONSTRAINT review_requests_subject_employee_id_fkey FOREIGN KEY (subject_employee_id) REFERENCES public.employees(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: selection_retention_outcomes selection_retention_outcomes_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_retention_outcomes
    ADD CONSTRAINT selection_retention_outcomes_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.selection_sessions(id) ON DELETE CASCADE;


--
-- Name: selection_retention_outcomes selection_retention_outcomes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_retention_outcomes
    ADD CONSTRAINT selection_retention_outcomes_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: selection_scoring_weights selection_scoring_weights_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_scoring_weights
    ADD CONSTRAINT selection_scoring_weights_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: selection_sessions selection_sessions_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_sessions
    ADD CONSTRAINT selection_sessions_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.selection_templates(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: selection_stage_results selection_stage_results_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_stage_results
    ADD CONSTRAINT selection_stage_results_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.selection_sessions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: selection_templates selection_templates_vacancy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_templates
    ADD CONSTRAINT selection_templates_vacancy_id_fkey FOREIGN KEY (vacancy_id) REFERENCES public.vacancies(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: selection_verdicts selection_verdicts_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.selection_verdicts
    ADD CONSTRAINT selection_verdicts_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.selection_sessions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: specialization_module_results specialization_module_results_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.specialization_module_results
    ADD CONSTRAINT specialization_module_results_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.selection_sessions(id);


--
-- Name: subscriptions subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id);


--
-- Name: subscriptions subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tenant_settings tenant_settings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.tenant_settings
    ADD CONSTRAINT tenant_settings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vacancies vacancies_org_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.vacancies
    ADD CONSTRAINT vacancies_org_unit_id_fkey FOREIGN KEY (org_unit_id) REFERENCES public.org_units(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vacancies vacancies_requisition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hr_user
--

ALTER TABLE ONLY public.vacancies
    ADD CONSTRAINT vacancies_requisition_id_fkey FOREIGN KEY (requisition_id) REFERENCES public.hiring_requisitions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: alumni_profiles; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.alumni_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: alumni_profiles alumni_profiles_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY alumni_profiles_select ON public.alumni_profiles FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: alumni_profiles alumni_profiles_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY alumni_profiles_write ON public.alumni_profiles USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: analytics_signals; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.analytics_signals ENABLE ROW LEVEL SECURITY;

--
-- Name: analytics_signals analytics_signals_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY analytics_signals_select ON public.analytics_signals FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text))));


--
-- Name: analytics_signals analytics_signals_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY analytics_signals_write ON public.analytics_signals USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: application_stage_events; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.application_stage_events ENABLE ROW LEVEL SECURITY;

--
-- Name: application_stage_events application_stage_events_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY application_stage_events_insert ON public.application_stage_events FOR INSERT WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)) AND (actor_user_id = app.current_user_id())));


--
-- Name: application_stage_events application_stage_events_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY application_stage_events_select ON public.application_stage_events FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: applications; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.applications ENABLE ROW LEVEL SECURITY;

--
-- Name: applications applications_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY applications_select ON public.applications FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: applications applications_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY applications_write ON public.applications USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: assessment_answers; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.assessment_answers ENABLE ROW LEVEL SECURITY;

--
-- Name: assessment_answers assessment_answers_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY assessment_answers_select ON public.assessment_answers FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.assessment_sessions s
  WHERE ((s.id = assessment_answers.session_id) AND (s.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))))));


--
-- Name: assessment_answers assessment_answers_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY assessment_answers_write ON public.assessment_answers USING ((EXISTS ( SELECT 1
   FROM public.assessment_sessions s
  WHERE ((s.id = assessment_answers.session_id) AND (s.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.assessment_sessions s
  WHERE ((s.id = assessment_answers.session_id) AND (s.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))))));


--
-- Name: assessment_questions; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.assessment_questions ENABLE ROW LEVEL SECURITY;

--
-- Name: assessment_questions assessment_questions_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY assessment_questions_select ON public.assessment_questions FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.assessment_templates t
  WHERE ((t.id = assessment_questions.template_id) AND (t.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))))));


--
-- Name: assessment_questions assessment_questions_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY assessment_questions_write ON public.assessment_questions USING ((EXISTS ( SELECT 1
   FROM public.assessment_templates t
  WHERE ((t.id = assessment_questions.template_id) AND (t.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.assessment_templates t
  WHERE ((t.id = assessment_questions.template_id) AND (t.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))))));


--
-- Name: assessment_sessions; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.assessment_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: assessment_sessions assessment_sessions_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY assessment_sessions_select ON public.assessment_sessions FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: assessment_sessions assessment_sessions_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY assessment_sessions_write ON public.assessment_sessions USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: assessment_templates; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.assessment_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: assessment_templates assessment_templates_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY assessment_templates_select ON public.assessment_templates FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: assessment_templates assessment_templates_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY assessment_templates_write ON public.assessment_templates USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: audit_events; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_events audit_events_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY audit_events_insert ON public.audit_events FOR INSERT WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: audit_events audit_events_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY audit_events_select ON public.audit_events FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (actor_user_id = app.current_user_id()))));


--
-- Name: candidates; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.candidates ENABLE ROW LEVEL SECURITY;

--
-- Name: candidates candidates_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY candidates_select ON public.candidates FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: candidates candidates_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY candidates_write ON public.candidates USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: comp_bands; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.comp_bands ENABLE ROW LEVEL SECURITY;

--
-- Name: comp_bands comp_bands_delete; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_bands_delete ON public.comp_bands FOR DELETE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: comp_bands comp_bands_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_bands_insert ON public.comp_bands FOR INSERT WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: comp_bands comp_bands_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_bands_select ON public.comp_bands FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: comp_bands comp_bands_update; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_bands_update ON public.comp_bands FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: comp_plan_items; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.comp_plan_items ENABLE ROW LEVEL SECURITY;

--
-- Name: comp_plan_items comp_plan_items_delete; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_plan_items_delete ON public.comp_plan_items FOR DELETE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: comp_plan_items comp_plan_items_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_plan_items_insert ON public.comp_plan_items FOR INSERT WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: comp_plan_items comp_plan_items_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_plan_items_select ON public.comp_plan_items FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text))));


--
-- Name: comp_plan_items comp_plan_items_update; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_plan_items_update ON public.comp_plan_items FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: comp_plans; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.comp_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: comp_plans comp_plans_delete; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_plans_delete ON public.comp_plans FOR DELETE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: comp_plans comp_plans_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_plans_insert ON public.comp_plans FOR INSERT WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: comp_plans comp_plans_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_plans_select ON public.comp_plans FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text))));


--
-- Name: comp_plans comp_plans_update; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY comp_plans_update ON public.comp_plans FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: conversations; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

--
-- Name: conversations conversations_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY conversations_select ON public.conversations FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: conversations conversations_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY conversations_write ON public.conversations USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: data_retention_policies; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.data_retention_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: data_retention_policies data_retention_policies_isolation; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY data_retention_policies_isolation ON public.data_retention_policies USING ((tenant_id = app.current_tenant_id())) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: device_tokens; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.device_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: device_tokens device_tokens_owner_rw; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY device_tokens_owner_rw ON public.device_tokens USING (((tenant_id = app.current_tenant_id()) AND ((user_id = app.current_user_id()) OR app.is_admin()))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (user_id = app.current_user_id())));


--
-- Name: employee_lifecycle_events; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.employee_lifecycle_events ENABLE ROW LEVEL SECURITY;

--
-- Name: employee_lifecycle_events employee_lifecycle_events_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY employee_lifecycle_events_insert ON public.employee_lifecycle_events FOR INSERT WITH CHECK (((tenant_id = app.current_tenant_id()) AND ((actor_user_id = app.current_user_id()) OR ((actor_user_id IS NULL) AND app.has_role('system'::text)))));


--
-- Name: employee_lifecycle_events employee_lifecycle_events_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY employee_lifecycle_events_select ON public.employee_lifecycle_events FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text) OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = employee_lifecycle_events.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: employees; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

--
-- Name: employees employees_delete; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY employees_delete ON public.employees FOR DELETE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: employees employees_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY employees_insert ON public.employees FOR INSERT WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: employees employees_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY employees_select ON public.employees FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text) OR (app.has_role('employee'::text) AND (user_id = app.current_user_id())))));


--
-- Name: employees employees_update; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY employees_update ON public.employees FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: employment_documents; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.employment_documents ENABLE ROW LEVEL SECURITY;

--
-- Name: employment_documents employment_documents_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY employment_documents_select ON public.employment_documents FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = employment_documents.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: employment_documents employment_documents_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY employment_documents_write ON public.employment_documents USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: exit_interviews; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.exit_interviews ENABLE ROW LEVEL SECURITY;

--
-- Name: exit_interviews exit_interviews_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY exit_interviews_select ON public.exit_interviews FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text))));


--
-- Name: exit_interviews exit_interviews_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY exit_interviews_write ON public.exit_interviews USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: external_vacancy_posts; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.external_vacancy_posts ENABLE ROW LEVEL SECURITY;

--
-- Name: external_vacancy_posts external_vacancy_posts_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY external_vacancy_posts_select ON public.external_vacancy_posts FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: external_vacancy_posts external_vacancy_posts_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY external_vacancy_posts_write ON public.external_vacancy_posts USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: hh_connections; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.hh_connections ENABLE ROW LEVEL SECURITY;

--
-- Name: hh_connections hh_connections_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hh_connections_select ON public.hh_connections FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: hh_connections hh_connections_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hh_connections_write ON public.hh_connections USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: hh_sync_cursors; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.hh_sync_cursors ENABLE ROW LEVEL SECURITY;

--
-- Name: hh_sync_cursors hh_sync_cursors_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hh_sync_cursors_select ON public.hh_sync_cursors FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: hh_sync_cursors hh_sync_cursors_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hh_sync_cursors_write ON public.hh_sync_cursors USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: hiring_requisitions; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.hiring_requisitions ENABLE ROW LEVEL SECURITY;

--
-- Name: hiring_requisitions hiring_requisitions_delete; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hiring_requisitions_delete ON public.hiring_requisitions FOR DELETE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: hiring_requisitions hiring_requisitions_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hiring_requisitions_insert ON public.hiring_requisitions FOR INSERT WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR (app.has_role('hiring_manager'::text) AND (created_by_user_id = app.current_user_id())))));


--
-- Name: hiring_requisitions hiring_requisitions_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hiring_requisitions_select ON public.hiring_requisitions FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR (app.has_role('hiring_manager'::text) AND (created_by_user_id = app.current_user_id())))));


--
-- Name: hiring_requisitions hiring_requisitions_update; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hiring_requisitions_update ON public.hiring_requisitions FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (app.has_role('hiring_manager'::text) AND (created_by_user_id = app.current_user_id()))))) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: hr_snapshots; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.hr_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: hr_snapshots hr_snapshots_delete; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hr_snapshots_delete ON public.hr_snapshots FOR DELETE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: hr_snapshots hr_snapshots_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hr_snapshots_insert ON public.hr_snapshots FOR INSERT WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: hr_snapshots hr_snapshots_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hr_snapshots_select ON public.hr_snapshots FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text))));


--
-- Name: hr_snapshots hr_snapshots_update; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY hr_snapshots_update ON public.hr_snapshots FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: idp_items; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.idp_items ENABLE ROW LEVEL SECURITY;

--
-- Name: idp_items idp_items_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY idp_items_select ON public.idp_items FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text) OR (EXISTS ( SELECT 1
   FROM (public.idps i
     JOIN public.employees e ON ((e.id = i.employee_id)))
  WHERE ((i.id = idp_items.idp_id) AND (e.user_id = app.current_user_id())))))));


--
-- Name: idp_items idp_items_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY idp_items_write ON public.idp_items USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (EXISTS ( SELECT 1
   FROM (public.idps i
     JOIN public.employees e ON ((e.id = i.employee_id)))
  WHERE ((i.id = idp_items.idp_id) AND (e.user_id = app.current_user_id()))))))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (EXISTS ( SELECT 1
   FROM (public.idps i
     JOIN public.employees e ON ((e.id = i.employee_id)))
  WHERE ((i.id = idp_items.idp_id) AND (e.user_id = app.current_user_id())))))));


--
-- Name: idps; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.idps ENABLE ROW LEVEL SECURITY;

--
-- Name: idps idps_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY idps_select ON public.idps FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text) OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = idps.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: idps idps_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY idps_write ON public.idps USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = idps.employee_id) AND (e.user_id = app.current_user_id())))))))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = idps.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: interviews; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.interviews ENABLE ROW LEVEL SECURITY;

--
-- Name: interviews interviews_delete; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY interviews_delete ON public.interviews FOR DELETE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: interviews interviews_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY interviews_insert ON public.interviews FOR INSERT WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: interviews interviews_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY interviews_select ON public.interviews FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: interviews interviews_update; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY interviews_update ON public.interviews FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: key_results; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.key_results ENABLE ROW LEVEL SECURITY;

--
-- Name: key_results key_results_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY key_results_select ON public.key_results FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text) OR (EXISTS ( SELECT 1
   FROM (public.okrs o
     JOIN public.employees e ON ((e.id = o.employee_id)))
  WHERE ((o.id = key_results.okr_id) AND (e.user_id = app.current_user_id())))))));


--
-- Name: key_results key_results_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY key_results_write ON public.key_results USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (EXISTS ( SELECT 1
   FROM (public.okrs o
     JOIN public.employees e ON ((e.id = o.employee_id)))
  WHERE ((o.id = key_results.okr_id) AND (e.user_id = app.current_user_id()))))))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (EXISTS ( SELECT 1
   FROM (public.okrs o
     JOIN public.employees e ON ((e.id = o.employee_id)))
  WHERE ((o.id = key_results.okr_id) AND (e.user_id = app.current_user_id())))))));


--
-- Name: knowledge_articles; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.knowledge_articles ENABLE ROW LEVEL SECURITY;

--
-- Name: knowledge_articles knowledge_articles_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY knowledge_articles_select ON public.knowledge_articles FOR SELECT USING ((tenant_id = app.current_tenant_id()));


--
-- Name: knowledge_articles knowledge_articles_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY knowledge_articles_write ON public.knowledge_articles USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: learning_assignments; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.learning_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: learning_assignments learning_assignments_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY learning_assignments_select ON public.learning_assignments FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text) OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = learning_assignments.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: learning_assignments learning_assignments_update_self; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY learning_assignments_update_self ON public.learning_assignments FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = learning_assignments.employee_id) AND (e.user_id = app.current_user_id())))))) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: learning_assignments learning_assignments_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY learning_assignments_write ON public.learning_assignments USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: learning_courses; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.learning_courses ENABLE ROW LEVEL SECURITY;

--
-- Name: learning_courses learning_courses_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY learning_courses_select ON public.learning_courses FOR SELECT USING ((tenant_id = app.current_tenant_id()));


--
-- Name: learning_courses learning_courses_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY learning_courses_write ON public.learning_courses USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: learning_path_items; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.learning_path_items ENABLE ROW LEVEL SECURITY;

--
-- Name: learning_path_items learning_path_items_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY learning_path_items_select ON public.learning_path_items FOR SELECT USING ((tenant_id = app.current_tenant_id()));


--
-- Name: learning_path_items learning_path_items_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY learning_path_items_write ON public.learning_path_items USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: learning_paths; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.learning_paths ENABLE ROW LEVEL SECURITY;

--
-- Name: learning_paths learning_paths_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY learning_paths_select ON public.learning_paths FOR SELECT USING ((tenant_id = app.current_tenant_id()));


--
-- Name: learning_paths learning_paths_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY learning_paths_write ON public.learning_paths USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: message_templates; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.message_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: message_templates message_templates_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY message_templates_select ON public.message_templates FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: message_templates message_templates_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY message_templates_write ON public.message_templates USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: messages; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: messages messages_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY messages_select ON public.messages FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: messages messages_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY messages_write ON public.messages USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY notifications_insert ON public.notifications FOR INSERT WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: notifications notifications_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY notifications_select ON public.notifications FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (recipient_user_id = app.current_user_id())));


--
-- Name: notifications notifications_update_own; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY notifications_update_own ON public.notifications FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND (recipient_user_id = app.current_user_id()))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (recipient_user_id = app.current_user_id())));


--
-- Name: offboarding_checklists; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.offboarding_checklists ENABLE ROW LEVEL SECURITY;

--
-- Name: offboarding_checklists offboarding_checklists_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY offboarding_checklists_select ON public.offboarding_checklists FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text) OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = offboarding_checklists.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: offboarding_checklists offboarding_checklists_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY offboarding_checklists_write ON public.offboarding_checklists USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: offboarding_tasks; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.offboarding_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: offboarding_tasks offboarding_tasks_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY offboarding_tasks_select ON public.offboarding_tasks FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text) OR (app.has_role('employee'::text) AND (assignee_user_id = app.current_user_id())))));


--
-- Name: offboarding_tasks offboarding_tasks_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY offboarding_tasks_write ON public.offboarding_tasks USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: offers; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;

--
-- Name: offers offers_delete; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY offers_delete ON public.offers FOR DELETE USING (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: offers offers_insert; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY offers_insert ON public.offers FOR INSERT WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: offers offers_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY offers_select ON public.offers FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: offers offers_update; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY offers_update ON public.offers FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: okrs; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.okrs ENABLE ROW LEVEL SECURITY;

--
-- Name: okrs okrs_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY okrs_select ON public.okrs FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text) OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = okrs.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: okrs okrs_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY okrs_write ON public.okrs USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = okrs.employee_id) AND (e.user_id = app.current_user_id())))))))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = okrs.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: onboarding_checklists; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.onboarding_checklists ENABLE ROW LEVEL SECURITY;

--
-- Name: onboarding_checklists onboarding_checklists_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY onboarding_checklists_select ON public.onboarding_checklists FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text) OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = onboarding_checklists.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: onboarding_checklists onboarding_checklists_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY onboarding_checklists_write ON public.onboarding_checklists USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: onboarding_tasks; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.onboarding_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: onboarding_tasks onboarding_tasks_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY onboarding_tasks_select ON public.onboarding_tasks FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('hiring_manager'::text) OR (app.has_role('employee'::text) AND (assignee_user_id = app.current_user_id())))));


--
-- Name: onboarding_tasks onboarding_tasks_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY onboarding_tasks_write ON public.onboarding_tasks USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: one_on_ones; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.one_on_ones ENABLE ROW LEVEL SECURITY;

--
-- Name: one_on_ones one_on_ones_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY one_on_ones_select ON public.one_on_ones FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (manager_user_id = app.current_user_id()) OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = one_on_ones.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: one_on_ones one_on_ones_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY one_on_ones_write ON public.one_on_ones USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (manager_user_id = app.current_user_id())))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (manager_user_id = app.current_user_id()))));


--
-- Name: org_units; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.org_units ENABLE ROW LEVEL SECURITY;

--
-- Name: org_units org_units_tenant_read; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY org_units_tenant_read ON public.org_units FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: org_units org_units_tenant_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY org_units_tenant_write ON public.org_units USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: pre_start_portal_entries; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.pre_start_portal_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: pre_start_portal_entries pre_start_portal_entries_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY pre_start_portal_entries_select ON public.pre_start_portal_entries FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = pre_start_portal_entries.employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: pre_start_portal_entries pre_start_portal_entries_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY pre_start_portal_entries_write ON public.pre_start_portal_entries USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: resumes; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.resumes ENABLE ROW LEVEL SECURITY;

--
-- Name: resumes resumes_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY resumes_select ON public.resumes FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: resumes resumes_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY resumes_write ON public.resumes USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: review_cycles; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.review_cycles ENABLE ROW LEVEL SECURITY;

--
-- Name: review_cycles review_cycles_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY review_cycles_select ON public.review_cycles FOR SELECT USING ((tenant_id = app.current_tenant_id()));


--
-- Name: review_cycles review_cycles_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY review_cycles_write ON public.review_cycles USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: review_requests; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.review_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: review_requests review_requests_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY review_requests_select ON public.review_requests FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR (reviewer_user_id = app.current_user_id()) OR (app.has_role('employee'::text) AND (EXISTS ( SELECT 1
   FROM public.employees e
  WHERE ((e.id = review_requests.subject_employee_id) AND (e.user_id = app.current_user_id()))))))));


--
-- Name: review_requests review_requests_update_self; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY review_requests_update_self ON public.review_requests FOR UPDATE USING (((tenant_id = app.current_tenant_id()) AND (reviewer_user_id = app.current_user_id()))) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: review_requests review_requests_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY review_requests_write ON public.review_requests USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: selection_sessions; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.selection_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: selection_sessions selection_sessions_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY selection_sessions_select ON public.selection_sessions FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: selection_sessions selection_sessions_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY selection_sessions_write ON public.selection_sessions USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: selection_stage_results; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.selection_stage_results ENABLE ROW LEVEL SECURITY;

--
-- Name: selection_stage_results selection_stage_results_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY selection_stage_results_select ON public.selection_stage_results FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.selection_sessions s
  WHERE ((s.id = selection_stage_results.session_id) AND (s.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))))));


--
-- Name: selection_stage_results selection_stage_results_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY selection_stage_results_write ON public.selection_stage_results USING ((EXISTS ( SELECT 1
   FROM public.selection_sessions s
  WHERE ((s.id = selection_stage_results.session_id) AND (s.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.selection_sessions s
  WHERE ((s.id = selection_stage_results.session_id) AND (s.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))))));


--
-- Name: selection_templates; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.selection_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: selection_templates selection_templates_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY selection_templates_select ON public.selection_templates FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: selection_templates selection_templates_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY selection_templates_write ON public.selection_templates USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: selection_verdicts; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.selection_verdicts ENABLE ROW LEVEL SECURITY;

--
-- Name: selection_verdicts selection_verdicts_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY selection_verdicts_select ON public.selection_verdicts FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.selection_sessions s
  WHERE ((s.id = selection_verdicts.session_id) AND (s.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))))));


--
-- Name: selection_verdicts selection_verdicts_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY selection_verdicts_write ON public.selection_verdicts USING ((EXISTS ( SELECT 1
   FROM public.selection_sessions s
  WHERE ((s.id = selection_verdicts.session_id) AND (s.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.selection_sessions s
  WHERE ((s.id = selection_verdicts.session_id) AND (s.tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))))));


--
-- Name: subscriptions; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: subscriptions subscriptions_isolation; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY subscriptions_isolation ON public.subscriptions USING ((tenant_id = app.current_tenant_id())) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: telegram_links; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.telegram_links ENABLE ROW LEVEL SECURITY;

--
-- Name: telegram_links telegram_links_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY telegram_links_select ON public.telegram_links FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: telegram_links telegram_links_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY telegram_links_write ON public.telegram_links USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text)))) WITH CHECK (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text))));


--
-- Name: tenant_settings; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.tenant_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: tenant_settings tenant_settings_isolation; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY tenant_settings_isolation ON public.tenant_settings USING ((tenant_id = app.current_tenant_id())) WITH CHECK ((tenant_id = app.current_tenant_id()));


--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants tenants_self; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY tenants_self ON public.tenants FOR SELECT USING ((id = app.current_tenant_id()));


--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles user_roles_tenant_admin; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY user_roles_tenant_admin ON public.user_roles USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: vacancies; Type: ROW SECURITY; Schema: public; Owner: hr_user
--

ALTER TABLE public.vacancies ENABLE ROW LEVEL SECURITY;

--
-- Name: vacancies vacancies_select; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY vacancies_select ON public.vacancies FOR SELECT USING (((tenant_id = app.current_tenant_id()) AND (app.is_admin() OR app.has_role('recruiter'::text) OR app.has_role('hiring_manager'::text))));


--
-- Name: vacancies vacancies_write; Type: POLICY; Schema: public; Owner: hr_user
--

CREATE POLICY vacancies_write ON public.vacancies USING (((tenant_id = app.current_tenant_id()) AND app.is_admin())) WITH CHECK (((tenant_id = app.current_tenant_id()) AND app.is_admin()));


--
-- Name: SCHEMA app; Type: ACL; Schema: -; Owner: hr_user
--

GRANT USAGE ON SCHEMA app TO app_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO app_user;


--
-- Name: TABLE alumni_profiles; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.alumni_profiles TO app_user;


--
-- Name: TABLE analytics_signals; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.analytics_signals TO app_user;


--
-- Name: TABLE application_stage_events; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.application_stage_events TO app_user;


--
-- Name: TABLE applications; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.applications TO app_user;


--
-- Name: TABLE assessment_answers; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.assessment_answers TO app_user;


--
-- Name: TABLE assessment_questions; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.assessment_questions TO app_user;


--
-- Name: TABLE assessment_sessions; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.assessment_sessions TO app_user;


--
-- Name: TABLE assessment_templates; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.assessment_templates TO app_user;


--
-- Name: TABLE audit_events; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.audit_events TO app_user;


--
-- Name: TABLE candidates; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.candidates TO app_user;


--
-- Name: TABLE comp_bands; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.comp_bands TO app_user;


--
-- Name: TABLE comp_plan_items; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.comp_plan_items TO app_user;


--
-- Name: TABLE comp_plans; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.comp_plans TO app_user;


--
-- Name: TABLE conversations; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.conversations TO app_user;


--
-- Name: TABLE employee_lifecycle_events; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT ON TABLE public.employee_lifecycle_events TO app_user;


--
-- Name: TABLE employees; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.employees TO app_user;


--
-- Name: TABLE employment_documents; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.employment_documents TO app_user;


--
-- Name: TABLE exit_interviews; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.exit_interviews TO app_user;


--
-- Name: TABLE hh_connections; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.hh_connections TO app_user;


--
-- Name: TABLE hh_sync_cursors; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.hh_sync_cursors TO app_user;


--
-- Name: TABLE hiring_requisitions; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.hiring_requisitions TO app_user;


--
-- Name: TABLE hr_snapshots; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.hr_snapshots TO app_user;


--
-- Name: TABLE idp_items; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idp_items TO app_user;


--
-- Name: TABLE idps; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.idps TO app_user;


--
-- Name: TABLE interviews; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.interviews TO app_user;


--
-- Name: TABLE key_results; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.key_results TO app_user;


--
-- Name: TABLE knowledge_articles; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.knowledge_articles TO app_user;


--
-- Name: TABLE learning_assignments; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.learning_assignments TO app_user;


--
-- Name: TABLE learning_courses; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.learning_courses TO app_user;


--
-- Name: TABLE learning_path_items; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.learning_path_items TO app_user;


--
-- Name: TABLE learning_paths; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.learning_paths TO app_user;


--
-- Name: TABLE message_templates; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.message_templates TO app_user;


--
-- Name: TABLE messages; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.messages TO app_user;


--
-- Name: TABLE notifications; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.notifications TO app_user;


--
-- Name: TABLE offboarding_checklists; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.offboarding_checklists TO app_user;


--
-- Name: TABLE offboarding_tasks; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.offboarding_tasks TO app_user;


--
-- Name: TABLE offers; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.offers TO app_user;


--
-- Name: TABLE okrs; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.okrs TO app_user;


--
-- Name: TABLE onboarding_checklists; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.onboarding_checklists TO app_user;


--
-- Name: TABLE onboarding_tasks; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.onboarding_tasks TO app_user;


--
-- Name: TABLE one_on_ones; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.one_on_ones TO app_user;


--
-- Name: TABLE org_units; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.org_units TO app_user;


--
-- Name: TABLE pre_start_portal_entries; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pre_start_portal_entries TO app_user;


--
-- Name: TABLE resumes; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.resumes TO app_user;


--
-- Name: TABLE review_cycles; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.review_cycles TO app_user;


--
-- Name: TABLE review_requests; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.review_requests TO app_user;


--
-- Name: TABLE selection_sessions; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.selection_sessions TO app_user;


--
-- Name: TABLE selection_stage_results; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.selection_stage_results TO app_user;


--
-- Name: TABLE selection_templates; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.selection_templates TO app_user;


--
-- Name: TABLE selection_verdicts; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.selection_verdicts TO app_user;


--
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tenants TO app_user;


--
-- Name: TABLE user_roles; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.user_roles TO app_user;


--
-- Name: TABLE vacancies; Type: ACL; Schema: public; Owner: hr_user
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.vacancies TO app_user;


--
-- PostgreSQL database dump complete
--

\unrestrict wdOxN2Mr8GXJApTcjSuArzPEr3bLN4B4NKLyOShjRTwts1Tnsr0QFO9YWp4tzcS

